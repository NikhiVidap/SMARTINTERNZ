<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}

if(isset($_GET['edit_id']))
	{
		$edit_id	=	$_GET['edit_id'];
		$_SESSION['edit_id'] = $edit_id;
	}
	 else if(isset($_SESSION['edit_id']))
	{
		$edit_id	= $_SESSION['edit_id'];
	}
	
	if(isset($_POST['update']))
	{	
		$department 	= $_POST['department'];
		$description	= $_POST['description'];
		
		
		if($db->update_category($department,$description,$edit_id))
		{
		?>
			<script>
			alert("Successfully Updated...!!!");
			window.location.href="income-source-category-master.php";
			</script>
		<?php
			
		}
		else
		{
			$success_msg = 2 ;
		}
	}

$db_expenses	=	array();
$db_expenses = $db->get_category_by_id($edit_id);

if(!empty($db_expenses))
{
	$res_id		=	$db_expenses[0];
	$res_dep	=	$db_expenses[1];
	$res_desc	=	$db_expenses[2];
	
}
	
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>New Product</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	<link href="datatable/datatables.min.css" rel="stylesheet" />

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	
</head>
<body class="fixed-navbar">
  
<div class="page-wrapper" style="min-height:500px;">
<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>
<div class="content-wrapper">
<div class="row" style="padding:0px; margin:0px; margin-top:15px; border-radius:15px;">

<div class="ibox" style="border-radius:5px; padding:7px;">
	 <form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">
		
		<div class="ibox-head">
			<div class="ibox-title"><i class="fas fa-cog" style="margin-right:10px;"></i>UPDATE CATEGORY</div>
			
			<a href="add-department.php" class="btn btn-outline-danger btn-rounded waves-effect"><i class="fas fa-angle-double-left">&nbsp;&nbsp;</i>DESIGNATION</a>

		</div>
		
		<div class="ibox-body">
			<div class="row">
				
				<div class="col-sm-4 col-md-4 col-lg-4 form-group mb-4">			
					<label class="form-group mb-4 set-row label_marg"><b>Enter Category</b></label>
					<div class="input-group-icon input-group-icon-left  set-row">
						<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
						<input class="form-control form-control-air" name="department" id="department" placeholder="Category Name" value="<?php echo $res_dep; ?>"  required />
					</div>
				</div>
				
				<div class="col-sm-4 col-md-4 col-lg-4 form-group mb-4">			
					<label class="form-group mb-4 set-row label_marg"><b>Description</b></label>
					<div class="input-group-icon input-group-icon-left  set-row">
						<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
						<input class="form-control form-control-air" name="description" id="description" placeholder="Description"  value="<?php echo $res_desc; ?>" required >
					</div>
				</div>
				
				<div class="col-sm-4 form-group mb-12" style="text-align:center; padding-left:0px; padding-right:0px; padding-top:20px;">
					<div class="col-sm-12 form-group mb-12" style="margin:auto;">
						<button class="btn btn-pink btn-air" type="submit" name="update" style="width:100%;" onclick="submitData()">UPATE DETAILS</button>
							
					</div>
				</div>
			</div>
		</div>
	</form>
	</div>
</div>
</div>

</div>
</div>
<?php include('footer.php'); ?>
</div>
    </div>
    <?php include('search.php'); ?>
   
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    
    <script src="js/jquery.min.js"></script>

    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/idle-timer.min.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
	<script src="datatable/datatables.min.js"></script>
    <script src="js/app.min.js"></script>
	
</body>
</html>