<?php 
require_once('lib/functions.php');

$db		=	new login_function();
$two_thousand		=	"";
$five_hundard		=	"";
$hundard			=	"";
$fifty				=	"";
$twenty				=	"";
$ten				=	"";
$five				=	"";
$two				=	"";


$ten_rs				=	"";
$five_rs			=	"";
$two_rs				=	"";	
$one_rs				=	"";
$ekun_rokh_bharana	=	"";
$checkne_jama		=	"";	
$banket_parsper_jama=	"";
$anamat_peki_jama	=	"";
$ekun				=	"";
		$total_paid_amount		=	"";
		$two_thousand_val	=	"";
		$show_two_thousand	=	"";
		
		$five_hundard_val	=	"";
		$show_five_hundard	=	"";
		
		$two_hundred_val	=	"";
		$show_two_hundred_val="";
		$hundred_val		=	"";
		$show_hundred_val	=	"";
		
		$fifty_val			=	"";
		$show_fifty_val		=	"";
		
		$twenty_val			=	"";
		$show_twenty_val	=	"";
		
		$ten_val			=	"";
		$show_ten_val		=	"";
		
		$ten_val_rs			=	"";
		$show_ten_rs		=	"";
		
		$five_val_rs		=	"";
		$show_five_rs		=	"";
		
		$two_val_rs			=	"";
		$show_two_rs		=	"";
		
		$one_val_rs			=	"";
		$show_one_rs		=	"";
		
		$note_total			=	"";
		$nani_total			=	"";
		$ekun_bharana		=	"";
		$flag				=	0;
if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
	
if(isset($_GET['edit_id']))
{
	$edit_id				=	$_GET['edit_id'];
	$_SESSION['edit_id'] 	= $edit_id;
}
else if(isset($_SESSION['edit_id']))
{
	$edit_id	= $_SESSION['edit_id'];
}
$details	=	array();
$details	=	$db->get_chalan_data($edit_id);
if(!empty($details))
{
$res_id				=	$details[0];		
$software_users		=	$details[1];		
$from_date1			=	$details[2]	;	
$total_paid_amount	=	$details[3]	;	
$two_thousand_val	=	$details[4]	;	
$show_two_thousand	=	$details[5]	;	
$five_hundard_val	=	$details[6]	;	
$show_five_hundard	=	$details[7]	;	
$two_hundred_val	=	$details[8]	;	
$show_two_hundred_val=	$details[9]	;	
$hundred_val		=	$details[10];	
$show_hundred_val	=	$details[11];	
$fifty_val			=	$details[12];	
$show_fifty_val		=	$details[13];	
$twenty_val			=	$details[14];	
$show_twenty_val	=	$details[15];	
$ten_val			=	$details[16];	
$show_ten_val		=	$details[17];	
$ten_val_rs			=	$details[18];	
$show_ten_rs		=	$details[19];	
$five_val_rs		=	$details[20];	
$show_five_rs		=	$details[21];	
$two_val_rs			=	$details[22];	
$show_two_rs		=	$details[23];	
$one_val_rs			=	$details[24];	
$show_one_rs		=	$details[25];	
$note_total			=	$details[26];	
$nani_total			=	$details[27];	
$ekun_bharana		=	$details[28];	
$date				=	$details[29];	
$time				=	$details[30];	

}
$si_data=array();						
$si_data=$db->get_collection_agent_profile_details_api($software_users);
if(!empty($si_data))
{
   $si_name=$si_data['employee_name'];
   
}
$from_data = explode("-",$from_date1);
$from_date1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];

$from_data1 = explode("-",$date);
$date = $from_data1[2]."-".$from_data1[1]."-".$from_data1[0];
function getIndianCurrency($number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
}


if(isset($_POST['submit']))
{
		$total_paid_amount	=	$_POST['paid_amount'];
		$two_thousand_val	=	$_POST['two_thousand_val'];
		$show_two_thousand	=	$_POST['show_two_thousand'];
		$five_hundard_val	=	$_POST['five_hundard_val'];
		$show_five_hundard	=	$_POST['show_five_hundard'];
		$two_hundred_val	=	$_POST['two_hundred_val'];
		$show_two_hundred_val=	$_POST['show_two_hundred_val'];
		$hundred_val		=	$_POST['hundred_val'];
		$show_hundred_val	=	$_POST['show_hundred_val'];
		$fifty_val			=	$_POST['fifty_val'];
		$show_fifty_val		=	$_POST['show_fifty_val'];
		$twenty_val			=	$_POST['twenty_val'];
		$show_twenty_val	=	$_POST['show_twenty_val'];
		$ten_val			=	$_POST['ten_val'];
		$show_ten_val		=	$_POST['show_ten_val'];
		$ten_val_rs			=	$_POST['ten_val_rs'];
		$show_ten_rs		=	$_POST['show_ten_rs'];
		$five_val_rs		=	$_POST['five_val_rs'];
		$show_five_rs		=	$_POST['show_five_rs'];
		$two_val_rs			=	$_POST['two_val_rs'];
		$show_two_rs		=	$_POST['show_two_rs'];
		$one_val_rs			=	$_POST['one_val_rs'];
		$show_one_rs		=	$_POST['show_one_rs'];
		$note_total			=	$_POST['note_total'];
		$nani_total			=	$_POST['nani_total'];
		$ekun_bharana		=	$_POST['ekun_bharana'];
		
		
		if($ekun_bharana > $total_paid_amount)
		{
		?>
		<script>
		alert("Please Don't Add More Amount");
		</script>
		<?php
		$flag=1;
		}
		if($ekun_bharana=='')
		{
		?>
		<script>
		alert("Please Don't Create Empty Chalan");
		</script>
		<?php
		$flag=1;
		}
		if($flag==0)
		{
			
				if($db->update_chalan($software_users,$from_date1,$total_paid_amount,$two_thousand_val,$show_two_thousand,$five_hundard_val,$show_five_hundard,$two_hundred_val,$show_two_hundred_val,$hundred_val,$show_hundred_val,$fifty_val,$show_fifty_val,$twenty_val,$show_twenty_val,$ten_val,$show_ten_val,$ten_val_rs,$show_ten_rs,$five_val_rs,$show_five_rs,$two_val_rs,$show_two_rs,$one_val_rs,$show_one_rs,$note_total,$nani_total,$ekun_bharana,$edit_id))
				{
				?>
				<script>
				alert("Chalan Updted Succesfully");
				</script>
				<?php
				}
				else
				{
				?>
				<script>
				alert("Failed To Updted");
				</script>
				<?php
				}
			
		}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Create Chalan</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
			.mid-section
			{
				min-height:800px;
				width:720px;
				margin:auto;
				font-family:cambria;
				margin-top:5px;
				border:1px solid #dfdfdf;
				padding:3px;
			}
			.header-contain
			{
				display:inline-table;
				float:left;
				padding:10px;
			}
			
			h3
			{
				text-align:center;
				text-transform:uppercase;
			}
			.name-data
			{
				font-weight:bold;
				font-size:13px;
				
			}
			
			.footer-data
			{
				text-transform:uppercase;				
				line-height:22px;
				font-size:14px;
				float:right;	
				margin-right:20px;
				text-align:center;
			}
			.label-data
			{
				font-weight:bold;
				font-size:13px;
				display:inline-table;
			}
			table
			{
				font-size:12px;
				padding:1px;
			}
			th
			{
				
				padding:1px;
				text-align:center;
				border:1px solid black;
			}
			td
			{
				padding:1px;
				border:1px solid black;
			}
			.table td, .table th
			{
				padding: .4rem;
				vertical-align: top;
				border: 1px solid black !important;
			}
			.info
			{
				display:inline-table;
				width:105px;
				margin-right:5px;
			}
			@media print {
			  @page { margin: 0; }
			  body { margin: 0.6cm; }
			}
			.mahanagar-palika-logo
			{
				position: absolute;
				left:5px;
				top:11px;
				height:90px;
				width:90px;
				border-radius:40px;
			}
			.left_image
			{
				position: absolute;
				right:5px;
				top:11px;
				height:90px;
				width:90px;
				border-radius:40px;
			}
			.head_pay_sleep
			{
				border-bottom:1px dashed #CCCCCC;
				background-color:#FCFCFC;
				text-align:center;
				margin-bottom:8px;
				padding-top:2px;
				padding-bottom:10px;
				position:relative;
				line-height:24px;
			}
			
		</style>
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
</head>
<body style="background-color:white;">
<form  method="post" action="<?php echo $_SERVER['PHP_SELF']?>"  autocomplete="off" enctype="multipart/form-data">

<div class="mid-section">
	<div class="head_pay_sleep">
		<img src="images/mahanagar-palika-logo.png" class="mahanagar-palika-logo" style="height:70px; width:70px; margin-top:0px;" />
		<h1 style="margin-bottom:10px;margin-top:25px; font-size:32px; margin-left:2px;">सोलापूर महानगरपालिका </h1>
		<div style="font-size:16px;">सोलापूर महानगरपालिकेच्या कोष कार्यालयामध्ये भरलेल्या एकवट रोख रकमेचे चलन </div>
	</div>

	<div style="height:10px;margin-bottom:0px;float:left; margin-top:10px;">
		<div class="label-data">खाते घनकचरा व्यवस्थापन  विभाग आ.नि प्रभाग ४८ </div> <br />
	</div>
	<div style="height:10px;margin-bottom:0px;float:right; margin-top:10px;">
		<div class="label-data" style="margin-top:0px;" >दिनांक  - <?php echo date("d-m-Y"); ?></div>	
	</div>
	
	<div class="data" style="margin:1px;">
		
	<div style="min-height:200px;margin-bottom:0px; width:100%; ">
	<!---TABLE DIV------->
	<div style="min-height:200px;margin-bottom:0px;float:left; margin-top:10px; width:50%; border:1px solid #dfdfdf;">
	<table class="table table-bordered table-hover" >
	<thead>
	
	<th> जमेचे खाते नि विवरण </th>
	<th>रक्कम </th>
	<th>पेमेंट प्रकार  </th>
	</thead>
	<tbody>
	<?php
	$penalty_data=$db->get_penalty_data_by_si_and_date($software_users,$from_date1);
	$total_amount	=	0;
	if(!empty($penalty_data))
	{
		foreach($penalty_data as $record)
		{
			$id					=	$record[0];
			$image1				=	$record[1];
			$image2				=	$record[2];
			$image3				=	$record[3];
			$image4				=	$record[4];
			$name				=	$record[5];
			$address			=	$record[6];
			$mobile_no			=	$record[7];
			$penalty_for		=	$record[8];
			$penalty_amount		=	$record[9];
			$status				=	$record[10];
			$payment_method		=	$record[11];
			$payment_description=	$record[12];
			$note				=	$record[13];
			$user_id			=	$record[14];
			$living_address		=	$record[17];
			$random_string		=	$record[18];	
			//
			$si_data=array();						
			$si_data=$db->get_collection_agent_profile_details_api($user_id);
			if(!empty($si_data))
			{
			   $si_name=$si_data['employee_name'];
			   
			}
			$total_amount=$total_amount+$penalty_amount;
			
			
	?>
	<tr>
	<td>
	<?php
	
	if($penalty_for!='')
	{
	$pdata=explode(",",$penalty_for);
	$count=count($pdata);
	
	for($i=0;$i<$count;$i++)
	{
		
		$res_penalty_name="";
		$res_penalty_name=$db->get_penalty_name($pdata[$i]);
		$res_penalty_amount=$db->get_penalty_amount($pdata[$i]);
	?>
	 <span> <?php echo$res_penalty_name; ?>-<span style="margin-left:20px;"><?php echo $res_penalty_amount; ?></span></span>  <br /> 
	<?php
		
	}
	}
	?>
	</td>
	<td><?php echo $penalty_amount; ?></td>
	<td><?php echo $payment_method; ?></td>
	</tr>
	<?php
		}
	?>
	<tr style="font-weight:bold;">
	<td>एकूण </td>
	<td><?php echo $total_amount; ?></td>
	<td></td>
	</tr>
	<?php
	}
	?>
	</tbody>
	</table>
	
	 <input type="hidden" name="paid_amount" value="<?php echo $total_amount; ?>">
	 <div  style="100%;">अक्षरी  - <b><?php  echo getIndianCurrency($total_amount)." केवळ "; ?></b> <br />मिळाले . </div>
	<div  style="100%;">बिनचूक आहे .</div>
	<div  style="100%;">रक्कम स्वीकारून पावती द्यावी .</div>
	<div  style="100%;">दिनांक : <?php echo date("d-m-Y"); ?></div>
	<br />
	<div  style="50%; display:inline-table; float:left;">लेखनिक  </div>
	<div  style="50%; display:inline-table; float:right;">खात्याचे अधिकारी   </div>
	<br />
	<div  style="100%;">वरील प्रमाणे रक्कम मिळाली .</div>
	<br />
	<div  style="100%;">वर जमा केली असे दिनांक :<?php echo date("d-m-Y"); ?></div>
	</div>
	
	<!---RIGHT DIV---->
	<div style="min-height:200px;margin-bottom:0px;float:right; margin-top:10px; width:50%; border:1px solid #dfdfdf;">
	
	<table class="table table-bordered table-hover" >
		<thead>
		<th>चलन (कोटी ) संख्या  </th>
		<th>रुपये  </th>
		
	</thead>
	<tbody>
		<tr>
		<td><span style="width:70px; text-align:center !important;">2000 X </span> <input type="number"  style="width:60px;" id="two_thousand_val" name="two_thousand_val" value="<?php echo $two_thousand_val; ?>" ></td>
		<input type="hidden" name="two_thousand" value="2000" id="two_thousand">
		<td><input type="number"  name="show_two_thousand" id="show_two_thousand"   value="<?php echo $show_two_thousand; ?>"style="width:60px;" readonly ></td>
		</tr>
		
		<tr>
		<td><span style="width:70px; text-align:center !important;">500 X </span><input type="number" 
		id="five_hundard_val" name="five_hundard_val" style="width:60px;"  value="<?php echo $five_hundard_val; ?>" ></td>
		<input type="hidden" id="five_hundard" value="500" >
		<td><input type="number" id="show_five_hundard" name="show_five_hundard"  style="width:60px;"  value="<?php echo $show_five_hundard; ?>"  readonly ></td>
		</tr>
		<tr>
		<td><span style="width:70px; text-align:center !important;">200 X </span><input type="number" 
		name="two_hundred_val"  id="two_hundred_val" style="width:60px;" value="<?php echo $two_hundred_val; ?>" ></td>
		<input type="hidden" id="two_hundred" value="200" >
		<td><input type="number" id="show_two_hundred_val" name="show_two_hundred_val" value="<?php echo $show_two_hundred_val; ?>"  style="width:60px;" readonly ></td>
		</tr>
		<tr>
		<td><span style="width:70px; text-align:center !important;">100 X </span><input type="number" 
		name="hundred_val"  id="hundred_val" style="width:60px;" value="<?php echo $hundred_val; ?>"></td>
		<input type="hidden" id="hundred" value="100" >
		<td><input type="number" id="show_hundred_val" name="show_hundred_val" value="<?php echo $show_hundred_val; ?>" style="width:60px;" readonly ></td>
		</tr>
		<tr>
		<td><span style="width:70px; text-align:center !important;">50 X </span><input type="number" name="fifty_val"  id="fifty_val" style="width:60px;" value="<?php echo $fifty_val; ?>" ></td>
		<input type="hidden" id="fifty" value="50" >
		<td><input type="number" id="show_fifty_val" name="show_fifty_val"  style="width:60px;" value="<?php echo $show_fifty_val; ?>"  readonly ></td>
		</tr>
		<tr>
		<td><span style="width:70px; text-align:center !important;">20 X </span><input type="number" name="twenty_val" id="twenty_val" style="width:60px;" value="<?php echo $twenty_val; ?>" ></td>
		<input type="hidden" id="twenty" value="20" >
		<td><input type="number" id="show_twenty_val" name="show_twenty_val"  style="width:60px;" value="<?php echo $show_twenty_val; ?>" readonly ></td>
		</tr>
		<tr>
		<td><span style="width:70px; text-align:center !important;">10 X </span><input type="number" name="ten_val" id="ten_val" style="width:60px;"  value="<?php echo $ten_val; ?>"  ></td>
		<input type="hidden" id="ten" value="10" >
		<td><input type="number" id="show_ten_val" name="show_ten_val"  style="width:60px;"  value="<?php echo $show_ten_val; ?>"  readonly ></td>
		</tr>
		<!--<tr>
		<td><span style="width:70px; text-align:center !important;">5 X </span><input type="number" name="five" style="width:60px;"></td>
		<td></td>
		</tr>
		<tr>
		<td><span style="width:70px; text-align:center !important;">2 X </span><input type="number" name="two" style="width:60px;"></td>
		<td></td>
		</tr>-->
		<tr>
		<td>एकूण </td>
		<td><input type="number" name="note_total" id="note_total" value="<?php echo $note_total; ?>"  style="width:60px;" readonly ></td>
		</tr>
		<tr>
		<td colspan="2" style="font-weight:bold;"> 
		नाणी
		</td>
		</tr>
		<tr>
		
		<td>दहा रुपये<input type="number" name="ten_val_rs" id="ten_val_rs" style="width:60px;" value="<?php echo $ten_val_rs; ?>" ></td>
		<input type="hidden" id="ten_rs" value="10" >
		<td><input type="number" name="show_ten_rs" id="show_ten_rs"  value="<?php echo $show_ten_rs; ?>" style="width:60px;" readonly ></td>
		</tr>
		<tr>
		<td>पाच  रुपये   <input type="number" name="five_val_rs" id="five_val_rs" style="width:60px;" value="<?php echo $five_val_rs; ?>" ></td>
		<input type="hidden" id="five_rs" value="5" >
		<td><input type="number" name="show_five_rs" id="show_five_rs"  style="width:60px;" value="<?php echo $show_five_rs; ?>"  readonly ></td>
		</tr>
		<tr>
		<td>दोन  रुपये  <input type="number" name="two_val_rs" id="two_val_rs" style="width:60px;" value="<?php echo $two_val_rs; ?>" > </td>
		<input type="hidden" id="two_rs" value="2" >
		<td><input type="number" name="show_two_rs" id="show_two_rs" style="width:60px;" readonly value="<?php echo $show_two_rs; ?>"  ></td>
		</tr>
		<tr>
		<td>एक  रुपये <input type="number" name="one_val_rs" id="one_val_rs" style="width:60px;" value="<?php echo $one_val_rs; ?>" > </td>
		<input type="hidden" id="one_rs" value="1" >
		<td><input type="number" name="show_one_rs" id="show_one_rs" style="width:60px;" readonly value="<?php echo $show_one_rs; ?>" ></td>
		</tr>
		
		<!--<tr>
		<td> 1). चेकने जमा </td>
		<td><input type="number" name="checkne_jama" style="width:100px;"></td>
		</tr>
		<tr>
		<td>2). बँकेत परस्पर जमा </td>
		<td><input type="number" name="banket_parsper_jama" style="width:100px;"></td>
		</tr>
		<tr>
		<td>3). अनामत पैकी जमा </td>
		<td><input type="number" name="anamat_peki_jama" style="width:100px;"></td>
		</tr>-->
		<tr>
		<td>एकूण  </td>
		<td><input type="number" name="nani_total" id="nani_total" style="width:60px;" readonly value="<?php echo $nani_total; ?>"> </td>
		</tr>
		<tr>
		<td>एकूण  भरणा </td>
		<td><input type="number" name="ekun_bharana" id="ekun_bharana" style="width:100px;" value="<?php echo $ekun_bharana; ?>"  readonly></td>
		</tr>
	</tbody>
	</table>
	<p class="footer-data"><b>नगदी </b><br />
	<b>सोलापूर महानगरपालिका </b></p>
	</div>
	<!---END RIGHT DIV--->
	<!---END TABLE DIV--->
	
	</div>
	
	<!--<br />
	 <div class="info">इतर </div> - <b><?php echo $note; ?></b><br />
	  <div class="info">रु </div> - <b><?php echo $penalty_amount; ?></b><br />
	 <div  style="100%;">रक्कम रु अक्षरी   - <b><?php  echo getIndianCurrency($penalty_amount)." Only"; ?></b> <br />मिळाले . </div>
	</div>
	<br /><br />
			<p class="footer-data"><b>सोलापूर महानगरपालिका </b><br />-->
			
	</div>
	<center>
	<br />
	<input type="submit" value="UPDATE CHALAN" class="btn btn-primary" style="font-weight:bold; margin-top:100px;" name="submit">
	</center>	
</div>
</form>
<script src="js/jquery.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
			
$("#two_thousand_val").keyup(function(){
var a = $("#two_thousand").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_two_thousand").val(res);
cal();
final_cal();
});

$("#five_hundard_val").keyup(function(){

var aa = $("#five_hundard").val();
var bb = $(this).val();
var resb	=	parseInt(aa) * parseInt(bb);
$("#show_five_hundard").val(resb);
cal();
final_cal();
});

$("#two_hundred_val").keyup(function(){
var a = $("#two_hundred").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_two_hundred_val").val(res);
cal();
final_cal();
});

$("#hundred_val").keyup(function(){
var a = $("#hundred").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_hundred_val").val(res);
cal();
final_cal();
});

$("#fifty_val").keyup(function(){
var a = $("#fifty").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_fifty_val").val(res);
cal();
final_cal();
});

$("#twenty_val").keyup(function(){
var a = $("#twenty").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_twenty_val").val(res);
cal();
final_cal();
});

$("#ten_val").keyup(function(){
var a = $("#ten").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_ten_val").val(res);
cal();
final_cal();
});

$("#ten_val_rs").keyup(function(){
var a = $("#ten_rs").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_ten_rs").val(res);
nani_calculation();
final_cal();
});

$("#five_val_rs").keyup(function(){
var a = $("#five_rs").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_five_rs").val(res);
nani_calculation();
final_cal();
});

$("#two_val_rs").keyup(function(){
var a = $("#two_rs").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_two_rs").val(res);
nani_calculation();
final_cal();
});

$("#one_val_rs").keyup(function(){
var a = $("#one_rs").val();
var b = $(this).val();
var res	=	parseInt(a) * parseInt(b);
$("#show_one_rs").val(res);
nani_calculation();
final_cal();
});

function cal()
{
	
	var a = $("#show_two_thousand").val();
	if(a=="")
	{
		a = 0;
	}
	var b = $("#show_five_hundard").val();
	if(b=="")
	{
		b = 0;
	}
	var c = $("#show_two_hundred_val").val();
	if(c=="")
	{
		c = 0;
	}
	var d = $("#show_hundred_val").val();
	if(d=="")
	{
		d = 0;
	}
	var e = $("#show_fifty_val").val();
	if(e=="")
	{
		e = 0;
	}
	var f = $("#show_twenty_val").val();
	if(f=="")
	{
		f = 0;
	}
	var g = $("#show_ten_val").val();
	if(g=="")
	{
		g = 0;
	}
	var answer	=	 parseInt(a) + parseInt(b) + parseInt(c) + parseInt(d) + parseInt(e) + parseInt(f) + parseInt(g);
	 $("#note_total").val(answer);
}

function nani_calculation()
{
	
	var a = $("#show_ten_rs").val();
	if(a=="")
	{
		a = 0;
	}
	var b = $("#show_five_rs").val();
	if(b=="")
	{
		b = 0;
	}
	var c = $("#show_two_rs").val();
	if(c=="")
	{
		c = 0;
	}
	var d = $("#show_one_rs").val();
	if(d=="")
	{
		d = 0;
	}
	
	var answer	=	 parseInt(a) + parseInt(b) + parseInt(c) + parseInt(d);
	 $("#nani_total").val(answer);
}

function final_cal()
{
	var c = $("#note_total").val();
	if(c=="")
	{
		c = 0;
	}
	var d = $("#nani_total").val();
	if(d=="")
	{
		d = 0;
	}
	var answer	=	parseInt(c) + parseInt(d);
	 $("#ekun_bharana").val(answer);
}
});
</script>
	</body>
</html>