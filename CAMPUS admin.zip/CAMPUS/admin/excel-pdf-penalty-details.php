<?php 
require_once('lib/functions.php');

$db		=	new login_function();
ob_start();
if(isset($_SESSION['to_date1'])  AND isset($_SESSION['from_date1']))
{
			$from_date1			=$_SESSION['from_date1'];
			$to_date1       	=$_SESSION['to_date1'];
			$software_data     =$_SESSION['software_users'];
			$category_data   		=$_SESSION['category'];
			$status     		=$_SESSION['status'];
			$option     		=$_SESSION['option'];


}
$res_category="";
/*if($category!='all')
{
	$res_category=$db->get_penalty_name($category);
}
else
{
	$res_category=$category;
}*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>EXCEL PDF</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
	 <script src="js/jquery.min.js"></script>
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th
{
	text-align:center;
	border:1px solid black;
	font-size:12px;
}
table,td
{
	text-align:left;
	border:1px solid black;
	font-size:12px;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 300px;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
.main_head
{
	width:1200px;
	margin:auto;
	font-size:14px;
	
	padding:1px;
	padding-top:0px;
	box-shadow:0px 0px 5px 1px #DFDFDF;
	border:1px solid #CCCCCC;
}	
.main_head>h1,h2,h4,h6
{
	text-align:center;
	margin:0px;
}
.sub_head
{
	border-bottom:1px dashed #CCCCCC;
	background-color:#FCFCFC;
	text-align:center;
	margin-bottom:8px;
	padding-top:2px;
	padding-bottom:10px;
	position:relative;
	line-height:40px;
}
.logo
{
	position: absolute;
	left:50px;
	top:11px;
	height:70px;
	width:70px;
	border-radius:40px;
}
body
{
	font-family:cambria;
	background-color:white;
}
label
{
	text-align:left;
	font-size:16px;
	font-weight:bold;
	margin:4px;
}
.sub_txtline
{
	font-size:14px;
	font-weight:bold;
	line-height:25px;
	font-family:cambria;
	font-weight:bold;
}
h6
{
	font-size:16px !important;
}
thead		
{
	background-color:#efefef;
	font-size:14px;
	font-weight:bold;
	
}	
.table-bordered td, .table-bordered th {
    border: 1px solid black;
	-webkit-print-color-adjust: exact; 
}
.link
{
	background-color:#208F86 !important;
	font-size:17px;
	font-family:cambria;
	color:#FFFFFF;
	padding:10px;
	border-radius:10px;
	font-weight:bold;
	border:1px solid #666;
	margin-top:15px;
}
.table td, .table th {
    padding: .0rem;
    vertical-align: top;
    border-top: 1px solid #e9ecef;
}
@media print 
{
			
	@page 
	{
		 //size: Landscape;   /* auto is the initial value */
		 margin: 1%;
		
	 }
}
</style>
<body style="background-color:white;">
<div class="main_head">

 <div class="sub_head">
 <div class="head_pay_sleep">
<img src="images/mahanagar-palika-logo.png" class="mahanagar-palika-logo" style="height:70px; width:70px; margin-top:0px;float:left;" />
<h1 style="margin-bottom:10px;margin-top:25px; font-size:32px;">सोलापूर महानगरपालिका</h1>
</div>
<div class="sub_txtline" style="font-size:14px; line-height:25px; font-family:cambria; font-weight:bold;"><center>Print Date  : <?php echo date("d-m-Y"); ?></center></div>
</div>

<!----------------TABLE--------------------------->
<div class="sub_txtline" style="font-size:14px; line-height:25px; font-family:cambria; font-weight:bold;"><center>From Date  : <?php echo $from_date1; ?> To <?php echo $to_date1; ?> , Category:<?php echo $res_category; ?> ,  Status:<?php echo $status; ?></center></div>

<table class="table table-bordered table-hover" id="example" >
	<thead class="thead-default thead-lg">
	<?php
	if($option==2)
	{
	?>
	<tr>
		<th width="1">Sr</th>
		<th width="5">Re No</th>
		<th width="120">SI Details</th></th>
		<th width="100">Name</th>
		<th width="15">Living Address</th>
		<th width="10">Fine Captured Location</th>
		<th width="10">Mobile No</th>
		<th width="100">Penalty For</th>
		<th width="5">Penalty Amt</th>
		<th width="5">Pyt Status</th>
		<th width="4">Pyt Mtd</th>
		<th width="10">Pyt Des</th>
		<th width="10">Note</th>
		<th width="5">Date/Time</th>
		
	</tr>
	<?php
	}
	else
	{
	?>
	<tr>
		<th>Sr.No</th>
		<th>Re No</th>
		<th>SI Details</th></th>
		<th>Name</th>
		<th>Living Address</th>
		<th>Fine Captured Location</th>
		<th>Mobile No</th>
		<th>Penalty For</th>
		<th>Penalty Amount</th>
		<th>Pyt Status</th>
		<th>Pyt Method</th>
		<th>Pyt Description</th>
		<th>Note</th>
		<th>Date</th>
		<th>Time</th>
	</tr>

	<?php
	}
	?>
	</thead>
	<tbody>
	<?php
		$from_data = explode("-",$from_date1);
		$from_data1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];
	
		$to_data = explode("-",$to_date1);
		$to_data1 = $to_data[2]."-".$to_data[1]."-".$to_data[0];
		
		$data	=	array();
		$data	=	$db->get_all_penalty_details_report($from_data1,$to_data1,$software_data,$category_data,$status);
		
	
		if(!empty($data))
			{
				$total_amt=0;
				$counter =0;
				foreach($data as $record)
				{
					$id					=	$record[0];
					$image1				=	$record[1];
					$image2				=	$record[2];
					$image3				=	$record[3];
					$image4				=	$record[4];
					$name				=	$record[5];
					$address			=	$record[6];
					$mobile_no			=	$record[7];
					$penalty_for		=	$record[8];
					$penalty_amount		=	$record[9];
					$status				=	$record[10];
					$payment_method		=	$record[11];
					$payment_description=	$record[12];
					$note				=	$record[13];
					$user_id			=	$record[14];
					$living_address		=	$record[17];
					$random_string		=	$record[18];
					$res_date		    =	$record[15];
					$res_time	    	=	$record[16];
					$from_data1 = explode("-",$res_date);
		            $res_date = $from_data1[2]."-".$from_data1[1]."-".$from_data1[0];
					$total_amt=$total_amt+$penalty_amount;						
						//$res_penalty_for=$db->get_penalty_name($penalty_for);
					$si_data=array();						
					$si_data=$db->get_collection_agent_profile_details_api($user_id);
					if(!empty($si_data))
					{
					   $si_name=$si_data['employee_name'];
					   
					}	

			?>
			<tr> 
				<td style="text-align:center;"><?php echo $counter+1; ?></td>
				<td style="text-align:center;"><?php echo $id; ?></td>
				<td>Name:<?php echo $si_name; ?> <br /> User Id: <?php echo $user_id;?></td>
                <td><span style="font-weight:bold;"></span><?php echo $name; ?></td>
				<td><span style="font-weight:bold;"></span><?php echo $living_address; ?></td>
				<td><span style="font-weight:bold;"></span><?php echo $address; ?></td>
				<td><span style="font-weight:bold;"></span><?php echo $mobile_no; ?></td>
				<td><span style="font-weight:bold;"></span>
				<?php
				if($penalty_for!='')
				{
					$pdata=explode(",",$penalty_for);
					$count=count($pdata);
					$j=1;
					for($i=0;$i<$count;$i++)
					{
						
						$res_penalty_name="";
						$res_penalty_name=$db->get_penalty_name($pdata[$i]);
						//$res_penalty_amount=$db->get_penalty_amount($pdata[$i]);
					?>
					<span>  <?php echo $j.")".$res_penalty_name; ?></span> <br /> 
					<?php
						$j++;
					}
				}
				?>
				</td>
				<td style="text-align:center;"><span style="font-weight:bold;"></span><?php echo $penalty_amount; ?></td>
				<td><span style="font-weight:bold;"></span><?php echo $status; ?></td>
				<td><span style="font-weight:bold;"></span><?php echo $payment_method; ?></td>
				<td><span style="font-weight:bold;"></span><?php echo $payment_description; ?></td>
				<td><span style="font-weight:bold;"></span><?php echo $note; ?></td>
				<td><span style="font-weight:bold;"></span><?php echo $res_date; ?> <br /> <?php echo $res_time; ?> </td>
				

			</tr> 			
			<?php
					$counter++;
				}
			
			?>
			<tr>
			<td colspan="8">Total Amount </td>
			<td style="text-align:center; font-weight:bold;"> &#8377 <?php echo $total_amt; ?></td>
			<td colspan="6"></td>

			</tr>
			<?php
			}
			else
			{
			?>
			<td colspan="14" style="text-align:center;">Penalty Details Not Available...</td>
			<?php
			}
		   ?>
		</tr> 
	</tbody> 
</table> 
</div>
<!----------------END TABLE------------------------->	
<?php
if($option==1)
{
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename= penalty-report.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	ob_end_flush();
}
else
{
?>
	<script>
	window.print();
	</script>
<?php
}
?>

</body>

</html>
