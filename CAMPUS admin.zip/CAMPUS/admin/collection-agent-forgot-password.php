<?php
require_once('../admin/lib/functions.php');
$db		=	new login_function();

if(isset($_POST['mobile_no']))
{
	$mobile_no				= $_POST['mobile_no'];
		
	$db_password =	$db->get_collection_password_mobile_password($mobile_no);
	if($db_password=="")
	{
		$response["status"] = "0";
		$response["message"] = "User is not registered with us";
	}
	else
	{	/*
		 //Send Message
			$user_message	=	"DPBOSS - Your User Id ".$mobile_no.",Login Password is ".$db_password;
												
			//Send Message
			$forwardURL = 'http://sms.bulksmsind.in/sendSMS?'.http_build_query(array(
    		'username' => "mehediali",
    		'sendername' => "DPBOSS",
    		'smstype' => "TRANS",
    		'numbers' => $mobile_no,
    		'message' => $user_message,
    		'apikey' => "1b4a8d6a-5760-40c7-b7eb-e31119e19cad",
        	));

			$curl = curl_init();
			curl_setopt ($curl, CURLOPT_URL, $forwardURL);
			
			curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
			
			curl_exec ($curl);
			curl_close ($curl);
            */
            $response["status"] = "1";
			$response["message"] = "Password sent to your registered number";
            
		
	}
	
	

}//END
echo json_encode($response);
?>