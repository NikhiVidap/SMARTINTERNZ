<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}

$success			=0;

if(isset($_GET['del']))
{
	$del	=	$_GET['del'];
	
	if($db->delete_expenses($del))
	{
		$success	=	3;
	}
	
}
if(isset($_GET['double']))
{
	$double	=	$_GET['double'];
	$db->update_penalty_status_as_double($double);
}

if(isset($_GET['not_double']))
{
	$not_double	=	$_GET['not_double'];
	$db->update_penalty_status_as_not_double($not_double);
}

if(isset($_GET['paid']))
{
	$paid	=	$_GET['paid'];
	$db->update_penalty_status_as_paid($paid);
}

if(isset($_GET['unpaid']))
{
	$unpaid	=	$_GET['unpaid'];
	$db->update_penalty_status_as_not_unpaid($unpaid);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $project_title; ?></title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th
{
	text-align:center;
	text-transform:uppercase;
}
table,td
{
	text-align:left;
	text-transform:uppercase;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 700px;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
</style>
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
</head>
<body class="fixed-navbar">

<div class="page-wrapper" style="height:5000px;">

<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>

<div class="content-wrapper">
<div class="page-content fade-in-up">
<div class="ibox" style="border-radius:5px; padding:7px;">
<?php
$from_date1	=	date("d-m-Y");
$to_date1	=	date("d-m-Y");
$software_users	=	"";
$category		=	"";
$status			=	"";
$category_data	=	"";
$software_data	=	"";
$software_data_new="";
$category_data_new="";
if(isset($_POST['search']))
{
	$from_date1		= $_POST['from_date1'];
	$to_date1       = $_POST['to_date1'];
	//$software_users = $_POST['software_users'];
	//$category 		= $_POST['category'];
	$status 		= $_POST['status'];
	
	if(!empty($_POST['software_users'])) {
    foreach($_POST['software_users'] as $software) {
			if($software_data=="")
			{
				$software_data="'".$software."'";
				$software_data_new[]=$software;
			}
			else
			{
				 $software_data	=$software_data.",'".$software."'";
				$software_data_new[]=$software;
			}
           
		}
	}
	else
	{
		$software_data="all";
	}
	if(!empty($_POST['category'])) 
	{
    foreach($_POST['category'] as $cat) {
		if($category_data=="")
			{
				$category_data="'".$cat."'";
				$category_data_new[]=$cat;
			}
			else
			{
				 $category_data	=$category_data.",'".$cat."'";
				$category_data_new[]=$cat;
			}
           
		}
	}
	else
	{
		$category_data="all";
	}
	
	
	
	
	
	$_SESSION['to_date1']		=	$to_date1;
	$_SESSION['from_date1']		=	$from_date1;
	$_SESSION['software_users']	=	$software_data;
	$_SESSION['category']		=	$category_data;
	$_SESSION['status']			=	$status;
	
}
if(isset($_POST['pdf']))
{
	$from_date1		= $_POST['from_date1'];
	$to_date1       = $_POST['to_date1'];
	//$software_users = $_POST['software_users'];
	//$category 		= $_POST['category'];
	$status 		= $_POST['status'];
	if(!empty($_POST['software_users'])) {
    foreach($_POST['software_users'] as $software) {
			if($software_data=="")
			{
				$software_data="'".$software."'";
			}
			else
			{
				 $software_data	=$software_data.",'".$software."'";

			}
           
		}
	}
	else
	{
		$software_data="all";
	}
	if(!empty($_POST['category'])) 
	{
    foreach($_POST['category'] as $cat) {
		if($category_data=="")
			{
				$category_data="'".$cat."'";
			}
			else
			{
				 $category_data	=$category_data.",'".$cat."'";

			}
           
		}
	}
	else
	{
		$category_data="all";
	}
	$_SESSION['to_date1']		=	$to_date1;
	$_SESSION['from_date1']		=	$from_date1;
	$_SESSION['software_users']	=	$software_data;
	$_SESSION['category']		=	$category_data;
	$_SESSION['status']			=	$status;
	$_SESSION['option']			=	2;
	//header("location:excel-pdf-penalty-details.php" , '_blank');
?>
<script>
 //var win = window.open("excel-pdf-penalty-details.php", '_blank');
  //win.focus();
window.location="excel-pdf-penalty-details.php";
</script>
<?php
	//header("location:excel-pdf-penalty-details.php");
	
}
if(isset($_POST['excel']))
{
	$from_date1		= $_POST['from_date1'];
	$to_date1       = $_POST['to_date1'];
	//$software_users = $_POST['software_users'];
	//$category 		= $_POST['category'];
	$status 		= $_POST['status'];
	if(!empty($_POST['software_users'])) {
    foreach($_POST['software_users'] as $software) {
			if($software_data=="")
			{
				$software_data="'".$software."'";
			}
			else
			{
				 $software_data	=$software_data.",'".$software."'";

			}
           
		}
	}
	else
	{
		$software_data="all";
	}
	if(!empty($_POST['category'])) 
	{
    foreach($_POST['category'] as $cat) {
		if($category_data=="")
			{
				$category_data="'".$cat."'";
			}
			else
			{
				 $category_data	=$category_data.",'".$cat."'";

			}
           
		}
	}
	else
	{
		$category_data="all";
	}
	$_SESSION['to_date1']		=	$to_date1;
	$_SESSION['from_date1']		=	$from_date1;
	$_SESSION['software_users']	=	$software_data;
	$_SESSION['category']		=	$category_data;
	$_SESSION['status']			=	$status;
	$_SESSION['option']		   =	1;

?>
<script>
var win = window.open("excel-pdf-penalty-details.php", '_blank');
 // win.focus();
//window.location="excel-pdf-penalty-details.php";
</script>
<?php
	
}
if(isset($_SESSION['to_date1'])  AND isset($_SESSION['from_date1']))
{
			$from_date1			=$_SESSION['from_date1'];
			$to_date1       	=$_SESSION['to_date1'];
			$software_data     =$_SESSION['software_users'];
			$category_data   	=$_SESSION['category'];
			$status     		=$_SESSION['status'];
			

}	
//print_r($category_data_new);
?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" autocomplete="off">
<span style="color:red;">NOTE:Hold down the Ctrl button to select multiple options.</span>
	<div class="col-lg-12" style="font-size:16px;padding:10px;">
		
		<div class="col-lg-4"  style="display:inline-table; ">
		<label class="form-group mb-4 set-row"><b>Software User</b></label>
		<div class="input-group-icon input-group-icon-left  set-row">
		<select class="form-control" name="software_users[]" multiple style="height:200px;">
		<option value="all" <?php if($software_data_new!=''){ if(in_array("all",$software_data_new)) { ?> Selected <?php } } ?>>ALL</option>	
		<?php

		$data	=	array();
		$data	=	$db->get_all_collection_agent_details();

		if(!empty($data))
		{
			$counter =0;
			foreach($data as $record)
			{
				$id				=	$record[0];
				$employee_code	=	$record[1];
				$res_name		=	$record[2];
				$user_id		=	$record[5];

		?>
		<option value="<?php echo $user_id; ?>" <?php if($software_data_new!=''){ if(in_array($user_id,$software_data_new)) { ?> Selected <?php } } ?>><?php echo $res_name; ?></option>	
		<?php
			}
		}
		?>
		</select>
		</div>
		</div>
		<div class="col-lg-6"  style="display:inline-table;">
			<label class="form-group mb-4 set-row"><b>Category</b></label>
			<div class="input-group-icon input-group-icon-left  set-row">
			<select class="form-control" name="category[]" multiple style="height:200px;">
			<option value="all" <?php if($category_data_new!=''){ if(in_array("all",$category_data_new)) { ?> Selected <?php } } ?>>ALL</option>	
			<?php

			$data1	=	array();
			$data1	=	$db->get_all_penalty_category_details();
			
			if(!empty($data1))
				{
					$counter1 =0;
					foreach($data1 as $record1)
					{
						$id					=	$record1[0];
						$res_title			=	$record1[1];
				

			?>
			 <option value="<?php echo $id; ?>" <?php if($category_data_new!=''){if(in_array($id,$category_data_new)) { ?> Selected <?php } } ?>><?php echo $res_title; ?></option>
			<?php
				}
			}
			?>
			</select>
			</div>
			</div>
		<div class="col-lg-3" style="display:inline-table;">
			From date:
			<input placeholder="Select From date" type="text" name="from_date1" id="from_date" value=<?php echo $from_date1; ?> class="form-control">
		</div>
		
		<div class="col-lg-3"  style="display:inline-table;">
			To date:
			<input placeholder="Select To date" value=<?php echo $to_date1; ?>  type="text" name="to_date1" id="to_date" class="form-control">
		</div>	
		<div class="col-lg-2"  style="display:inline-table;">
			<label class="form-group mb-4 set-row"><b>Status</b></label>
			<div class="input-group-icon input-group-icon-left  set-row">
			<select class="form-control" name="status" >
			<option value="all" <?php if($status=="all") { ?> Selected <?php } ?>>ALL</option>	
			<option value="pending" <?php if($status=="pending") { ?> Selected <?php } ?>>Pending</option>	
			<option value="paid" <?php if($status=="paid") { ?> Selected <?php } ?>>Paid</option>	
			</select>
			</div>
			
			</div>
	
		<!-- end of colg-2.5-->
		<center>
		<div class="col-lg-1" style="display:inline-table;width:100%;margin:auto;">
		<label></label>
		<br />
		<input class="btn btn-success btn-block"  type="submit" name="search"  value="SEARCH" style="background-color:#24B8E3;color:white;margin-top:-5px;" />
		</div><!-- end of colg-2.6-->
		<div class="col-lg-1" style="display:inline-table;width:100%;margin:auto;">
			<label></label>
			<input class="btn btn-warning btn-block"  type="submit" name="excel"  value="EXCEL" style="color:white;margin-top:-5px;" />
		</div>
		<div class="col-lg-1" style="display:inline-table;width:100%;margin:auto;">
			<label></label>
			<input class="btn btn-danger btn-block"  type="submit" name="pdf"  value="PDF" style="color:white;margin-top:-5px;" />
		</div>
		 </center>
	</div><!-- end of colg-2.6-->
</form>
</div>
</div>
	
<div class="page-content fade-in-up" style="height:5000px !important;">
<div class="ibox" style="border-radius:5px; padding:7px; height:5000px !important;">

<div class="ibox-body" style="padding:7px; padding-top:0px;">
	<div class="ibox-head">
		<div class="ibox-title">Penalty Report</div>
	</div>
</div>
<div class="flexbox mb-4" style="margin-left:20px;margin-right:20px;">
		<div class="input-group-icon input-group-icon-left mr-3">
			<span class="input-icon input-icon-right font-16"><i class="fas fa-search"></i></span>
			<input class="form-control form-control-rounded form-control-solid" id="key-search" type="text" placeholder="Search ...">
		</div>
</div>
<div class="table-wrapper-scroll-y my-custom-scrollbar" >

<div class="table-responsive" id="table_response" style="min-height:1000px; width:100%; overflow:auto;">
<table class="table table-bordered table-hover" id="example" >
	<thead class="thead-default thead-lg">
		<tr>
			<th>Sr.No</th>
			<th>Re No</th>
			<th>SI Details</th></th>
			<th>Penalty Details</th>
			<th>Double Status</th>
			<th>Payment Status</th>
			<th>Payment Action</th>
			<th>Action</th>
			<th>Edit</th>
			<th>View</th> 
			<th>Attachment 1</th> 
			<th>Attachment 2</th> 
			<th>Attachment 3</th> 
			<th>Attachment 4</th> 
			
		</tr>
	</thead>
	<tbody>
	<?php
		$from_data = explode("-",$from_date1);
		$from_data1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];
	
		$to_data = explode("-",$to_date1);
		$to_data1 = $to_data[2]."-".$to_data[1]."-".$to_data[0];
		
		$data	=	array();
		$data	=	$db->get_all_penalty_details_report($from_data1,$to_data1,$software_data,$category_data,$status);
		$si_name="";
	
		if(!empty($data))
			{
				$total_amt=0;
				$counter =0;
				foreach($data as $record)
				{
					$id					=	$record[0];
					$image1				=	$record[1];
					$image2				=	$record[2];
					$image3				=	$record[3];
					$image4				=	$record[4];
					$name				=	$record[5];
					$address			=	$record[6];
					$mobile_no			=	$record[7];
					$penalty_for		=	$record[8];
					$penalty_amount		=	$record[9];
					$status				=	$record[10];
					$payment_method		=	$record[11];
					$payment_description=	$record[12];
					$note				=	$record[13];
					$user_id			=	$record[14];
					$living_address		=	$record[17];
					$random_string		=	$record[18];
					$double_status		=	$record[19];						
					//
					$si_data=array();						
					$si_data=$db->get_collection_agent_profile_details_api($user_id);
					if(!empty($si_data))
					{
					   $si_name=$si_data['employee_name'];
					   
					}
			?>
			<tr> 
				<td style="text-align:center;"><?php echo $counter+1; ?></td>
					<td><?php echo $id; ?></td>
				<td><span style="font-weight:bold;"> SI Name </span>:<?php echo $si_name; ?> <br /> <span style="font-weight:bold;"> User Id: </span> <?php echo $user_id;?></td>
				<td><span style="font-weight:bold;">Name:</span><?php echo $name; ?><br/>
				<span style="font-weight:bold;">Fine Captured Location:</span><?php echo $address; ?><br/>
				<span style="font-weight:bold;">Mobile No:</span><?php echo $mobile_no; ?><br/>
				<span style="font-weight:bold;">Penalty For:
				</span>
				<?php
				if($penalty_for!='')
				{
					$pdata=explode(",",$penalty_for);
					$count=count($pdata);
					$j=1;
					for($i=0;$i<$count;$i++)
					{
						
						$res_penalty_name="";
						$res_penalty_name=$db->get_penalty_name($pdata[$i]);
						//$res_penalty_amount=$db->get_penalty_amount($pdata[$i]);
					?>
					<span>  <?php echo $j.")".$res_penalty_name; ?></span> <br /> 
					<?php
						$j++;
					}
				}
				?>
				<br/>
				<span style="font-weight:bold;">Penalty Amount:</span><?php echo $penalty_amount; ?><br/>
				<span style="font-weight:bold;">Payment Status:</span><?php echo $status; ?><br/>
				<span style="font-weight:bold;">Payment Method:</span><?php echo $payment_method; ?><br/>
				<span style="font-weight:bold;">Payment Description:</span><?php echo $payment_description; ?><br/>
				<span style="font-weight:bold;">Note:</span><?php echo $note; ?><br />
				<span style="font-weight:bold;">Living Address:</span><?php echo $living_address; ?><br />
				<span style="font-weight:bold;">Random String:</span><?php echo $random_string; ?></td>
				<?php 
				if($double_status=="" )
				{
				?>
				<td style="color:green !important; font-weight:bold;"></td>	
				<?php	
				}
				else if($double_status=="Double")
				{
				?>
				<td style="color:red !important; font-weight:bold;">Double</td>
				<?php 
				}
				if($double_status=="Double")
				{
				?>
				<td><center><a href="penalty-report.php?not_double=<?php echo $id;?>"  style="color:green; font-weight:bold;" onclick="return confirm('Are you sure Remove As Not Double ?');">Remove Not Double</a></center></td>
				<?php
				}
				else if($double_status=="")
				{
				?>
				<td><center><a href="penalty-report.php?double=<?php echo $id;?>"  style="color:red; font-weight:bold;" onclick="return confirm('Are you sure Set As Double ?');">Set As Double</a></center></td>
				<?php
				}
				?>
				<?php 
				if($status=='Paid' )
				{
				?>
				<td style="color:orange !important; font-weight:bold; font-size:15px;">Paid</td>	
				<?php	
				}
				else 
				{
				?>
				<td style="color:blue !important; font-weight:bold; font-size:15px;">UnPaid</td>
				<?php 
				}
				if($status=="Paid")
				{
				?>
				<td><center><a href="penalty-report.php?unpaid=<?php echo $id;?>"  style="color:blue; font-weight:bold; font-size:15px;" onclick="return confirm('Are you sure Set As Unpaid ?');">Set As Unpaid</a></center></td>
				<?php
				}
				else 
				{
				?>
				<td><center><a href="penalty-report.php?paid=<?php echo $id;?>"  style="color:orange; font-weight:bold; font-size:15px;" onclick="return confirm('Are you sure Set As Paid ?');">Set As Paid</a></center></td>
				<?php
				}
				?>
				
				<td><a href="edit-penalty-details.php?edit_id=<?php echo $id; ?>" target="_blank" style="font-weight:bold; color:green;">EDIT</a></td>
				
				<td><a href="view-penalty-details.php?p_id=<?php echo $id; ?>" target="_blank" style="font-weight:bold; color:green;">VIEW</a></td>
				<?php
				if($image1!="" AND strpos($image1, '.') !== false )
				{
				?>
				<td><a href="../api/post_images/<?php echo $image1; ?>" target="_blank"><img src="../api/post_images/<?php echo $image1; ?>" height="50px" width="50px"></a></td>

				<?php
				}
				else
				{
				?>
				<td><a href="../api/post_images/no-image.png" target="_blank"><img src="../api/post_images/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				if($image2!="" AND strpos($image2, '.') !== false )
				{
				?>
				<td><a href="../api/post_images/<?php echo $image2; ?>" target="_blank"><img src="../api/post_images/<?php echo $image2; ?>" height="50px" width="50px"></a></td>

				<?php
				}
				else
				{
				?>
				<td><a href="../api/post_images/no-image.png" target="_blank"><img src="../api/post_images/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				if($image3!="" AND strpos($image3, '.') !== false)
				{
				?>
				<td><a href="../api/post_images/<?php echo $image3; ?>" target="_blank"><img src="../api/post_images/<?php echo $image3; ?>" height="50px" width="50px"></a></td>

				<?php
				}
				else
				{
				?>
				<td><a href="../api/post_images/no-image.png" target="_blank"><img src="../api/post_images/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				if($image4!="" AND strpos($image4, '.') !== false )
				{
				?>
				<td><a href="../api/post_images/<?php echo $image4; ?>" target="_blank"><img src="../api/post_images/<?php echo $image4; ?>" height="50px" width="50px"></a></td>

				<?php
				}
				else
				{
				?>
				<td><a href="../api/post_images/no-image.png" target="_blank"><img src="../api/post_images/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				?>
				
			</tr> 			
			<?php
					$counter++;
				}
			?>
			
			<?php
			}
			else
			{
			?>
			<td colspan="3">No Data Found...</td>
			<?php
			}
		   ?>
		</tr> 
	</tbody> 
</table> 
</div>
</div>
</div>
</div>
</div>
	</div>
<?php include('footer.php'); ?>
	
<?php //include('search.php'); ?>
<!-- END SEARCH PANEL-->
<!-- BEGIN THEME CONFIG PANEL-->

<!-- END THEME CONFIG PANEL-->
<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
<div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- New question dialog-->

<!-- End New question dialog-->
<!-- QUICK SIDEBAR-->
<?php //include('right-side-bar.php'); ?>
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
<script>

$( function()  {
		$( "#from_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		$( "#to_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		
}  ) ;
		


</script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->

<!-- CORE SCRIPTS-->
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
<script>
$(function() {
	$('#example').DataTable({
		pageLength: 10,
		fixedHeader: true,
		responsive: true,
		"sDom": 'rtip',
		columnDefs: [{
			targets: 'no-sort',
			orderable: false
		}]
	});

	var table = $('#example').DataTable();
	$('#key-search').on('keyup', function() {
		table.search(this.value).draw();
	});
  
});
</script>
	


    <!-- PAGE LEVEL SCRIPTS-->
</body>

</html>
