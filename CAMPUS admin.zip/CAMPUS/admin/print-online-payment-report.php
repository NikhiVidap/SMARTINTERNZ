<?php 
require_once('lib/functions.php');

$db		=	new login_function();
ob_start();
$_SESSION['option']=2;
if(isset($_SESSION['option']) AND isset($_SESSION['from_date1']) AND isset($_SESSION['to_date1']) )
{
		$option		=	$_SESSION['option'];
		$from_date1	=	$_SESSION['from_date1'];
		$to_date1	=	$_SESSION['to_date1'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>EXCEL PDF</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
	 <script src="js/jquery.min.js"></script>
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	text-transform:uppercase;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	text-transform:uppercase;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th
{
	text-align:center;
	border:1px solid black;
	font-size:12px;
}
table,td
{
	text-align:left;
	border:1px solid black;
	font-size:12px;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 300px;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
.main_head
{
	width:900px;
	margin:auto;
	font-size:14px;
	
	padding:10px;
	padding-top:0px;
	box-shadow:0px 0px 5px 1px #DFDFDF;
	border:1px solid #CCCCCC;
}	
.main_head>h1,h2,h4,h6
{
	text-align:center;
	margin:5px;
}
.sub_head
{
	border-bottom:1px dashed #CCCCCC;
	background-color:#FCFCFC;
	text-align:center;
	margin-bottom:8px;
	padding-top:10px;
	padding-bottom:10px;
	position:relative;
	line-height:40px;
}
.logo
{
	position: absolute;
	left:50px;
	top:1px;
	height:70px;
	width:70px;
	border-radius:40px;
}
body
{
	font-family:cambria;
	background-color:white;
}
label
{
	text-align:left;
	font-size:16px;
	font-weight:bold;
	margin:4px;
}
.sub_txtline
{
	font-size:14px;
	font-weight:bold;
	line-height:25px;
	font-family:cambria;
	font-weight:bold;
}
h6
{
	font-size:16px !important;
}
thead		
{
	background-color:#efefef;
	font-size:14px;
	font-weight:bold;
	
}	
.table-bordered td, .table-bordered th {
    border: 1px solid black;
	-webkit-print-color-adjust: exact; 
}
.link
{
	background-color:#208F86 !important;
	font-size:17px;
	font-family:cambria;
	color:#FFFFFF;
	padding:10px;
	border-radius:10px;
	font-weight:bold;
	border:1px solid #666;
	margin-top:15px;
}
.table td, .table th {
    padding: .5rem;
    vertical-align: top;
    border-top: 1px solid #e9ecef;
}
</style>
<body style="background-color:white;">
<!----------------TABLE--------------------------->	
<div class="main_head">
<?php
if($option==2)
{
?>
 <div class="sub_head">
 <div class="head_pay_sleep">
<img src="images/mahanagar-palika-logo.png" class="mahanagar-palika-logo" style="height:70px; width:70px;  margin-top:-20px; float:left;" />
<h1 style="margin-bottom:10px;margin-top:25px; font-size:32px;">सोलापूर महानगरपालिका</h1>
</div>

</div>
<?php
}
?>
<h1 style="margin-bottom:10px;margin-top:25px; font-weight:bold; font-size:25px; line-height:25px; margin-top:15px; text-align:center;">Online Payment Report</h1>
<div class="sub_txtline" style="font-size:14px; line-height:25px; font-family:cambria; font-weight:bold;"><center>From Date  : <?php echo $from_date1; ?> </div>
<table class="table table-bordered table-hover" id="example" >
	<thead>
	<tr>
		<th width="5">Sr No</th>
		<th width="50">SI Details</th> 
		<th width="5">Date</th> 
		<th width="2">Re No</th> 
		<th width="20">Name</th> 
		<th width="5">Mobile No</th> 
		<th width="5">Payment Method</th> 
		<th width="5">Payment Amount</th> 
	</tr>
	</thead>
	<tbody>
	<?php
		$date_data	=	explode("-",$from_date1);
		$res_from_date = $date_data[2]."-".$date_data[1]."-".$date_data[0];
		/*$date_data1	=	explode("-",$to_date1);
		$res_to_date = $date_data1[2]."-".$date_data1[1]."-".$date_data1[0];
		
		$date1=date_create($res_from_date);
		$date2=date_create($res_to_date);
		$diff=date_diff($date1,$date2);
		$total_days	=	$diff->format("%R%a ");
		$date1	=	$res_from_date;	*/
		
		$final_amount	=	0;
		
		$data			=	array();
		$data			=	$db->get_all_collection_agent_details();
		$total_amount	=	0;
		if(!empty($data))
		{
			$counter =0;
			foreach($data as $record1)
			{
				$id				=	$data[$counter][0];
				$employee_code	=	$data[$counter][1];
				$res_name		=	$data[$counter][2];
				$res_mobile_no	=	$data[$counter][3];
				$res_address	=	$data[$counter][4];
				$suser_id		=	$data[$counter][5];
				$password		=	$data[$counter][6];
				$res_user_type	=	$data[$counter][7];
				if($res_user_type=='0') 
				{ 
					$user_type_name="Collection Agent";
				}
				else if($res_user_type=='1')
				{
					$user_type_name="Cashier";
				}
				
				?>
			<tr> 
				<td style="text-align:left;"><span class="txt"><?php echo $counter+1; ?></td>
				<td>Name : <?php echo $res_name; ?> <br /> Mobile No : <?php echo $res_mobile_no; ?> </td>
				<td colspan="6">
				<table class="table table-bordered">
				
				<!--<thead>
				<tr>
					<th width="5">Date</th> 
					<th width="5">Re No</th> 
					<th width="5">Name</th> 
					<th width="5">Mobile No</th> 
					<th width="5">Payment Method</th> 
					<th width="5">Payment Amount</th> 
				</tr>
				</thead>-->
				
				<?php
				$total_amount	=	0;
				$i				=0;
				//for ($i = 0; $i <= $total_days; $i++)
				//{	
							$penalty_data	=	array();
									
							$penalty_data	=	$db->get_penalty_details_online_payment_new($res_from_date,$suser_id);
							if(!empty($penalty_data))
							{
								$penalty_counter	=	0;
								foreach($penalty_data as $record)
								{
									$id					=	$record[0];
									$image1				=	$record[1];
									$image2				=	$record[2];
									$image3				=	$record[3];
									$image4				=	$record[4];
									$name				=	$record[5];
									$address			=	$record[6];
									$mobile_no			=	$record[7];
									$penalty_for		=	$record[8];
									$penalty_amount		=	$record[9];
									$status				=	$record[10];
									$payment_method		=	$record[11];
									$payment_description=	$record[12];
									$note				=	$record[13];
									$new_user_id		=	$record[14];
									$living_address		=	$record[17];
									$random_string		=	$record[18];	
									$date				=	$record[15];
									
									$total_amount=$total_amount+$penalty_amount;
									
							?>
								
								<tr style="font-size:13px;">
								<?php
								$date_data5	=	explode("-",$date);
								$res_entry_date = $date_data5[2]."-".$date_data5[1]."-".$date_data5[0];
								?>
								<td><?php echo $res_entry_date; ?></td>
								<td><?php echo $id; ?></td>
								<td><?php echo $name; ?></td>
								<td><?php echo $mobile_no; ?></td>
							
								<td><?php echo $payment_method; ?></td>
								<td><?php echo $penalty_amount; ?></td>
								
								
								</tr>
							<?php
									$penalty_counter++;
								//$date1 = date('Y-m-d', strtotime($date1. ' + 1 day'));	
								//}
							}
							
						
					}
					if($total_amount!=0)
					{
					?>
					
					<tr style="text-align:center !important; font-weight:bold;">
					<td colspan="5" style="text-align:center !important; font-weight:bold;">Total:</td>
					<td style="text-align:center !important; font-weight:bold;"> &#8377 <?php echo $total_amount; ?></td>
					
					</tr>
					<?php
					}
					?>
					</table>
					</td>
				<?php
				$counter++;
					$final_amount=$final_amount+$total_amount;
				}
					
			?>
			<tr style="text-align:center !important; font-weight:bold; font-size:16px;">
			<td colspan="8" style="text-align:center !important; font-weight:bold; font-size:16px;">Total Amount  : &#8377 <?php echo $final_amount; ?></td>
			
			</tr>
			<?php
			
		}

		else
		{
		?>
		<td colspan="3">No Data Found...</td>
		<?php
		}
		?>
		</tr> 
		</tbody> 
		</table> 
		</div>
<!----------------END TABLE------------------------->	
<?php
if($option==1)
{
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename= rented-property.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	ob_end_flush();
}
else
{
?>
	<script>
	window.print();
	</script>
<?php
}
?>

</body>

</html>
