<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}

		
$success			=0;

if(isset($_GET['del']))
{
	$del	=	$_GET['del'];
	
	if($db->delete_collection_agent($del))
	{
		$success	=	3;
	}
	
}
 if(isset($_GET['active']))
{
	$active	=	$_GET['active'];
	$db->update_user_as_active($active);
}

if(isset($_GET['block']))
{
	$block	=	$_GET['block'];
	$db->update_user_as_block($block);
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $project_title; ?></title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th
{
	text-align:center;
	
}
table,td
{
	text-align:left;

}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 350px;
overflow: auto;
}
.table-wrapper-scroll-x
{
position: relative;
width: 100%;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
.txt
{
	text-align:left;
	color:#232B99;
	font-size:12px;
	margin-right:10px;
	font-weight:bold;
	height:40px;
}	

	
</style>

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	</head>
	<body class="fixed-navbar">

	<div class="page-wrapper" style="height:900px;">

	<?php include('header.php'); ?>
	<?php include('side-bar.php'); ?>

	<div class="content-wrapper">


	<div class="page-content fade-in-up">
	<div class="ibox" style="border-radius:5px; padding:7px;">

	<div class="ibox-body" style="padding:7px; padding-top:0px;">
		<div class="ibox-head">
			<div class="ibox-title">Allowed Users List</div>
			<a href="add-member.php" class="btn btn-primary btn-air" style=""><i class="fas fa-plus">&nbsp;&nbsp;</i>Add Details</a>			
		</div>	
	</div>

	<?php
		
		if($success=='3')
		{
		?>
		<script>
			alert("Software User  Deleted Successfully...!!!");
		</script>
		
		<?php
		}
		?>
		
		<br />
		
	<div class="flexbox mb-4" style="margin-left:20px;margin-right:20px;">
	<div class="input-group-icon input-group-icon-left mr-3">
	<span class="input-icon input-icon-right font-16"><i class="fas fa-search"></i></span>
	<input class="form-control form-control-rounded form-control-solid" id="key-search" type="text" placeholder="Search ...">
	</div>

	</div>

	<div class="table-wrapper-scroll-y table-wrapper-scroll-x my-custom-scrollbar">

	<div class="table-responsive" id="table_response" style="height:100%; width:100%; overflow:auto;">
	<table class="table table-bordered table-hover" id="example" >
	<thead class="thead-default thead-lg">
	<tr>
	<th>Sr No</th>    
	<th>Details</th>
	<th>User Status</th>
	<th>Action</th>
	<th>Action</th>
	<th>Action</th>

	</tr>
	</thead>
	<tbody>
	<?php
	$data	=	array();
	$data	=	$db->get_all_collection_agent_details();

	if(!empty($data))
	{
		$counter =0;
		foreach($data as $record)
		{
			$id				=	$record[0];
			$employee_code	=	$record[1];
			$res_name		=	$record[2];
			$res_mobile_no	=	$record[3];
			$res_address	=	$record[4];
			$user_id		=	$record[5];
			$password		=	$record[6];
			$res_user_type	=	$record[7];
			$user_status	=	$record[8];
			if($res_user_type=='0') 
			{ 
				$user_type_name="2 Wheeler";
			}
			else if($res_user_type=='1')
			{
				$user_type_name="3 Wheeler";
			}
			else if($res_user_type=='2')
			{
				$user_type_name="4 Wheeler";
			}
			?>
		<tr> 
		    <td><?php echo $counter+1; ?></td>
			<td style="text-align:left;">
		
			<span class="txt">Unique Code:</span><?php echo $employee_code; ?></br>

			<span class="txt">Name:</span><?php echo $res_name; ?></br>
			<span class="txt">Mobile Number:</span><?php echo $res_mobile_no; ?></br>
			<span class="txt">Address:</span><?php echo $res_address; ?></br>
			<span class="txt">Vehicle Id:</span><?php echo $user_id; ?></br>
			<span class="txt">Other Info:</span><?php echo $password; ?></br>
			<span class="txt">Vehicle Type:</span><?php echo $user_type_name; ?></br>
			</td>
			
			<?php 
			if($user_status=="" OR $user_status=="Active")
			{
			?>
			<td style="color:green !important; font-weight:bold;">Active</td>	
			<?php	
			}
			else if($user_status=="Block")
			{
			?>
			<td style="color:red !important; font-weight:bold;">Block</td>
			<?php 
			}
			if($user_status=="Block")
			{
			?>
			<td><center><a href="users.php?active=<?php echo $id;?>"  style="color:green; font-weight:bold;" onclick="return confirm('Are you sure to Active the User ?');">Make Active</a></center></td>
			<?php
			}
			else if($user_status=="" OR $user_status=="Active")
			{
			?>
			<td><center><a href="users.php?block=<?php echo $id;?>"  style="color:red; font-weight:bold;" onclick="return confirm('Are you sure to Block the User ?');">Make Block</a></center></td>
			<?php
			}
			?>
			<td><center><a href="update-user.php?edit_id=<?php echo $id; ?>"><i class="fas fa-edit"style="color:blue;margin-left:20px;"></i></a></center> </td>
			<td><center><a href="colletion-agent.php?del=<?php echo $id;?>" onclick="return confirm('Are You Sure to Delete this Record ?');"><i class="fas fa-trash"style="color:red;margin-left:20px;"></i></a></center> </td>
			
	<?php
	$counter++;
	}
	
}

else
{
?>
<td colspan="19">No Data Found...</td>
<?php
}
?>
</tr> 
</tbody> 
</table> 
</div>
</div>
</div>
</div>
</div>
	</div>
</div>

		<?php include('footer.php'); ?>
	
<?php //include('search.php'); ?>
<!-- END SEARCH PANEL-->
<!-- BEGIN THEME CONFIG PANEL-->

<!-- END THEME CONFIG PANEL-->
<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
<div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- New question dialog-->

<!-- End New question dialog-->
<!-- QUICK SIDEBAR-->
<?php //include('right-side-bar.php'); ?>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->

<!-- CORE SCRIPTS-->
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
<script>
$(function() {
	$('#example').DataTable({
		pageLength: 10,
		fixedHeader: true,
		responsive: true,
		"sDom": 'rtip',
		columnDefs: [{
			targets: 'no-sort',
			orderable: false
		}]
	});

	var table = $('#example').DataTable();
	$('#key-search').on('keyup', function() {
		table.search(this.value).draw();
	});
  
});
</script>
</body>

</html>
