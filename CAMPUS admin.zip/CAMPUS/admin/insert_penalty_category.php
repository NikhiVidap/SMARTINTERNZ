<?php
require_once('lib/functions.php');
$db		=	new login_function();
$success="";

		if(isset($_POST['submitData']))
		{
		
			$category_title 	= $_POST['dep'];
			$amount    			= $_POST['desc'];
		  
			$db_id 		= $db->get_penalty_category_details($category_title);
		  
			if($db_id=="")
			{
				if($db->create_penalty_category($category_title,$amount))
				{
					$success	= 1;
					
					
				}
			}
			else
				{
				$success	= 2;
				}

		}
echo json_encode($success);
?>