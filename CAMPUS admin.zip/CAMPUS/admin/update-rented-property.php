<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
	
$flag			=	0;
$employee_name	=	"";
$birth			=	"";
$gender			=	"";
$blood_grp		=	"";
$martial_status	=	"";
$mobile_no		=	"";
$address		=	"";
$designation	=	"";
$join_date		=	"";
$aadhar_no		=	"";
$image			=	"";
$adhar_attach	=	"";
$pan_attach		=	"";
$password		=	"";				
$other_mobile_no	="";	
$actual_pan_attach=	"";	
$actual_adhar_attach ="";
$actual_image	=	"";		
$user_id		=	"";
$password		=	"";
//
$frequency_days		=	"";
$property_issue_date=	"";
$payble_deposite_amount	=	"";
//
//
$property_type			=	"";
$income_source			=	"";
$actual_property_photo1	=	"";
$actual_property_photo2	=	"";
$actual_property_photo3	=	"";
$actual_property_photo4	=	"";
if(isset($_GET['edit_id']))
{
	$edit_id	=	$_GET['edit_id'];
	$_SESSION['edit_id'] = $edit_id;
}
else if(isset($_SESSION['edit_id']))
{
	$edit_id	= $_SESSION['edit_id'];
}
		
if(isset($_POST['add']))
{	
	$employee_name		= 	$_POST['employee_name'];
	$mobile_no 			= 	$_POST['mobile_no'];
	$address 			= 	$_POST['address'];
	$other_mobile_no 	=   $_POST['other_mobile_no'];
	$user_id 			=   $_POST['user_id'];
	$password 			=   $_POST['password'];
	//
	$frequency_days 	= $_POST['frequency_days'];
	$property_issue_date= $_POST['property_issue_date'];
	$payble_deposite_amount=$_POST['payble_deposite_amount'];
	//
	$property_type			=	$_POST['property_type'];
	$income_source			=	$_POST['income_source'];
	if(strlen($mobile_no)!=10)
	{
	?>
	<script type="text/javascript">
	alert("Please Enter 10 digit Contact Number");

	</script>
	<?php
	$flag				=	1;	
	}
	if($other_mobile_no!="")
	{
	if(strlen($other_mobile_no)!=10)
	{
	?>
	<script type="text/javascript">
		alert("Please Enter 10 digit Contact Number");
		
	</script>
	<?php
		$flag=1;
	}
	}	
	
	$aadhar_no	 	= $_POST['aadhar_no'];
	if($aadhar_no!='')
	{
	if(strlen($aadhar_no)!=12)
	{
	?>
	<script type="text/javascript">
		alert("Please Enter 12 digit Aadhar Number");
		
	</script>
	<?php
	$flag				=	1;	
	}
	}

	

	if($flag==0)
	{
	
		if($db->update_rented_property_master($employee_name,$mobile_no,$address,$other_mobile_no,$aadhar_no,$edit_id,$user_id,$password,$frequency_days,$property_issue_date,$payble_deposite_amount,$property_type,$income_source))
		{
		?>
			<script>
			alert("Details Successfully Updated...!!!");
			window.location.href="update-rented-property.php";
			</script>
		<?php
			
		}
		else
		{
			?>
			<script>
			alert("Details Failed to update...!!!");
			</script>
		<?php
			
		}
	
	}

}                                                                                                   


	$record	=	array();
	$record = $db->get_rent_property_details_by_id($edit_id);
	
	if(!empty($record))
	{
		$id						=	$record[0];
		$employee_name			=	$record[1];
		$mobile_no				=	$record[2];
		$address				=	$record[3];
		$other_mobile_no		=	$record[4];
		$aadhar_no				=	$record[5];
		$image					=	$record[6];
		$pan_attach				=	$record[7];
		$adhar_attach			=	$record[8];
		$user_id				=	$record[9];
		$password				=	$record[10];
		$frequency_days			=	$record[11];
		$property_issue_date	=	$record[12];
		$payble_deposite_amount	=	$record[13];
		$property_type			=	$record[14];
		$income_source			=	$record[15];
		$property_photo1		=	$record[16];
		$property_photo2		=	$record[17];
		$property_photo3		=	$record[18];
		$property_photo4		=	$record[19];
	}
	
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Update Rented Property</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	<link href="datatable/datatables.min.css" rel="stylesheet" />

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	<script>
	function validateForm() {
	  var a = document.forms["myForm"]["employee_name"].value;
	  var f = document.forms["myForm"]["mobile_no"].value;
	  var g = document.forms["myForm"]["address"].value;
	  var h = document.forms["myForm"]["frequency_days"].value;
	  var j = document.forms["myForm"]["property_issue_date"].value;
	  var k = document.forms["myForm"]["payble_deposite_amount"].value;
	  var l = document.forms["myForm"]["property_type"].value;
	  var m = document.forms["myForm"]["income_source"].value;
	  if (a == "") {
		alert("Enter Employees Name");
		return false;
	  }
	   if (g == "") {
		alert("Enter Address");
		return false;
	  }
	 if (f == "") {
		alert("Enter  Mobile Number");
		return false;
	  }
	 
	   if (h == "") {
		alert("Enter User Id");
		return false;
	  }
	   if (i == "") {
		alert("Enter Password");
		return false;
	  }
	  if (h == "select") {
		alert("Select Frequency Days");
		return false;
	  }
	  if (j == "") {
		alert("Enter Property Issue Date");
		return false;
	  }
	  if (k == "") {
		alert("Enter Deposite Amount");
		return false;
	  }
	  if (l == "select") {
		alert("Select Property Type");
		return false;
	  }
	   if (m == "select") {
		alert("Select Income Source");
		return false;
	  }
	}
	</script>
	

</head>
<body class="fixed-navbar">
  
<div class="page-wrapper" style="min-height:500px;">
<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>
<div class="content-wrapper">
<div class="row" style="padding:0px; margin:0px; margin-top:15px; border-radius:15px;">

<div class="ibox" style="border-radius:5px; padding:7px;">
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">

<div class="ibox-head">
<div class="ibox-title"><i class="fas fa-user-tie" style="margin-right:10px;"></i>Update Rented Property Master</div>
<a href="update-rent-images.php?up_emp_id=<?php echo $edit_id; ?>" class="btn btn-primary btn-air"><i class="fas fa-edit">&nbsp;&nbsp;</i>UPDATE IMAGES</a>

</div>

<div class="ibox-body">
<div class="row">

<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
	<label class="form-group mb-4 set-row label_marg"><b>Name<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-user"></i></span>
		<input class="form-control form-control-air" name="employee_name" placeholder="Enter Name" value="<?php echo $employee_name; ?>"   />
	</div>
</div>
<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
	<label class="form-group mb-4 set-row label_marg"><b>Address<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-map-marker"></i></span>
		<textarea class="form-control form-control-air" name="address" id="address" placeholder="Enter Address" /><?php echo $address; ?></textarea>
	</div>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-4">
<label class="form-group mb-4 set-row label_marg"><b>Mobile Number<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-phone"></i></span>
		<input class="form-control form-control-air" type="number" name="mobile_no" placeholder="Enter Mobile Number" value="<?php echo $mobile_no; ?>"   />
	</div>
</div>
<div class="col-sm-3 col-md-3 col-lg-63form-group mb-3">
	<label class="form-group mb-4 set-row label_marg"><b>Enter Other Mobile Number</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-phone"></i></span>
		<input type="number" name="other_mobile_no" class="form-control form-control-air" value="<?php echo $other_mobile_no; ?>" placeholder="Enter Other Mobile Number"   />
	</div>
</div>

<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-3">
	<label class="form-group mb-4 set-row label_marg"><b>Aadhar Card Number</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
		<input type="text" name="aadhar_no" id="aadhar_no" class="form-control form-control-air" value="<?php echo $aadhar_no; ?>" placeholder="Enter Aadhar Number"   />
	</div>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-4">
	<label class="form-group mb-4 set-row label_marg"><b>Frequency Days<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<select name="frequency_days" class="form-control form-control-air">
		<option value="select" <?php if($frequency_days=='select') { ?> Selected <?php } ?>>Select Frequency Days</option>
		<option value="Monthly" <?php if($frequency_days=='Monthly') { ?> Selected <?php } ?>>Monthly</option>
		<option value="Daily" <?php if($frequency_days=='Daily') { ?> Selected <?php } ?>>Daily</option>
		<option value="Weekly" <?php if($frequency_days=='Weekly') { ?> Selected <?php } ?>>Weekly</option>
		</select>
</div>

<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-4">
<label class="form-group mb-4 set-row label_marg"><b>Property Issue Date<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-phone"></i></span>
		<input class="form-control form-control-air" type="text" name="property_issue_date" placeholder="Enter Property Issue Date" value="<?php echo $property_issue_date; ?>" id="property_issue_date"   />
	</div>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-4">
<label class="form-group mb-4 set-row label_marg"><b>Payble Deposite Amount<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-inr"></i></span>
		<input class="form-control form-control-air" type="number" name="payble_deposite_amount" placeholder="Enter Payble Deposite Amount" value="<?php echo $payble_deposite_amount; ?>"   />
	</div>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-3">
	<label class="form-group mb-4 set-row label_marg"><b>Property Type<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<select name="property_type" class="form-control form-control-air">
		<option value="select" <?php if($property_type=='select') { ?> Selected <?php } ?>>Select Property Type</option>
		<option value="Ota" <?php if($property_type=='Ota') { ?> Selected <?php } ?>>Ota</option>
		<option value="Gala" <?php if($property_type=='Gala') { ?> Selected <?php } ?>>Gala</option>
		
		</select>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-3">
	<label class="form-group mb-4 set-row label_marg"><b>Income Source<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<select name="income_source" class="form-control form-control-air">
		<option value="select" <?php if($income_source=='select') { ?> Selected <?php } ?>>Select Income Source</option>
		<?php
		$data	=	array();
		$data	=	$db->get_all_category_details();
		
		if(!empty($data))
			{
				$counter =0;
				foreach($data as $record)
				{
					$id					=	$record[0];
					$res_title			=	$record[1];
					$res_description	=	$record[2];
					
		?>
		<option value="<?php echo $id; ?>" <?php if($income_source==$id) { ?> Selected <?php } ?>><?php echo $res_title; ?></option>
		<?php
				$counter++;
				}
				
			}
		?>
		</select>
</div>

<div class="col-sm-3 col-md-3 col-lg-63form-group mb-3">
	<label class="form-group mb-4 set-row label_marg"><b>User Id</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-phone"></i></span>
		<input type="text" name="user_id" class="form-control form-control-air" value="<?php echo $user_id; ?>" placeholder="Enter Other Mobile Number"   />
	</div>
</div>

<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-3">
	<label class="form-group mb-4 set-row label_marg"><b>Password</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
		<input type="password" name="password" id="aadhar_no" class="form-control form-control-air" value="<?php echo $password; ?>" placeholder="Enter Aadhar Number"   />
	</div>
</div>
<div class="col-sm-12 form-group mb-12" style="text-align:center; padding-left:0px; padding-right:0px; padding-top:20px;">
	<div class="col-sm-4 form-group mb-4" style="margin:auto;">
		<button class="btn btn-pink btn-air" type="submit" name="add" style="width:100%;" onclick="submitData()">SAVE DETAILS</button>
	</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>

</div>
</div>
<?php //include('footer.php'); ?>
</div>
    </div>
    <?php include('search.php'); ?>
   
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    
    <script src="js/jquery.min.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
<script>

$( function()  {
		$( "#property_issue_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		//$( "#join_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		
}  ) ;
		


</script>

    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/idle-timer.min.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
	<script src="datatable/datatables.min.js"></script>
    <script src="js/app.min.js"></script>
	
</body>
</html>