<?php
require_once('lib/functions.php');
$db		=	new login_function();
$success="";

		if(isset($_POST['submitData']))
		{
		
			$category_title 	= $_POST['dep'];
			$description    	= $_POST['desc'];
		  
			$db_department_id 		= $db->get_category_details($category_title);
		  
			if($db_department_id=="")
			{
				if($db->create_category($category_title,$description))
				{
					$success	= 1;
					
					
				}
			}
			else
				{
				$success	= 2;
				}

		}
echo json_encode($success);
?>