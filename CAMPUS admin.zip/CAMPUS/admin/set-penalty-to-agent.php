<?php

require_once('lib/functions.php');
$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}

if(isset($_GET['agent_id']))
{
	$agent_id	=	$_GET['agent_id'];
	$_SESSION['agent_id']	=	$agent_id;
}
else if(isset($_SESSION['agent_id']))
{
	$agent_id	=	$_SESSION['agent_id'];
}

$agent_penalty_data	=	$db->get_agent_penalty_data($agent_id);





$flag			=	0;
$employee_name	=	"";
$employee_code	=	"";
$mobile_no		=	"";
$address		=	"";
$user_id		=	"";
$password		=	"";
$user_id		=	"";
$password		=	"";
$user_type		=	"";
if(isset($_POST['add']))
{
	$penalty_entry_string	=	"";
	if(isset($_POST['penalty_id']))
	{
		$penalty_id	=	$_POST['penalty_id'];
		
		foreach($penalty_id as $penalty_new)
		{
			if($penalty_entry_string=="")
			{
				$penalty_entry_string	=	$penalty_new;
			}
			else{
				$penalty_entry_string	=	$penalty_entry_string.",".$penalty_new;
			}
		}
	}

	if($db->update_penalty_ids_to_agent($penalty_entry_string,$agent_id))
	{
?>
	<script>
		alert("Details updated successfully...!!!");
		window.location="colletion-agent.php";
	</script>
<?php		
	}
}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Set Penalty To Agent</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	<link href="datatable/datatables.min.css" rel="stylesheet" />

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	<script>
	function validateForm() {
	  var j = document.forms["myForm"]["employee_code"].value;
	  var a = document.forms["myForm"]["employee_name"].value;
	  var f = document.forms["myForm"]["mobile_no"].value;
	  var g = document.forms["myForm"]["address"].value;
	  var h = document.forms["myForm"]["user_id"].value;
	  var i = document.forms["myForm"]["password"].value;
	  var m = document.forms["myForm"]["user_type"].value;
	  if (m == "select") {
		alert("Select User Type");
		return false;
	  }
	 if (j == "") {
		alert("Enter Employee Code");
		return false;
	  }
	  if (a == "") {
		alert("Enter  Name");
		return false;
	  }
	 if (f == "") {
		alert("Enter  Mobile Number");
		return false;
	  }
	  if (g == "") {
		alert("Enter Address");
		return false;
	  }
	  if (h == "") {
		alert("Enter User Id");
		return false;
	  }
	   if (i == "") {
		alert("Enter Password");
		return false;
	  }
	   
	  
	}
	</script>
	

</head>
<body class="fixed-navbar">
  
<div class="page-wrapper" style="min-height:500px;">
<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>
<div class="content-wrapper">
<div class="row" style="padding:0px; margin:0px; margin-top:15px; border-radius:15px;">

<div class="ibox" style="border-radius:5px; padding:7px;">
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">



<?php
$record	=	array();
$record = $db->get_collection_details_by_user_id($agent_id);

if(!empty($record))
{
	$id						=	$record[0];
	$employee_code			=	$record[1];
	$employee_name			=	$record[2];
	$mobile_no				=	$record[3];
	$address				=	$record[4];
	$user_id				=	$record[5];
	$password				=	$record[6];
	$user_type				=	$record[7];
}	
?>

<div class="ibox-head">
<div class="ibox-title"><i class="fas fa-user-tie" style="margin-right:10px;"></i>Set Penalties To Agent - <label style="color:green;"><?php echo $employee_name; ?></label></div>
</div>
<div class="ibox-body">
<div class="row">

<div class="table-responsive" id="table_response">
<table class="table table-bordered table-hover" id="example" style="text-align:center;">
	<thead class="thead-default thead-lg">
		<tr style="">
			<th  style="text-align:center;font-size:15px;" width="20">Sr.No</th>
			<th  style="text-align:center;font-size:15px;" width="40">
			<label style="cursor:pointer;"><input type="checkbox" id="checkAll" style="height:20px; width:20px;"/>
			Check/Uncheck All</label></th>
			<th  style="text-align:center;font-size:15px;" width="500">Title</th> 
			<th  style="text-align:center;font-size:15px;" width="100">Amount</th> 
		</tr>
	</thead>
	<tbody>
<?php
	$set_penalty_data	=	array();
	if($agent_penalty_data!="")
	{
		$set_penalty_data	=	explode(",",$agent_penalty_data);
	}
	
	$agent_penalty_list_array	=	array();
	$agent_penalty_list	=	$db->get_agentpenalty_list($agent_id);

	if($agent_penalty_list!="")
	{
		$agent_penalty_list_array	=	explode(",",$agent_penalty_list);
	}

		$data	=	array();
		$data	=	$db->get_all_penalty_category_details();
		
		if(!empty($data))
			{
				$counter =0;
				$total_amount	=0;

				foreach($data as $record)
				{
					$id					=	$record[0];
					$res_title			=	$record[1];
					$res_description	=	$record[2];
					$res_date			=	$record[3];
					$res_time			=	$record[4];
					
					$total_amount		=	$total_amount+$res_description;

					?>
					<tr> 
						<td><?php echo $counter+1; ?></td>
						<td>
							<input type="checkbox" style="height:25px; width:25px; cursor:pointer;" name="penalty_id[]" value="<?php echo $id; ?>" <?php if(in_array($id, $agent_penalty_list_array)){ ?> checked <?php }  ?> />
						</td>
						<td style="text-align:left; font-size:15px;"><?php echo $res_title; ?></td>
						<td style="font-size:14px; color:purple !important; font-weight:bold;" ><?php echo $res_description; ?></td>
					</tr>	
				<?php
					$counter++;
				}
			}
			else
			{
			?>
			<td colspan="7">No Data Found...</td>
			<?php
			}
		   ?>
	</tbody> 
</table> 
</div>

<div class="col-sm-12 form-group mb-12" style="text-align:center; padding-left:0px; padding-right:0px; padding-top:20px;">
	<div class="col-sm-4 form-group mb-4" style="margin:auto;">
		<button class="btn btn-pink btn-air" type="submit" name="add" style="width:100%;" onclick="submitData()">SAVE PENALTY DETAILS</button>
	</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>

</div>
</div>
<?php include('footer.php'); ?>
</div>
    </div>
    <?php include('search.php'); ?>
   
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    
    <script src="js/jquery.min.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
<script>

$( function()  {
		$( "#birth" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		$( "#join_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		
}  ) ;

$("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});
</script>

    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/idle-timer.min.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
	<script src="datatable/datatables.min.js"></script>
    <script src="js/app.min.js"></script>
	
</body>
</html>