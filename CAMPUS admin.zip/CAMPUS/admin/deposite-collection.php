<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
	
$flag					=	0;
$property_name			=	"";
$payble_deposite_amount	=	"";
$payment_type			=	"";
$payment_description	=	"";
//
$remaining_amount	=	"";
$desposite_amount	=	"";
$paid_amount		=	"";
$propert_id			=	"";
if(isset($_GET['propert_id']))
{
	$propert_id	=	$_GET['propert_id'];
	$_SESSION['propert_id'] = $propert_id;
}
else if(isset($_SESSION['propert_id']))
{
	$propert_id	= $_SESSION['propert_id'];
}
else
{
	$propert_id="";
}
$original_deposite=0;
$original_deposite=$db->get_original_deposite($propert_id);

$property_name=$db->get_property_name_from_id($propert_id);

$sum_of_deposite=0;
 $sum_of_deposite=$db->get_sum_of_deposite($propert_id);

$remaining_amount=0;
$remaining_amount=$original_deposite-$sum_of_deposite;
if(isset($_POST['add']))
{	
	$property_name			= $_POST['property_name'];
	$payble_deposite_amount = $_POST['payble_deposite_amount'];
	$payment_type 			= $_POST['payment_type'];
	$payment_description 	= $_POST['payment_description'];
	$property_id=$db->get_property_id($property_name);
	


	
	if($property_id!='')
	{
		$original_deposite=0;
		$original_deposite=$db->get_original_deposite($property_id);

		$property_name=$db->get_property_name_from_id($property_id);

		$sum_of_deposite=0;
		 $sum_of_deposite-$db->get_sum_of_deposite($property_id);

		$remaining_amount=0;
		$remaining_amount=$original_deposite-$sum_of_deposite;
		if($payble_deposite_amount > $remaining_amount)
		{
		?>
		<script>
		alert("Payble Amount is Greater Than Deposite Amount");
		
		</script>
		<?php
		$flag=1;
		}
		if($flag==0)
		{
			if($db->create_deposite_amount($property_id,$payble_deposite_amount,$payment_type,$payment_description,$current_login_admin))
			{
			?>
				<script>
				alert("Deposite Amount Added Successfully...!!!");
				window.location.href="deposite-collection.php";
				</script>
			<?php
				
			}
			else
			{
				?>
				<script>
				alert("Deposite Amount Failed to Add...!!!");
				</script>
			<?php
				
				
			}
		}
	}
	else
	{
		?>
		<script>
		alert("Property Name Not Exist..Please Register First...!!!");
		</script>
	<?php
		
	}
}


	
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Add Deposite Collection</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	<link href="datatable/datatables.min.css" rel="stylesheet" />

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	<script>
	function validateForm() {
	  var a = document.forms["myForm"]["property_name"].value;
	  var f = document.forms["myForm"]["payble_deposite_amount"].value;
	  var g = document.forms["myForm"]["payment_type"].value;
	  var h = document.forms["myForm"]["payment_description"].value;
	 
	  if (a == "") {
		alert("Enter  Property Name");
		return false;
	  }
	 if (f == "") {
		alert("Enter Deposite Amount");
		return false;
	  }
	  if (g == "Select Payment Type") {
		alert("Select Payment Type");
		return false;
	  }
	  if (h == "") {
		alert("Enter Payment Description");
		return false;
	  }
	  
	}
	</script>
	

</head>
<body class="fixed-navbar">
  
<div class="page-wrapper" style="min-height:500px;">
<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>
<div class="content-wrapper">
<div class="row" style="padding:0px; margin:0px; margin-top:15px; border-radius:15px;">

<div class="ibox" style="border-radius:5px; padding:7px;">
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">

<div class="ibox-head">
<div class="ibox-title"><i class="fas fa-inr" style="margin-right:10px;"></i>ADD Deposite Collection</div>

</div>

<div class="ibox-body">
<div class="row">

<div class="col-sm-4 col-md-4 col-lg-4 form-group mb-4">
	<label class="form-group mb-4 set-row label_marg"><b>Property Name</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-search"></i></span>
		<input class="property_name_data form-control form-control-air" name="property_name" placeholder="Property Name" value="<?php echo $property_name; ?>"   />
	</div>
</div>

<div class="col-sm-4 col-md-4 col-lg-4 form-group mb-4">
<label class="form-group mb-4 set-row label_marg"><b>Payble Deposite Amount</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-inr"></i></span>
		<input class="payble_deposite_amount form-control form-control-air" type="number" name="payble_deposite_amount" placeholder="Enter Payble Deposite Amount" value="<?php echo $payble_deposite_amount; ?>"   />
	</div>
</div>
<div class="col-sm-4 col-md-4 col-lg-4 form-group mb-3">	
	<label class="form-group mb-4 set-row label_marg"><b>Payment  Type</b></label>
<div class="input-group-icon input-group-icon-left  set-row">
	<span class="input-icon input-icon-left"><i class="fas fa-hand-holding-usd"></i></span>
		<select class="payment_type form-control form-control-air" name="payment_type">
			<option option="Select Payment Type">Select Payment Type</option>
			<option option="CASH">CASH</option>
			<option option="NEFT">NEFT</option>
			<option option="WALLET">WALLET</option>
			<option option="ONLINE BANKING<">ONLINE BANKING</option>
		</select>
</div>
</div>
<div class="col-sm-4 col-md-4 col-lg-4 form-group mb-4">
<label class="form-group mb-4 set-row label_marg"><b>Deposite Amount</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-inr"></i></span>
		<input class="desposite_amount form-control form-control-air" type="number" name="desposite_amount" placeholder="Deposite Amount" value="<?php echo $original_deposite; ?>"   readonly />
	</div>
</div>
<div class="col-sm-4 col-md-4 col-lg-4 form-group mb-4">
<label class="form-group mb-4 set-row label_marg"><b>Paid Amount</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-inr"></i></span>
		<input class="paid_amount form-control form-control-air" type="number" name="paid_amount" placeholder="Paid Amount" value="<?php echo $sum_of_deposite; ?>"  readonly />
	</div>
</div>
<div class="col-sm-4 col-md-4 col-lg-4 form-group mb-4">
<label class="form-group mb-4 set-row label_marg"><b>Remaining  Amount</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-inr"></i></span>
		<input class="remaining_amount form-control form-control-air" type="number" name="remaining_amount" placeholder="Remaining Amount" value="<?php echo $remaining_amount; ?>"  readonly />
	</div>
</div>

<div class="col-sm-12 col-md-12 col-lg-12 form-group mb-3">		
<label class="form-group mb-4 set-row label_marg"><b>Payment  Description</b></label>
<div class="input-group-icon input-group-icon-left  set-row">
	<span class="input-icon input-icon-left"><i class="fas fa-hand-holding-usd"></i></span>
	<input class="form-control form-control-air" type="text" name="payment_description" placeholder="Payment  Description" value="<?php echo $payment_description; ?>" />
</div>
</div>	
<div class="col-sm-12 form-group mb-12" style="text-align:center; padding-left:0px; padding-right:0px; padding-top:20px;">
	<div class="col-sm-4 form-group mb-4" style="margin:auto;">
		<button class="btn btn-pink btn-air" type="submit" name="add" style="width:100%;" onclick="submitData()">SAVE DETAILS</button>
	</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>

</div>
</div>
<?php include('footer.php'); ?>
</div>
    </div>
    <?php include('search.php'); ?>
   
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    
    <script src="js/jquery.min.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="css/jquery-ui.css">
	 <script src="js/jquery.min.js"></script>
	<script src="js/jquery-ui.js"></script>
	<style>
	.ui-widget-content {
		border: 1px solid #DE1559;
		font-size:16px;
		background: #DE1559;
		color:#FFF;
		font-weight:bold;
		
	}
	.ui-menu .ui-menu-item {
		margin: 0;
		padding:6px;
		border:1px solid #FFF;
		border-bottom:0px solid #E82A2A;
		cursor: pointer;
		width:100%;
	}
	</style>
	<?php
		$property_data 	=	array();
		$property_data	=	$db->get_property_name();
		
	?>
  <script>
  
  $(function() {
    var availableTags = [<?php
						
						if(!empty($property_data))
						{
							foreach($property_data as $property_name)
							{
								
								echo '"'.$property_name.'",';
							}
						}
						?>];
    $( ".property_name_data" ).autocomplete({
      source: availableTags
    });
  } );
  </script>		
<script>
$(document).ready(function(){

        $(".property_name_data").change(function() {
			
			var selected_proprty_id 	= $(".property_name_data").val();
			
            var formData = {
                'res_id': selected_proprty_id
            };
//            console.log(formData);

            $.ajax({
                url: "get_deposite_details.php",
                type: "post",
                data: formData,
                success: function(res_data) {
				//alert(res_data);
					var decoded_data = jQuery.parseJSON(res_data);
                   
					$(".desposite_amount").val(decoded_data[0]);
					$(".paid_amount").val(decoded_data[1]);
					$(".remaining_amount").val(decoded_data[2]);
					
					
					
                }
            });
			
        });
	    
});
$(document).ready(function(){
	$(".payble_deposite_amount").focusout(function() {
			
			
			var payble_deposite_amount 	= $(".payble_deposite_amount").val();
			var remaining_amount 		= $(".remaining_amount").val();
			if(parseFloat(payble_deposite_amount) > parseFloat(remaining_amount))
			{
				
				alert("Don't Enter Payble Deposite  Amount  Greater Than Deposite Amount");
				$('.payble_deposite_amount').val("");
				$(".payble_deposite_amount").focus();
				return false;
			}
			/*if(payble_deposite_amount > remaining_amount )
			{
				alert("Payble Amount is Greater Than Deposite Amount");
				return false;
			}*/
			
        });	

});
</script>

    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/idle-timer.min.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
	<script src="datatable/datatables.min.js"></script>
    <script src="js/app.min.js"></script>
	
</body>
</html>