<?php
	require_once('lib/functions.php');

	$db		=	new login_function();
	$data	=	array();
	if(isset($_POST['res_id']))
	{
		$res_id	=	$_POST['res_id'];
		$property_id=$db->get_property_id($res_id);
		$original_deposite=0;
		$original_deposite = $db->get_original_deposite($property_id);
		
		$sum_of_deposite=0;
		$sum_of_deposite=$db->get_sum_of_deposite($property_id);
		if($sum_of_deposite=='')
		{
			$sum_of_deposite=0;
		}
		$remaining_amount=0;
		$remaining_amount=$original_deposite-$sum_of_deposite;
		
		
			$data[0]	=	$original_deposite;
			$data[1]	=	$sum_of_deposite;
			$data[2]	=	$remaining_amount;
			
		
		echo json_encode($data);
	}
?>