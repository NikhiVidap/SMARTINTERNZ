<?php 
require_once('lib/functions.php');

$db		=	new login_function();
ob_start();
if(isset($_GET['option']))
{
	$option			=	$_GET['option'];
	$_SESSION['option']		=	$option;
}
else if(isset($_SESSION['option']))
{
		$option=$_SESSIOn['option'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>EXCEL PDF</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
	 <script src="js/jquery.min.js"></script>
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	text-transform:uppercase;
	border:1px solid black;
}
</style>
<body style="background-color:white;">
<!----------------TABLE--------------------------->	
<table class="table table-bordered table-hover" id="example" >
	<thead class="thead-default thead-lg">
	<tr>
	<th>Details</th>
	</tr>
	</thead>
	<tbody>
	<?php
	$data	=	array();
	$data	=	$db->get_all_rented_property_details();

	if(!empty($data))
	{
		$counter =0;
		foreach($data as $record)
		{
			$id						=	$record[0];
			$res_name				=	$record[1];
			$res_mobile_no			=	$record[2];
			$res_address			=	$record[3];
			$other_mobile_no		=	$record[4];
			$res_aadhar_no			=	$record[5];
			$res_image				=	$record[6];
			$res_pan_attach			=	$record[7];
			$res_adhar_attach		=	$record[8];
			
			
			
			?>
		<tr> 
			<td style="text-align:left;"><span class="txt">Sr No:</span><?php echo $counter+1; ?></br>
			<span class="txt">Name:</span><?php echo $res_name; ?></br>
			<span class="txt">Mobile Number:</span><?php echo $res_mobile_no; ?></br>
			<span class="txt">Other Mobile No:</span><?php echo $other_mobile_no; ?></br>
			<span class="txt">Address:</span><?php echo $res_address; ?></br>
			<span class="txt">Aadhar No:</span><?php echo $res_aadhar_no; ?>
			</td>
			
	<?php
	$counter++;
	}
	
}

else
{
?>
<td colspan="19">No Data Found...</td>
<?php
}
?>
</tr> 
</tbody> 
</table> 
<!----------------END TABLE------------------------->	
<?php
if($option==1)
{
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename= rented-property.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	ob_end_flush();
}
else
{
?>
	<script>
	window.print();
	</script>
<?php
}
?>

</body>

</html>
