<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}

if(isset($_GET['edit_id']))
{
    $edit_id    =   $_GET['edit_id'];
    $_SESSION['edit_id']    =   $edit_id;
}
else if(isset($_SESSION['edit_id']))
{
    $edit_id    =   $_SESSION['edit_id'];
}

$flag			=	0;
$penalty_for	=	"";
$payment_method	=	"";

if(isset($_POST['add']))
{
	$penalty_for	= $_POST['penalty_for'];
	$payment_method	= $_POST['pay_method'];

    $penalty_amount = $db->get_penalty_amount($penalty_for);
    
    if($db->update_penalty_recipt_data($edit_id,$penalty_for,$payment_method,$penalty_amount))
    {
        ?>
        <script>
			alert("Receipt Details Updated Successfully...!!!");
			window.location = "penalty-report.php";
		</script>
        <?php
    }
}

$record	=	array();
$record	=	$db->get_all_penalty_details_report_by_id($edit_id);
if(!empty($record))
{

	$id					=	$record[0];
	$image1				=	$record[1];
	$image2				=	$record[2];
	$image3				=	$record[3];
	$image4				=	$record[4];
	$name				=	$record[5];
	$address			=	$record[6];
	$mobile_no			=	$record[7];
	$penalty_for		=	$record[8];
	$penalty_amount		=	$record[9];
	$status				=	$record[10];
	$payment_method		=	$record[11];
	$payment_description=	$record[12];
	$note				=	$record[13];
	$user_id			=	$record[14];
	$living_address		=	$record[17];
	$random_string		=	$record[18];
	$res_date		    =	$record[15];
}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Edit Receipt</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	<link href="datatable/datatables.min.css" rel="stylesheet" />

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
</head>
<body class="fixed-navbar">
  
<div class="page-wrapper" style="min-height:500px;">
<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>
<div class="content-wrapper">
<div class="row" style="padding:0px; margin:0px; margin-top:15px; border-radius:15px;">

<div class="ibox" style="border-radius:5px; padding:7px;">
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">

<div class="ibox-head">
<div class="ibox-title"><i class="fas fa-user-tie" style="margin-right:10px;"></i>Edit Receipt</div>
</div>
<div class="ibox-body">
<div class="row">

<div class="col-sm-12 col-md-12 col-lg-12 form-group mb-12" style="font-size:25px; color:Green; text-align:center; border-bottom:1px dashed #666; margin-bottom:25px;">
   Receipt Number :  <?php echo $edit_id; ?>    
</div>

<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
	<label class="form-group mb-4 set-row label_marg"><b>Penalty For<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
			<select class="form-control" name="penalty_for">
			<?php

			$data1	=	array();
			$data1	=	$db->get_all_penalty_category_details();
			
			if(!empty($data1))
				{
					$counter1 =0;
					foreach($data1 as $record1)
					{
						$id				=	$record1[0];
						$res_title		=	$record1[1];
						$amount			=	$record1[5];
			?>
			 <option value="<?php echo $id; ?>" <?php if($id==$penalty_for) { ?> Selected <?php } ?>><?php echo $res_title." : ".$amount; ?></option>
			<?php
				}
			}
			?>
			</select>
	</div>
</div>
<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
	<label class="form-group mb-4 set-row label_marg"><b>Payment Method<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<select class="form-control" name="pay_method">
	    <option value="CASH" <?php if($payment_method=="CASH"){ ?> selected <?php } ?>>CASH</option>
	    <option value="GOOGLE PAY" <?php if($payment_method=="GOOGLE PAY"){ ?> selected <?php } ?>>GOOGLE PAY</option>
	    <option value="PHONE PAY" <?php if($payment_method=="PHONE PAY"){ ?> selected <?php } ?>>PHONE PAY</option>
	    <option value="PAYTM" <?php if($payment_method=="PAYTM"){ ?> selected <?php } ?>>PAYTM</option>
	    <option value="BHIM" <?php if($payment_method=="BHIM"){ ?> selected <?php } ?>>BHIM</option>
	    <option value="AMAZON PAY" <?php if($payment_method=="AMAZON PAY"){ ?> selected <?php } ?>>AMAZON PAY</option>
	    <option value="NEFT" <?php if($payment_method=="NEFT"){ ?> selected <?php } ?>>NEFT</option>
	    <option value="RTGS" <?php if($payment_method=="RTGS"){ ?> selected <?php } ?>>RTGS</option>
	</select>
</div>

<div class="col-sm-12 form-group mb-12" style="text-align:center; padding-left:0px; padding-right:0px; padding-top:20px;">
	<div class="col-sm-4 form-group mb-4" style="margin:auto;">
		<button class="btn btn-pink btn-air" type="submit" name="add" style="width:100%;">UPDATE DETAILS</button>
	</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>

</div>
</div>
<?php include('footer.php'); ?>
</div>
    </div>
    <?php include('search.php'); ?>
   
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    
    <script src="js/jquery.min.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
<script>

$( function()  {
		$( "#birth" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		$( "#join_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		
}  ) ;
		


</script>

    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/idle-timer.min.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
	<script src="datatable/datatables.min.js"></script>
    <script src="js/app.min.js"></script>
	
</body>
</html>