<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Report</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 300px;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
	
</style>

<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
</head>
<body class="fixed-navbar">

<div class="page-wrapper" style="height:800px;">

<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>

<div class="content-wrapper">
<div class="page-content fade-in-up">
<div class="ibox" style="border-radius:5px; padding:7px;">

<div class="ibox-body" style="padding:7px; padding-top:0px;">
<div class="ibox-head">
<div class="ibox-title">Report</div>
</div>
</div>

<br />

<div class="flexbox mb-4">
<div class="input-group-icon input-group-icon-left mr-3">
	<span class="input-icon input-icon-right font-16"><i class="fas fa-search"></i></span>
	<input class="form-control form-control-rounded form-control-solid" id="key-search" type="text" placeholder="Search ...">
</div>
</div>
<div class="table-wrapper-scroll-y my-custom-scrollbar">

<div class="table-responsive" id="table_response">
<table class="table table-bordered table-hover" id="example" >
	<thead class="thead-default thead-lg">
		<tr>
			<th>Sr.No</th>
			<th>Details</th> 
			<th>Date</th> 
			<th>Time</th> 
		</tr>
	</thead>
	<tbody>
	<?php
		$data	=	array();
		$data	=	$db->get_all_entry_details();
		
		if(!empty($data))
			{
				$counter =0;
				$total_amount	=0;

				foreach($data as $record)
				{
					$id					=	$record[0];
					$res_vehicle_id		=	$record[1];
					$res_date			=	$record[2];
					$res_time			=	$record[3];
					
					$record	=	array();
					$record = $db->get_details_by_v_id($res_vehicle_id);

					if(!empty($record))
					{
						$id						=	$record[0];
						$employee_code			=	$record[1];
						$employee_name			=	$record[2];
						$mobile_no				=	$record[3];
						$address				=	$record[4];
						$user_id				=	$record[5];
						$password				=	$record[6];
						$user_type				=	$record[7];
					}	
				?>
					<tr> 
						<td><?php echo $counter+1; ?></td>
						<td style="text-align:left;">					
							<span class="txt">Unique Code:</span><?php echo $employee_code; ?></br>
							<span class="txt">Name:</span><?php echo $res_name; ?></br>
							<span class="txt">Mobile Number:</span><?php echo $res_mobile_no; ?></br>
							<span class="txt">Address:</span><?php echo $res_address; ?></br>
							<span class="txt">Vehicle Id:</span><?php echo $user_id; ?></br>
							<span class="txt">Other Info:</span><?php echo $password; ?></br>
							<span class="txt">Vehicle Type:</span><?php echo $user_type_name; ?></br>
						</td>
						<td><?php echo $res_date; ?></td>
						<td><?php echo $res_time; ?></td>
					</tr>
				<?php
				$counter++;
				}
			}			
			else
			{
			?>
			<td colspan="7">No Data Found...</td>
			<?php
			}
		   ?>
		</tr> 
	</tbody> 
</table> 
</div>
</div>
</div>
</div>
</div>
	</div>
</div>

		<?php include('footer.php'); ?>
	
<?php //include('search.php'); ?>
<!-- END SEARCH PANEL-->
<!-- BEGIN THEME CONFIG PANEL-->

<!-- END THEME CONFIG PANEL-->
<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
<div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- New question dialog-->

<!-- End New question dialog-->
<!-- QUICK SIDEBAR-->
<?php //include('right-side-bar.php'); ?>
<script src="js/jquery.min.js"></script>

<script type="text/javascript">
function submitData()
{	
	if($('#department').val()=="")
	{
	alert("Please Enter Category Title");
	}
	else if($('#description').val()=="")
	{
	alert("Please Enter Description");
	}
	else
	{
	//alert('hii');
	var dep = $("#department").val();
	var desc = $("#description").val();
			
	 $.ajax({
            type:'POST',
            url:'insert_penalty_category.php',
            data:'submitData=1&dep='+dep+'&desc='+desc,
			
			success:function(msg)
                {
                   
                   if(msg == '1')
                    {
                        $('#modalPush').modal('hide');
						alert("Category Added Successfully...!!!");
						location.reload();

                                               
                    }
                    else
                    {
                       alert("Category Already Exists...!!!");
                    }
                }
            });
			}
				
}

 
	</script>


<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->

<!-- CORE SCRIPTS-->
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
<script>
$(function() {
	$('#example').DataTable({
		pageLength: 10,
		fixedHeader: true,
		responsive: true,
		"sDom": 'rtip',
		columnDefs: [{
			targets: 'no-sort',
			orderable: false
		}]
	});

	var table = $('#example').DataTable();
	$('#key-search').on('keyup', function() {
		table.search(this.value).draw();
	});
  
});
</script>
	


    <!-- PAGE LEVEL SCRIPTS-->
</body>

</html>
