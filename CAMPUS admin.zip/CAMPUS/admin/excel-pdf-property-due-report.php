<?php 
require_once('lib/functions.php');

$db		=	new login_function();
ob_start();
if(isset($_GET['option']))
{
	$option			=	$_GET['option'];
	$_SESSION		=	$option;
}
else if(isset($_SESSION['option']))
{
		$option=$_SESSIOn['option'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>EXCEL PDF</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
	 <script src="js/jquery.min.js"></script>
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	text-transform:uppercase;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	text-transform:uppercase;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
</style>
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
	border:1px solid black;
}
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th
{
	text-align:center;
	border:1px solid black;
	font-size:12px;
}
table,td
{
	text-align:left;
	border:1px solid black;
	font-size:12px;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 300px;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
.main_head
{
	width:920px;
	margin:auto;
	font-size:14px;
	
	padding:10px;
	padding-top:0px;
	box-shadow:0px 0px 5px 1px #DFDFDF;
	border:1px solid #CCCCCC;
}	
.main_head>h1,h2,h4,h6
{
	text-align:center;
	margin:5px;
}
.sub_head
{
	border-bottom:1px dashed #CCCCCC;
	background-color:#FCFCFC;
	text-align:center;
	margin-bottom:8px;
	padding-top:10px;
	padding-bottom:10px;
	position:relative;
	line-height:40px;
}
.logo
{
	position: absolute;
	left:50px;
	top:1px;
	height:70px;
	width:70px;
	border-radius:40px;
}
body
{
	font-family:cambria;
	background-color:white;
}
label
{
	text-align:left;
	font-size:16px;
	font-weight:bold;
	margin:4px;
}
.sub_txtline
{
	font-size:14px;
	font-weight:bold;
	line-height:25px;
	font-family:cambria;
	font-weight:bold;
}
h6
{
	font-size:16px !important;
}
thead		
{
	background-color:#efefef;
	font-size:14px;
	font-weight:bold;
	
}	
.table-bordered td, .table-bordered th {
    border: 1px solid black;
	-webkit-print-color-adjust: exact; 
}
.link
{
	background-color:#208F86 !important;
	font-size:17px;
	font-family:cambria;
	color:#FFFFFF;
	padding:10px;
	border-radius:10px;
	font-weight:bold;
	border:1px solid #666;
	margin-top:15px;
}
.table td, .table th {
    padding: .5rem;
    vertical-align: top;
    border-top: 1px solid #e9ecef;
}
</style>
<body style="background-color:white;">
<!----------------TABLE--------------------------->	
<div class="main_head">
<?php
if($option==2)
{
?>
 <div class="sub_head">
 <div class="head_pay_sleep">
<img src="images/mahanagar-palika-logo.png" class="mahanagar-palika-logo" style="height:70px; width:70px;  margin-top:-20px; float:left;" />
<h1 style="margin-bottom:10px;margin-top:25px; font-size:32px;">सोलापूर महानगरपालिका</h1>
</div>

</div>
<?php
}
?>
<h1 style="margin-bottom:10px;margin-top:25px; font-weight:bold; font-size:25px; line-height:25px; margin-top:15px; text-align:center;">Due Report</h1>
<table class="table table-bordered table-hover" id="example" style="width:900px; margin:auto;">
	<thead>
	<tr>
		<th width="5">Sr No</th>
		<th width="50">Property Name</th> 
		<th width="5">Deposite Amount</th> 
		<th width="10">Paid Amount</th> 
		<th width="10">Remaining Amount</th> 
	</tr>
	</thead>
	<tbody>
	<?php
	$data	=	array();
	$data	=	$db->get_all_rented_property_details();
	$total_deposite_amount	=	0;
	$total_sum_of_deposite	=	0;
	$total_remaining_amount	=	0;
	if(!empty($data))
	{
		$counter 	=0;
		$sr_counter	=0;
		
		foreach($data as $record)
		{
			$id						=	$record[0];
			$res_name				=	$record[1];
			$res_mobile_no			=	$record[2];
			$res_address			=	$record[3];
			$other_mobile_no		=	$record[4];
			$res_aadhar_no			=	$record[5];
			$res_image				=	$record[6];
			$res_pan_attach			=	$record[7];
			$res_adhar_attach		=	$record[8];
			$user_id				=	$record[9];
			$password				=	$record[10];
			$frequency_days			=	$record[11];
			$property_issue_date	=	$record[12];
			$desposite_amount		=	$record[13];
			$sum_of_deposite=0;
			$sum_of_deposite=$db->get_sum_of_deposite($id);
			if($sum_of_deposite=='')
			{
				$sum_of_deposite=0;
			}
			$remaining_amount=0;
			$remaining_amount=$desposite_amount-$sum_of_deposite;
			
			$total_deposite_amount	=	$total_deposite_amount+$desposite_amount;
			$total_sum_of_deposite	=	$total_sum_of_deposite+$sum_of_deposite;
			$total_remaining_amount	=	$total_remaining_amount+$remaining_amount;
			if($desposite_amount!=$sum_of_deposite)
			{
			?>
		<tr> 
			<td style="text-align:left;"><span class="txt"><?php echo $sr_counter+1; ?></td>
			<td><?php echo $res_name; ?></td>
			<td style="text-align:center;"><?php echo $desposite_amount; ?></td>
			<td style="text-align:center;"><?php echo $sum_of_deposite; ?></td>
			<td style="text-align:center;"><?php echo $remaining_amount; ?></td>
			
			
	<?php
	$sr_counter++;
	}
	?>
	<tr style="text-align:center !important; font-weight:bold;">
	<td colspan="2" style="text-align:center !important; font-weight:bold;">Total:</td>
	<td style="text-align:center !important; font-weight:bold;"> &#8377 <?php echo $total_deposite_amount; ?></td>
	<td style="text-align:center !important; font-weight:bold;"> &#8377 <?php echo $total_sum_of_deposite; ?></td>
	<td style="text-align:center !important; font-weight:bold;"> &#8377 <?php echo $total_remaining_amount; ?></td>
	</tr>
	<?php
	$counter++;
	}
	
}

else
{
?>
<td colspan="19">No Data Found...</td>
<?php
}
?>
</tr> 
</tbody> 
</table> 
</div>
<!----------------END TABLE------------------------->	
<?php
if($option==1)
{
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename= rented-property.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	ob_end_flush();
}
else
{
?>
	<script>
	window.print();
	</script>
<?php
}
?>

</body>

</html>
