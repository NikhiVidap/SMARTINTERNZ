<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
	if(isset($_GET['p_id']))
	{
		$p_id				=	$_GET['p_id'];
		$_SESSION['p_id'] 	= 	$p_id;
	}
	 else if(isset($_SESSION['p_id']))
	{
		$p_id	= $_SESSION['p_id'];
	}
$record	=	array();
$record	=	$db->get_all_penalty_details_report_by_id($p_id);
if(!empty($record))
{

	$id					=	$record[0];
	$image1				=	$record[1];
	$image2				=	$record[2];
	$image3				=	$record[3];
	$image4				=	$record[4];
	$name				=	$record[5];
	$address			=	$record[6];
	$mobile_no			=	$record[7];
	$penalty_for		=	$record[8];
	$penalty_amount		=	$record[9];
	$status				=	$record[10];
	$payment_method		=	$record[11];
	$payment_description=	$record[12];
	$note				=	$record[13];
	$user_id			=	$record[14];
	$living_address		=	$record[17];
	$random_string		=	$record[18];
	$res_date		    =	$record[15];
}
$from_data = explode("-",$res_date);
$res_date = $from_data[2]."-".$from_data[1]."-".$from_data[0];
function getIndianCurrency($number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
    $digits = array('', 'hundred','thousand','lakh', 'crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Receipt</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
			.mid-section
			{
				min-height:450px;
				width:500px;
				margin:auto;
				font-family:cambria;
				margin-top:100px;
				//border:1px solid black;
			}
			.header-contain
			{
				display:inline-table;
				float:left;
				padding:10px;
			}
			
			h3
			{
				text-align:center;
				text-transform:uppercase;
			}
			.name-data
			{
				font-weight:bold;
				font-size:13px;
				
			}
			
			.footer-data
			{
				text-transform:uppercase;				
				line-height:22px;
				font-size:14px;
				float:right;	
				margin-right:20px;
				text-align:center;
			}
			.label-data
			{
				font-weight:bold;
				font-size:13px;
				display:inline-table;
			}
			table
			{
				font-size:15px;
			}
			th
			{
				
				padding:3px;
				text-align:center;
				border:1px solid black;
			}
			td
			{
				padding:5px;
				border:1px solid black;
			}
			.info
			{
				display:inline-table;
				width:105px;
				margin-right:5px;
			}
			@media print {
			  @page { margin: 0; }
			  body { margin: 0.6cm; }
			}
			.mahanagar-palika-logo
			{
				position: absolute;
				left:5px;
				top:11px;
				height:90px;
				width:90px;
				border-radius:40px;
			}
			.left_image
			{
				position: absolute;
				right:5px;
				top:11px;
				height:90px;
				width:90px;
				border-radius:40px;
			}
			.head_pay_sleep
			{
				border-bottom:1px dashed #CCCCCC;
				background-color:#FCFCFC;
				text-align:center;
				margin-bottom:8px;
				padding-top:2px;
				padding-bottom:10px;
				position:relative;
				line-height:24px;
			}
		</style>
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
</head>
<body style="background-color:white;">
<div class="mid-section">
	<div class="head_pay_sleep">
				<img src="images/mahanagar-palika-logo.png" class="mahanagar-palika-logo" style="height:70px; width:70px; margin-top:0px;" />
	<h1 style="margin-bottom:10px;margin-top:25px; font-size:32px; margin-left:2px;">सोलापूर महानगरपालिका </h1>
	<div style="font-size:16px;">घनकचरा व्यवस्थापन  विभाग </div>
	<img src="images/left-image.png" class="left_image" style="height:80px; width:80px; margin-top:0px;" />
			 <br /></div>

	<div style="height:30px;margin-bottom:0px;float:right; margin-top:10px;">
		<div class="label-data">प्रशासकीय शुल्क /दंडात्मक शुल्क </div> <br />
		<div class="label-data" style="margin-top:0px;" >दिनांक  - <?php echo $res_date; ?></div>	
	</div>
	<br /> <br />
	<div class="data" style="margin:0px;">
		 <p class="name-data">
		 <div class="info">नंबर </div> - <b><?php echo $p_id; ?></b><br />
		<div class="info">श्री / श्रीमती  </div> - <b><?php echo $name; ?></b><br />
		<div class="info">राहण्याचा पत्ता</div> - <b><?php echo $living_address; ?></b><br />
		<div class="info">पत्ता            </div> - <b><?php echo $address; ?>    यांचेकडून </b><br /> <br /> 
	<div style="height:200px;margin-bottom:0px; width:100%; ">
	<?php
	if($penalty_for!='')
	{
	$pdata=explode(",",$penalty_for);
	$count=count($pdata);
	$j=1;
	for($i=0;$i<$count;$i++)
	{
		
		$res_penalty_name="";
		$res_penalty_name=$db->get_penalty_name($pdata[$i]);
		$res_penalty_amount=$db->get_penalty_amount($pdata[$i]);
	?>
	 <span style="font-weight:bold; "> <?php echo $j.")".$res_penalty_name; ?>-<span style="margin-left:20px;"><?php echo $res_penalty_amount; ?></span></span>  <br /> 
	<?php
		$j++;
	}
	}
	?>
	<div style="width:100%;">
	<?php
	if($image1!="" AND strpos($image1, '.') !== false )
	{
	?>
	<a href="../api/post_images/<?php echo $image1; ?>" target="_blank"><img src="../api/post_images/<?php echo $image1; ?>" height="50px" width="50px"></a>

	<?php
	}
	?>
		<?php
	if($image2!="" AND strpos($image2, '.') !== false )
	{
	?>
	<a href="../api/post_images/<?php echo $image2; ?>" target="_blank"><img src="../api/post_images/<?php echo $image2; ?>" height="50px" width="50px"></a>

	<?php
	}
	?>

	<?php
	if($image3!="" AND strpos($image3, '.') !== false )
	{
	?>
	<a href="../api/post_images/<?php echo $image3; ?>" target="_blank"><img src="../api/post_images/<?php echo $image3; ?>" height="50px" width="50px"></a>

	<?php
	}
	?>

	<?php
	if($image4!="" AND strpos($image4, '.') !== false )
	{
	?>
	<a href="../api/post_images/<?php echo $image4; ?>" target="_blank"><img src="../api/post_images/<?php echo $image4; ?>" height="50px" width="50px"></a>

	<?php
	}
	?>
	
	</div>
	<br />
	 <div class="info">इतर </div> - <b><?php echo $note; ?></b><br />
	  <div class="info">रु </div> - <b><?php echo $penalty_amount; ?></b><br />
	 <div  style="100%;">रक्कम रु अक्षरी   - <b><?php  echo getIndianCurrency($penalty_amount)." Only"; ?></b> <br />मिळाले . </div>
	</div>
	<br /><br />
			<p class="footer-data"><b>सोलापूर महानगरपालिका </b><br />
			
	</div>
		
</div>


	</body>
</html>