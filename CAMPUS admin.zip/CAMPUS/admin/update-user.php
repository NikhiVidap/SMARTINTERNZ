<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
if(isset($_GET['edit_id']))
{
	$edit_id				=	$_GET['edit_id'];
	$_SESSION['edit_id'] 	= $edit_id;
}
else if(isset($_SESSION['edit_id']))
{
	$edit_id	= $_SESSION['edit_id'];
}
$flag			=	0;
$employee_name	=	"";
$employee_code	=	"";
$mobile_no		=	"";
$address		=	"";
$user_id		=	"";
$password		=	"";
$user_id		=	"";
$password		=	"";
$user_type		=	"";
if(isset($_POST['add']))
{	
	$employee_code	= $_POST['employee_code'];
	$employee_name	= $_POST['employee_name'];
	$mobile_no 		= $_POST['mobile_no'];
	$address 		= $_POST['address'];
	$user_id 		= $_POST['user_id'];
	$password 		= $_POST['password'];
	$user_type 			= $_POST['user_type'];
	if(strlen($mobile_no)!=10)
	{
	?>
	<script type="text/javascript">
	alert("Please Enter 10 digit Contact Number");

	</script>
	<?php
	$flag				=	1;	
	}
	if($flag==0)
	{
	
		if($db->update_collection_agent_master($employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$edit_id,$user_type))
		{
		?>
			<script>
			alert("User Successfully Updated..!!!");
			window.location.href="update-user.php";
			</script>
		<?php
			
		}
		else
		{
			?>
			<script>
			alert("Details Failed to Add...!!!");
			</script>
		<?php
			
		}
	
	}

}
$record	=	array();
$record = $db->get_collection_details_by_id($edit_id);

if(!empty($record))
{
	$id						=	$record[0];
	$employee_code			=	$record[1];
	$employee_name			=	$record[2];
	$mobile_no				=	$record[3];
	$address				=	$record[4];
	$user_id				=	$record[5];
	$password				=	$record[6];
	$user_type				=	$record[7];
}	
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Update</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	<link href="datatable/datatables.min.css" rel="stylesheet" />

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	<script>
	function validateForm() {
	  var j = document.forms["myForm"]["employee_code"].value;
	  var a = document.forms["myForm"]["employee_name"].value;
	  var f = document.forms["myForm"]["mobile_no"].value;
	  var g = document.forms["myForm"]["address"].value;
	  var h = document.forms["myForm"]["user_id"].value;
	  var i = document.forms["myForm"]["password"].value;
	  var m = document.forms["myForm"]["user_type"].value;
	    if (m == "select") {
		alert("Select User Type");
		return false;
	  }
	 if (j == "") {
		alert("Enter Employee Code");
		return false;
	  }
	  if (a == "") {
		alert("Enter  Name");
		return false;
	  }
	 if (f == "") {
		alert("Enter  Mobile Number");
		return false;
	  }
	  if (g == "") {
		alert("Enter Address");
		return false;
	  }
	   if (h == "") {
		alert("Enter User Id");
		return false;
	  }
	   if (i == "") {
		alert("Enter Password");
		return false;
	  }
	  
	}
	</script>
	

</head>
<body class="fixed-navbar">
  
<div class="page-wrapper" style="min-height:500px;">
<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>
<div class="content-wrapper">
<div class="row" style="padding:0px; margin:0px; margin-top:15px; border-radius:15px;">

<div class="ibox" style="border-radius:5px; padding:7px;">
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">

<div class="ibox-head">
<div class="ibox-title"><i class="fas fa-user-tie" style="margin-right:10px;"></i>Update User</div>
</div>
<div class="ibox-body">
<div class="row">
<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
	<label class="form-group mb-4 set-row label_marg"><b>Vehicle Type<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<select name="user_type" class="form-control form-control-air">
		<option value="select" <?php if($user_type=='select') { ?> Selected <?php } ?>>Select User Type</option>
		<option value="0" <?php if($user_type=='0') { ?> Selected <?php } ?>>2 Wheeler</option>
		<option value="1" <?php if($user_type=='1') { ?> Selected <?php } ?>>3 Wheeler</option>
		<option value="2" <?php if($user_type=='2') { ?> Selected <?php } ?>>4 Wheeler</option>
		</select>
	</div>
</div>
<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
	<label class="form-group mb-4 set-row label_marg"><b>Member Unique Code<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-user"></i></span>
		<input type="text" class="form-control form-control-air" name="employee_code" placeholder="Enter Member Unique Code" value="<?php echo $employee_code; ?>"   />
	</div>
</div>
<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
	<label class="form-group mb-4 set-row label_marg"><b>Name<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-user"></i></span>
		<input class="form-control form-control-air" name="employee_name" placeholder="Enter Name" value="<?php echo $employee_name; ?>"   />
	</div>
</div>
<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
<label class="form-group mb-4 set-row label_marg"><b>Mobile Number<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-phone"></i></span>
		<input class="form-control form-control-air" type="number" name="mobile_no" placeholder="Enter Mobile Number" value="<?php echo $mobile_no; ?>"   />
	</div>
</div>
<div class="col-sm-6 col-md-6 col-lg-6 form-group mb-6">
	<label class="form-group mb-4 set-row label_marg"><b>Address<span style="color:red; padding:5px; font-weight:bold; font-size:16px; ">*</span></b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-map-marker"></i></span>
		<textarea class="form-control form-control-air" name="address" id="address" placeholder="Enter Address" /><?php echo $address; ?></textarea>
	</div>
</div>

<div class="col-sm-3 col-md-3 col-lg-63form-group mb-3">
	<label class="form-group mb-4 set-row label_marg"><b>Vehicle Id</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-phone"></i></span>
		<input type="text" name="user_id" class="form-control form-control-air" value="<?php echo $user_id; ?>" placeholder="Enter Vehicle ID"   />
	</div>
</div>

<div class="col-sm-3 col-md-3 col-lg-3 form-group mb-3">
	<label class="form-group mb-4 set-row label_marg"><b>Other Information</b></label>
	<div class="input-group-icon input-group-icon-left  set-row">
		<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
		<input type="text" name="password" id="aadhar_no" class="form-control form-control-air" value="<?php echo $password; ?>" placeholder="Enter Other Information"  />
	</div>
</div>



<div class="col-sm-12 form-group mb-12" style="text-align:center; padding-left:0px; padding-right:0px; padding-top:20px;">
	<div class="col-sm-4 form-group mb-4" style="margin:auto;">
		<button class="btn btn-pink btn-air" type="submit" name="add" style="width:100%;" onclick="submitData()">UPDATE DETAILS</button>
	</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>

</div>
</div>
<?php include('footer.php'); ?>
</div>
    </div>
    <?php include('search.php'); ?>
   
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    
    <script src="js/jquery.min.js"></script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
<script>

$( function()  {
		$( "#birth" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		$( "#join_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		
}  ) ;
		


</script>

    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/jquery.slimscroll.min.js"></script>
    <script src="js/idle-timer.min.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/bootstrap-select.min.js"></script>
	<script src="datatable/datatables.min.js"></script>
    <script src="js/app.min.js"></script>
	
</body>
</html>