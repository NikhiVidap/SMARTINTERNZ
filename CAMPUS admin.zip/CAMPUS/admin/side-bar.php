<style>
.table-responsive
{
	font-size:11px !important;
}
tr th
{
	background-color:#DE1559 !important;
	color:#FFFFFF !important;
	font-size:12px;
}
tr td
{
	color:#000000 !important;
	font-size:12px;
}
.company_logo
{
	color:#DAAADB !important;
	font-size:12px !important;
	width:200px !important;
}
.company_logo:hover
{
	text-decoration:underline;
	color:#98E0AD !important;
}
.label_marg
{
	margin-bottom:4px !important;
	font-size:12px;
	color:#232B99;
	text-transform:uppercase;
}
.form-control
{
	color:#333 !important;
	
}
.ibox-title
{
	font-size:22px !important;
	color:#DE1559 !important;
}
.content-wrapper
{
	padding-top:65px !important;
	//background-image:url('images/back6.jpg');
	background-size:100% 100%;
	background-repeat: no-repeat;
	min-height:1000px !important;
}
.ibox .ibox-head {
	border-bottom: 1px dotted #f75a5f !important;
}
.mb-4
{
	margin-bottom:4px !important;
	font-size:12px;
	color:#232B99;
}
.mb6
{
	margin-bottom:4px !important;
	font-size:12px;
	color:red;
}
hr 
{
	
	border-bottom: 1px dotted #232B99 !important;

}
</style>
<header class="header">
	<div class="page-brand" style="background-color:#000;">
		<a href="dashboard.php">
			<span class="brand" style="font-size:15px; font-weight:bold;"><?php echo $project_title; ?></span>
			
		</a>
	</div>
	<div class="flexbox flex-1">
		<!-- START TOP-LEFT TOOLBAR-->
		<ul class="nav navbar-toolbar">
			<li>
				<a class="nav-link sidebar-toggler js-sidebar-toggler" href="javascript:;">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
			</li>
			<li>
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>"><img src="/admin/images/refresh-button.png" title="Refresh" style="height:22px; float:right;" /> </a>
			</li>
			
				<!--<a class="nav-link search-toggler js-search-toggler"><i class="fas fa-search"></i>
					<span>Search here...</span>
				</a>-->
			
		</ul>
		
	</div>
</header>
<nav class="page-sidebar" id="sidebar" style="background-color:#333333;">
	<div id="sidebar-collapse">
		<ul class="side-menu metismenu">
		<li>
			<a href="dashboard.php"><i class="sidebar-item-icon fas fa-home"></i>
			<span class="nav-label">DASHBOARD</span></a>
		</li>
		<!--
			<li>
				<a href="rented-property-master.php"><i class="sidebar-item-icon fas fa-user-tie "></i>
				<span class="nav-label">Rented Property Master</span></a>
			</li>
			
			<li>
				<a href="deposite-collection.php"><i class="sidebar-item-icon fas fa-inr"></i>
				<span class="nav-label">Deposite Collection</span></a>
			</li>
			<li>
				<a href="deposite-collection-report.php"><i class="sidebar-item-icon fas fa-inr"></i>
				<span class="nav-label">Deposite Collection Report</span></a>
			</li>
			<li>
				<a href="property-due-report.php"><i class="sidebar-item-icon fas fa-inr"></i>
				<span class="nav-label">Due Report</span></a>
			</li>
			-->
			<li>
				<a href="users.php"><i class="sidebar-item-icon fas fa-user-tie "></i>
				<span class="nav-label">Allowed Users</span></a>
			</li>
			
			<li>
				<a href="vehicle-entry-report.php"><i class="sidebar-item-icon fas fa-box"></i>
				<span class="nav-label">Vehicle In/Out Report</span></a>
			</li>
			
			
			<li>
				<a href="report-for-chalan.php"><i class="sidebar-item-icon fas fa-box"></i>
				<span class="nav-label">Create Chalan</span></a>
			</li>
			<li>
				<a href="chalan-report.php"><i class="sidebar-item-icon fas fa-box"></i>
				<span class="nav-label">Chalan Report</span></a>
			</li>
			<li>
				<a href="chalan-summary.php"><i class="sidebar-item-icon fas fa-list"></i>
				<span class="nav-label">Chalan Summary</span></a>
			</li>
			<li>
				<a href="online-payment-report.php"><i class="sidebar-item-icon fas fa-list"></i>
				<span class="nav-label">Online Payment Report</span></a>
			</li>
		<li>
		<a href="javascript:;"><i class="sidebar-item-icon fas fa-cog"></i>
			<span class="nav-label">SETTING</span><i class="fas fa-angle-left arrow"></i></a>
		<ul class="nav-2-level collapse">
			<!--<li>
				<a href="income-source-category-master.php"><i class="sidebar-item-icon fas fa-box"></i>
				<span class="nav-label">Income Source Category Master</span></a>
			</li>-->
			<li>
				<a href="penalty-category-master.php"><i class="sidebar-item-icon fas fa-box"></i>
				<span class="nav-label">Penalty Category</span></a>
			</li>
			
			<!--<li>
				<a href="change-password.php"><i class="sidebar-item-icon fas fa-lock"></i>
				<span class="nav-label">CHANGE PASSWORD</span></a>
				</li>-->
				<li>
				<a href="db-backup.php"><i class="sidebar-item-icon fas fa-database"></i>
				<span class="nav-label">DATABASE BACKUP</span></a>
			</li>
			</ul>
		</li>
		<div class="sidebar-footer" style="background-color:#000;">
			<a href="index.php?logout"><i class="fas fa-power-off"></i></a>
			<a href="http://www.dreamtechnology.in" class="company_logo">Software by <br /> Dream Technology</a>
		</div>
	</div>
</nav>