<?php
 session_start();
header( 'Content-Type: text/html; charset=utf-8');
date_default_timezone_set("Asia/Kolkata");

$project_title  =   "CAMPUS";
    	
class login_function
{
	private $con;
	
	function __construct()
	{
		$this->con = new mysqli("localhost","root","","dtdigita_penalty");
		//$this->con = new mysqli("localhost","dtdigita_newadmi","2=p2Md&MPdCa","dtdigita_newpenalty");
		mysqli_set_charset($this->con, 'utf8');
	}
	function get_category_details($department)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `category_master` WHERE `title`=?"))
		{	
			$stmt_insert->bind_param("s",$department);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	
	function get_designation_name($department)
	{
		if($stmt_insert = $this->con->prepare("SELECT `title` FROM `category_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("i",$department);
			
			$stmt_insert->bind_result($res_department);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_department;
				}
				return false;
			}	
		}
	}
	
	function create_category($department,$description)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		
		if($stmt_insert = $this->con->prepare("INSERT INTO `category_master`(`title`, `description`, `date`, `time`) VALUES (?,?,?,?)"))
		{
		
			$stmt_insert->bind_param("ssss",$department,$description,$date,$time);
			
			if($stmt_insert->execute())
			{ 
				return true;
			}
			return false;
		} 
	}
	
	function get_all_category_details()
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `title`, `description`, `date`, `time` FROM `category_master`"))
		{	
			$stmt_insert->bind_result($id,$res_department,$res_description,$date,$time);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]	=	$id;
					$details[$counter][1]	=	$res_department;
					$details[$counter][2]	=	$res_description;
					$details[$counter][3]	=	$date;
					$details[$counter][4]	=	$time;
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	
	function get_all_entry_details()
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `vehicle_id`, `date`, `time` FROM `entry_records`"))
		{	
			$stmt_insert->bind_result($id,$vehicle_id,$date,$time);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]	=	$id;
					$details[$counter][1]	=	$vehicle_id;
					$details[$counter][2]	=	$date;
					$details[$counter][3]	=	$time;
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	
	function delete_category($del)
	{
		if($stmt_select = $this->con->prepare("DELETE FROM `category_master` WHERE `id`=?"))
		{
			$stmt_select->bind_param("i",$del);
		
			if($stmt_select->execute())
			{					
					return true;
			}
				return false;
		}
	}
	function get_category_by_id($edit_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `title`,`description` FROM `category_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("i",$edit_id);
			$stmt_insert->bind_result($id,$department,$description);
			
			if($stmt_insert->execute())
			{
				$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]	=	$id;
					$details[1]	=	$department;
					$details[2]	=	$description;
					
					return $details;
				}
				return false;
			}	
		}
	}
	
	function update_categoty($department,$description,$edit_id)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		if($stmt_select = $this->con->prepare("UPDATE `category_master` SET `title`=?,`description`=?,`date`=? ,`time`=?  WHERE `id`=?"))
		{	
			$stmt_select->bind_param("ssssi",$department,$description,$date,$time,$edit_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_category($department,$description,$edit_id)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		if($stmt_select = $this->con->prepare("UPDATE `category_master` SET `title`=?,`description`=?,`date`=? ,`time`=?  WHERE `id`=?"))
		{	
			$stmt_select->bind_param("ssssi",$department,$description,$date,$time,$edit_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function get_admin_password($email_id)
	{
		if($stmt=$this->con->prepare("SELECT `password` FROM `admin` WHERE `email`=?"))
		{
			$stmt->bind_param("s",$email_id);
			
			$stmt->bind_result($res_password);
			
			if($stmt->execute())
			{
				if($stmt->fetch())
				{
					return $res_password;
				}
			}
			else
			{
				return false;
			}
		}
	}
	function update_admin_new_password($new_password,$admin_email_id)
	{
		if($stmt=$this->con->prepare("UPDATE `admin` SET `password`=? WHERE `email`=?"))
		{
			$stmt->bind_param("ss",$new_password,$admin_email_id);
			
			
			if($stmt->execute())
			{
				return $new_password;
			}
			else
			{
				return false;
			}
		}
	}
	//rent proerty
	
	function get_rented_exist_id($mobile_no)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `rented_property_master` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$mobile_no);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	
	
	function get_all_rented_property_details()
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `name`, `mobile_no`, `address`, `other_mobile_no`, `aadhar_no`, `image`, `pan_attach`, `adhar_attach`,`user_id`,`password`,`frequency_days`,`property_issue_date`,
		`payble_deposite_amount`,`property_type`, `income_source`, `property_photo1`, `property_photo2`, `property_photo3`, `property_photo4` FROM `rented_property_master` "))
		{	
			$stmt_insert->bind_result($id,$res_name,$res_mobile_no,
			$res_address,$other_mobile_no,$res_aadhar_no,$res_image,$res_pan_attach,$res_aadhar_attach,$user_id,$password,$frequency_days,$property_issue_date,$payble_deposite_amount,$property_type,$income_source,$property_photo1,$property_photo2,$property_photo3,$property_photo4);
			
			if($stmt_insert->execute())
			{
				$counter	=	0;
				$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]	=	$id;
					$details[$counter][1]	=	$res_name;
					$details[$counter][2]	=	$res_mobile_no;
					$details[$counter][3]	=	$res_address;
					$details[$counter][4]	=	$other_mobile_no;
					$details[$counter][5]	=	$res_aadhar_no;
					$details[$counter][6]	=	$res_image;
					$details[$counter][7]	=	$res_pan_attach;
					$details[$counter][8]	=	$res_aadhar_attach;
					$details[$counter][9]	=	$user_id;
					$details[$counter][10]	=	$password;
					$details[$counter][11]	=	$frequency_days;
					$details[$counter][12]	=	$property_issue_date;
					$details[$counter][13]	=	$payble_deposite_amount;
					$details[$counter][14]	=	$property_type;
					$details[$counter][15]	=	$income_source;
					$details[$counter][16]	=	$property_photo1;
					$details[$counter][17]	=	$property_photo2;
					$details[$counter][18]	=	$property_photo3;
					$details[$counter][19]	=	$property_photo4;
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	function create_rented_property_master($employee_name,$mobile_no,$address,$other_mobile_no,$aadhar_no,$actual_image,$actual_pan_attach,$actual_adhar_attach,$user_id,$password,$frequency_days,$property_issue_date,$payble_deposite_amount,$property_type,$income_source,$actual_property_photo1,$actual_property_photo2,$actual_property_photo3,$actual_property_photo4)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		
		if($stmt_insert = $this->con->prepare("INSERT INTO `rented_property_master`(`name`, `mobile_no`, `address`, `other_mobile_no`, `aadhar_no`, `image`, `pan_attach`, `adhar_attach`, `date`, `time`,`user_id`,`password`,`frequency_days`,
		`property_issue_date`,`payble_deposite_amount`,`property_type`, `income_source`, `property_photo1`, `property_photo2`, `property_photo3`, `property_photo4`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"))
		{
		
			$stmt_insert->bind_param("sssssssssssssssssssss",$employee_name,$mobile_no,$address,$other_mobile_no,$aadhar_no,$actual_image,$actual_pan_attach,$actual_adhar_attach,$date,$time,$user_id,$password,$frequency_days,$property_issue_date,$payble_deposite_amount,$property_type,$income_source,$actual_property_photo1,$actual_property_photo2,$actual_property_photo3,$actual_property_photo4);
			
			if($stmt_insert->execute())
			{ 
				return true;
			}
			return false;
		} 
	}
	function delete_rented_property($del)
	{
		if($stmt_select = $this->con->prepare("DELETE FROM `rented_property_master` WHERE `id`=?"))
		{
			$stmt_select->bind_param("i",$del);
		
			if($stmt_select->execute())
			{					
					return true;
			}
				return false;
		}
	}
	
	function get_collection_agent_exist_id($employee_code)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `collection_agent` WHERE `employee_code`=?"))
		{	
			$stmt_insert->bind_param("s",$employee_code);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	
	function get_vehicle_id_exist_id($vehicle_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$vehicle_id);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	
	function create_collection_agent_master($employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$user_type)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		$fine_entries	=	"";
		if($stmt_insert = $this->con->prepare("INSERT INTO `collection_agent`(`employee_code`, `employee_name`, `mobile_no`, `address`, `user_id`, `password`, `date`, `time`,`user_type`,`fine_entries`) VALUES  (?,?,?,?,?,?,?,?,?,?)"))
		{		
			$stmt_insert->bind_param("ssssssssss",$employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$date,$time,$user_type,$fine_entries);
			
			if($stmt_insert->execute())
			{ 
				return true;
			}
			return false;
		} 
	}
	
	function save_entry_record($vehicle_id)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");

		if($stmt_insert = $this->con->prepare("INSERT INTO `entry_records`(`vehicle_id`, `date`, `time`) VALUES (?,?,?)"))
		{		
			$stmt_insert->bind_param("sss",$vehicle_id,$date,$time);
			
			if($stmt_insert->execute())
			{ 
				return true;
			}
			return false;
		} 
	}
	
	function get_all_collection_agent_details()
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `employee_code`, `employee_name`, `mobile_no`, `address`, `user_id`, `password`,`user_type`,`user_status` FROM `collection_agent` "))
		{	
			$stmt_insert->bind_result($id,$employee_code,$employee_name,
			$mobile_no,$address,$user_id,$password,$user_type,$user_status);
			
			if($stmt_insert->execute())
			{
				$counter	=	0;
				$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]	=	$id;
					$details[$counter][1]	=	$employee_code;
					$details[$counter][2]	=	$employee_name;
					$details[$counter][3]	=	$mobile_no;
					$details[$counter][4]	=	$address;
					$details[$counter][5]	=	$user_id;
					$details[$counter][6]	=	$password;
					$details[$counter][7]	=	$user_type;
					$details[$counter][8]	=	$user_status;
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	
	function get_agent_penalty_data($agent_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `fine_entries` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$agent_id);
			
			$stmt_insert->bind_result($fine_entries);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $fine_entries;
				}
				return false;
			}	
		}
	}
	
	function get_rent_property_details_by_id($edit_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `name`, `mobile_no`, `address`, `other_mobile_no`, `aadhar_no`, `image`, `pan_attach`, `adhar_attach`,`user_id`,`password`,`frequency_days`,`property_issue_date`,
		`payble_deposite_amount`,`property_type`, `income_source`, `property_photo1`, `property_photo2`, `property_photo3`, `property_photo4` FROM `rented_property_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("i",$edit_id);
			$stmt_insert->bind_result($id,$res_name,$mobile_no,$address,$other_mobile_no,$aadhar_no,$image,$pan_attach,$adhar_attach,$user_id,$password,$frequency_days,$property_issue_date,$payble_deposite_amount,$property_type,$income_source,$property_photo1,$property_photo2,$property_photo3,$property_photo4);
			
			if($stmt_insert->execute())
			{
				$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]	=	$id;
					$details[1]	=	$res_name;
					$details[2]	=	$mobile_no;
					$details[3]	=	$address;
					$details[4]	=	$other_mobile_no;
					$details[5]	=	$aadhar_no;
					$details[6]	=	$image;
					$details[7]	=	$pan_attach;
					$details[8]	=	$adhar_attach;
					$details[9]	=	$user_id;
					$details[10]=	$password;
					$details[11]=	$frequency_days;
					$details[12]=	$property_issue_date;
					$details[13]=	$payble_deposite_amount;
					$details[14]	=	$property_type;
					$details[15]	=	$income_source;
					$details[16]	=	$property_photo1;
					$details[17]	=	$property_photo2;
					$details[18]	=	$property_photo3;
					$details[19]	=	$property_photo4;
					return $details;
				}
				return false;
			}	
		}
	}
	function update_rented_property_master($employee_name,$mobile_no,$address,$other_mobile_no,$aadhar_no,$edit_id,$user_id,$password,$frequency_days,$property_issue_date,$payble_deposite_amount,$property_type,$income_source)
	{
		if($stmt=$this->con->prepare("UPDATE `rented_property_master` SET `name`=?,`mobile_no`=?,`address`=?,`other_mobile_no`=?,`aadhar_no`=?,`user_id`=?,`password`=?,`frequency_days`=?,`property_issue_date`=?,`payble_deposite_amount`=?,`property_type`=?,`income_source`=?  WHERE `id`=?"))
		{
			$stmt->bind_param("ssssssssssssi",$employee_name,$mobile_no,$address,$other_mobile_no,$aadhar_no,$user_id,$password,$frequency_days,$property_issue_date,$payble_deposite_amount,$property_type,$income_source,$edit_id);
			
			
			if($stmt->execute())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	function update_employee_image($up_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `image`='' WHERE `id`=?"))
		{	
			$stmt_select->bind_param("i",$up_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	
	function update_employee_pancard($pan_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `pan_attach`='' WHERE `id`=?"))
		{	
			$stmt_select->bind_param("i",$pan_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	
	function update_employee_adharcard($adhar_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `adhar_attach`='' WHERE `id`=?"))
		{	
			$stmt_select->bind_param("i",$adhar_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_employee_pancard_attach($actual_pan_attach,$adhar_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `pan_attach`=? WHERE `id`=?"))
		{	
			$stmt_select->bind_param("si",$actual_pan_attach,$adhar_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	
	function update_employee_adhar_attach($actual_adhar_attach,$adhar_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `adhar_attach`=? WHERE `id`=?"))
		{	
			$stmt_select->bind_param("si",$actual_adhar_attach,$adhar_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	
	function update_employee_image_attach($actual_image,$img_id)
	{ 
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `image`=? WHERE `id`=?"))
		{	
			$stmt_select->bind_param("si",$actual_image,$img_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	
	function update_collection_agent_master($employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$edit_id,$user_type)
	{
		if($stmt_select = $this->con->prepare("UPDATE `collection_agent` SET `employee_code`=?,`employee_name`=?,`mobile_no`=?,`address`=?,`user_id`=?,`password`=? ,`user_type`=? WHERE `id`=?"))
		{	
			$stmt_select->bind_param("sssssssi",$employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$user_type,$edit_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function get_collection_details_by_id($edit_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `employee_code`, `employee_name`, `mobile_no`, `address`, `user_id`, `password`,`user_type` FROM `collection_agent` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("i",$edit_id);
			$stmt_insert->bind_result($id,$employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$user_type);
			
			if($stmt_insert->execute())
			{
				$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]	=	$id;
					$details[1]	=	$employee_code;
					$details[2]	=	$employee_name;
					$details[3]	=	$mobile_no;
					$details[4]	=	$address;
					$details[5]	=	$user_id;
					$details[6]	=	$password;
					$details[7]	=	$user_type;
					return $details;
				}
				return false;
			}	
		}
	}
	
	function get_details_by_v_id($edit_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `employee_code`, `employee_name`, `mobile_no`, `address`, `user_id`, `password`,`user_type` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("i",$edit_id);
			
			$stmt_insert->bind_result($id,$employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$user_type);
			
			if($stmt_insert->execute())
			{
				$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]	=	$id;
					$details[1]	=	$employee_code;
					$details[2]	=	$employee_name;
					$details[3]	=	$mobile_no;
					$details[4]	=	$address;
					$details[5]	=	$user_id;
					$details[6]	=	$password;
					$details[7]	=	$user_type;
					return $details;
				}
				return false;
			}	
		}
	}
	
	function get_collection_details_by_user_id($agent_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `employee_code`, `employee_name`, `mobile_no`, `address`, `user_id`, `password`,`user_type` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$agent_id);
			$stmt_insert->bind_result($id,$employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$user_type);
			
			if($stmt_insert->execute())
			{
				$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]	=	$id;
					$details[1]	=	$employee_code;
					$details[2]	=	$employee_name;
					$details[3]	=	$mobile_no;
					$details[4]	=	$address;
					$details[5]	=	$user_id;
					$details[6]	=	$password;
					$details[7]	=	$user_type;
					return $details;
				}
				return false;
			}	
		}
	}
	
	function get_collection_agent_password($user_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `password` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$user_id);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	function get_collection_password_mobile_password($user_id)
	{
		
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `collection_agent` WHERE `mobile_no`=?"))
		{	
			
			$stmt_insert->bind_param("s",$user_id);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				
				if($stmt_insert->fetch())
				{
					
					return $res_id;
				}
				return false;
			}	
		}
	}
	function get_collection_agent_type($user_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `user_type` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$user_id);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	function get_rent_profile_details_api($user_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `name`, `mobile_no`, `address`, `other_mobile_no`, `aadhar_no`, `image`, `pan_attach`, `adhar_attach`,`user_id`,`password` FROM `rented_property_master` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$user_id);
			$stmt_insert->bind_result($id,$res_name,$mobile_no,$address,$other_mobile_no,$aadhar_no,$image,$pan_attach,$adhar_attach,$user_id,$password);
			
			if($stmt_insert->execute())
			{
				$details	=	array();
				if($stmt_insert->fetch())
				{
					$details['id']				=	$id;
					$details['name']			=	$res_name;
					$details['mobile_no']		=	$mobile_no;
					$details['address']			=	$address;
					$details['other_mobile_no']	=	$other_mobile_no;
					$details['aadhar_no']		=	$aadhar_no;
					$details['image']			=	$image;
					$details['pan_attach']		=	$pan_attach;
					$details['adhar_attach']	=	$adhar_attach;
					$details['user_id']			=	$user_id;
					$details['password']		=	$password;
					
					return $details;
				}
				return false;
			}	
		}
	}
	function get_collection_agent_profile_details_api($user_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `employee_code`, `employee_name`, `mobile_no`, `address`, `user_id`, `password`,`user_type` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$user_id);
			$stmt_insert->bind_result($id,$employee_code,$employee_name,$mobile_no,$address,$user_id,$password,$user_type);
			
			if($stmt_insert->execute())
			{
				$details	=	array();
				if($stmt_insert->fetch())
				{
					$details['id']				=	$id;
					$details['employee_code']	=	$employee_code;
					$details['employee_name']	=	$employee_name;
					$details['mobile_no']		=	$mobile_no;
					$details['address']			=	$address;
					$details['user_id']			=	$user_id;
					$details['password']		=	$password;
					$details['user_type']		=	$user_type;
					return $details;
				}
				return false;
			}	
		}
	}
	function update_collection_agent_new_password($new_password,$user_id)
	{ 
		if($stmt=$this->con->prepare("UPDATE `collection_agent` SET `password`=? WHERE `user_id`=?"))
		{ 
			$stmt->bind_param("ss",$new_password,$user_id);
			
			
			if($stmt->execute())
			{ 
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	//6-12-2020
	
	function get_property_name()
	{
			
			if($stmt = $this->con->prepare("SELECT  `name` FROM `rented_property_master`"))
			{	
				
				$stmt->bind_result($res_name);
				
				if($stmt->execute())
				{
						$counter	=	0;
						$details	=	array();
					while($stmt->fetch())
					{
						$details[$counter]	=	$res_name;
						$counter++;
					}
					if(!empty($details))	
					{
						return $details;
					}
					return false;
				}	
			}
		}
	function get_property_id($property_name)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `rented_property_master` WHERE `name`=?"))
		{	
			$stmt_insert->bind_param("s",$property_name);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	
	//7-12-2020
	function create_deposite_amount($property_name,$payble_deposite_amount,$payment_type,$payment_description,$added_by)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		
		if($stmt_insert = $this->con->prepare("INSERT INTO `deposite_collection`( `property_id`, `amount`, `pay_type`, `description`, `added_by`, `date`, `time`) VALUES   (?,?,?,?,?,?,?)"))
		{
		
			$stmt_insert->bind_param("sssssss",$property_name,$payble_deposite_amount,$payment_type,$payment_description,$added_by,$date,$time);
			
			if($stmt_insert->execute())
			{ 
				return true;
			}
			return false;
		} 
	}
	function get_all_deposite_collection_details($added_by)
	{
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `property_id`, `amount`, `pay_type`, `description`, `added_by`, `date`, `time` FROM `deposite_collection` WHERE `added_by`=? "))
		{	
			
			$stmt_insert->bind_param("s",$added_by);
			$stmt_insert->bind_result($id,$property_id,$amount,
			$pay_type,$description,$added_by,$date,$time);
			
			if($stmt_insert->execute())
			{
				$counter	=	0;
				$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]	=	$id;
					$details[$counter][1]	=	$property_id;
					$details[$counter][2]	=	$amount;
					$details[$counter][3]	=	$pay_type;
					$details[$counter][4]	=	$description;
					$details[$counter][5]	=	$added_by;
					$details[$counter][6]	=	$date;
					$details[$counter][7]	=	$time;
					
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	function get_property_name_from_id($property_name)
	{
		if($stmt_insert = $this->con->prepare("SELECT `name` FROM `rented_property_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("s",$property_name);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	function delete_collection_agent_property($del)
	{
		if($stmt_select = $this->con->prepare("DELETE FROM `deposite_collection` WHERE `id`=?"))
		{
			$stmt_select->bind_param("i",$del);
		
			if($stmt_select->execute())
			{					
					return true;
			}
				return false;
		}
	}
	function get_sum_of_deposite($id)
	{
		
		if($stmt_insert = $this->con->prepare("SELECT SUM(`amount`) FROM `deposite_collection` WHERE `property_id`=?"))
			{	
				
				$stmt_insert->bind_param("s",$id);
				
				$stmt_insert->bind_result($res_id);
				
				if($stmt_insert->execute())
				{
					if($stmt_insert->fetch())
					{
						
						return $res_id;
					}
					return false;
				}	
			}
	}
	function get_original_deposite($property_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `payble_deposite_amount` FROM `rented_property_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("i",$property_id);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	
	function get_income_source_name($income_source)
	{
		if($stmt_insert = $this->con->prepare("SELECT `title` FROM `category_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("s",$income_source);
			
			$stmt_insert->bind_result($res_title);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_title;
				}
				return false;
			}	
		}
	}
	function update_photo1($adhar_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `property_photo1`='' WHERE `id`=?"))
		{	
			$stmt_select->bind_param("i",$adhar_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_photo2($adhar_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `property_photo2`='' WHERE `id`=?"))
		{	
			$stmt_select->bind_param("i",$adhar_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_photo3($adhar_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `property_photo3`='' WHERE `id`=?"))
		{	
			$stmt_select->bind_param("i",$adhar_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_photo4($adhar_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `property_photo4`='' WHERE `id`=?"))
		{	
			$stmt_select->bind_param("i",$adhar_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_photo1_attach($actual_image,$id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `property_photo1`=? WHERE `id`=?"))
		{	
			$stmt_select->bind_param("si",$actual_image,$id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_photo2_attach($actual_image,$id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `property_photo2`=? WHERE `id`=?"))
		{	
			$stmt_select->bind_param("si",$actual_image,$id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_photo3_attach($actual_image,$id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `property_photo3`=? WHERE `id`=?"))
		{	
			$stmt_select->bind_param("si",$actual_image,$id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	function update_photo4_attach($actual_image,$id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `rented_property_master` SET `property_photo4`=? WHERE `id`=?"))
		{	
			$stmt_select->bind_param("si",$actual_image,$id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	//12-12-2020PenaltyFunacton
	function get_penalty_category_details($category)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `penalty_category_master` WHERE `title`=?"))
		{	
			$stmt_insert->bind_param("s",$category);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	
	function get_penalty_name($category_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `title` FROM `penalty_category_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("i",$category_id);
			
			$stmt_insert->bind_result($res_title);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_title;
				}
				return false;
			}	
		}
	}
	
	function create_penalty_category($department,$amount)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		
		if($stmt_insert = $this->con->prepare("INSERT INTO `penalty_category_master`(`title`, `amount`, `date`, `time`) VALUES (?,?,?,?)"))
		{
		
			$stmt_insert->bind_param("ssss",$department,$amount,$date,$time);
			
			if($stmt_insert->execute())
			{ 
				return true;
			}
			return false;
		} 
	}
	
	function get_all_penalty_category_details()
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `title`, `amount`, `date`, `time`,`amount` FROM `penalty_category_master`"))
		{	
			$stmt_insert->bind_result($id,$res_department,$res_description,$date,$time,$amount);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]	=	$id;
					$details[$counter][1]	=	$res_department;
					$details[$counter][2]	=	$res_description;
					$details[$counter][3]	=	$date;
					$details[$counter][4]	=	$time;
					$details[$counter][5]	=	$amount;
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	
	function delete_penalty_category($del)
	{
		if($stmt_select = $this->con->prepare("DELETE FROM `penalty_category_master` WHERE `id`=?"))
		{
			$stmt_select->bind_param("i",$del);
		
			if($stmt_select->execute())
			{					
					return true;
			}
				return false;
		}
	}
	function get_penalty_category_by_id($edit_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `title`,`amount` FROM `penalty_category_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("i",$edit_id);
			$stmt_insert->bind_result($id,$department,$description);
			
			if($stmt_insert->execute())
			{
				$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]	=	$id;
					$details[1]	=	$department;
					$details[2]	=	$description;
					
					return $details;
				}
				return false;
			}	
		}
	}
	
	
	function update_penalty_categoty($department,$description,$edit_id)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		if($stmt_select = $this->con->prepare("UPDATE `penalty_category_master` SET `title`=?,`amount`=?,`date`=? ,`time`=?  WHERE `id`=?"))
		{	
			$stmt_select->bind_param("ssssi",$department,$description,$date,$time,$edit_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		    
		}
	}
	
	function update_penalty_recipt_data($edit_id,$penalty_for,$payment_method,$amount)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		if($stmt_select = $this->con->prepare("UPDATE `penalty_table` SET `penalty_for`=?,`payment_method`=?,`penalty_amount`=?,`date`=? ,`time`=?  WHERE `id`=?"))
		{	
			$stmt_select->bind_param("sssssi",$penalty_for,$payment_method,$amount,$date,$time,$edit_id);
		
			if($stmt_select->execute())
			{
				return true;
			}
		}
	}
	
	function get_penalty_report_api($penalty_list)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `title`, `amount`  FROM `penalty_category_master` where `id` IN (".$penalty_list.")"))
		{
			$stmt_insert->bind_result($id,$title,$amount);
			
			if($stmt_insert->execute())
			{
				$counter	=	0;
				$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter]['penalty_id']	=	$id;
					$details[$counter]['title']			=	$id.") ".$title;
					$details[$counter]['amount']		=	$amount;
					
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	function add_penalty_details($user_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$payment_method,$payment_description,$note,$status,$living_address,$random_string)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		//$status="pending";
		$double_status="";
		if($stmt_insert = $this->con->prepare("INSERT INTO `penalty_table`( `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`,`date`,`time`,`living_address`,
		`random_string`,`double_status`) VALUES  (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"))
		{
			$stmt_insert->bind_param("sssssssssssssssssss",$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string,$double_status);
			
			if($stmt_insert->execute())
			{ 
				return true;
			}
			return false;
		} 
	}
	function get_all_penalty_details_report($from_data1,$to_data1,$software_users,$category,$payment_status)
	{
		$user_stmt		=	"";
		$category_stmt	=	"";
		$status_stmt	=	"";
		
		if($software_users=='all' OR $software_users=="'all'")
		{
			$software_users="";
			$user_stmt=" AND  `user_id` LIKE  '%".$software_users."%' ";
		}
		else
		{
			$user_stmt=" AND  `user_id` IN ($software_users) ";
		}
		if($category=='all' OR $category=="'all'")
		{
			$category="";
			$category_stmt=" AND `penalty_for` LIKE  '%".$category."%' ";
		}
		else
		{
			$category_stmt=" AND `penalty_for` IN ($category) ";
		}
		if($payment_status=='all')
		{
			$payment_status="";
			$status_stmt=" AND `status`  LIKE  '%".$payment_status."%' ";
		}
		else
		{
			$status_stmt=" AND `status`  LIKE  '%".$payment_status."%' ";
		}
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`,
		`living_address`,`random_string`,`double_status` FROM `penalty_table` WHERE `date` BETWEEN ? AND ? ".$user_stmt.$category_stmt.$status_stmt))
		{	
			
			$stmt_insert->bind_param("ss",$from_data1,$to_data1);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string,$double_status);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$actual_file_name1;
					$details[$counter][2]		=	$actual_file_name2;
					$details[$counter][3]		=	$actual_file_name3;
					$details[$counter][4]		=	$actual_file_name4;
					$details[$counter][5]		=	$name;
					$details[$counter][6]		=	$address;
					$details[$counter][7]		=	$mobile_no;
					$details[$counter][8]		=	$penalty_for;
					$details[$counter][9]		=	$penalty_amount;
					$details[$counter][10]		=	$status;
					$details[$counter][11]		=	$payment_method;
					$details[$counter][12]		=	$payment_description;
					$details[$counter][13]		=	$note;
					$details[$counter][14]		=	$user_id;
					$details[$counter][15]		=	$date;
					$details[$counter][16]		=	$time;
					$details[$counter][17]		=	$living_address;
					$details[$counter][18]		=	$random_string;
					$details[$counter][19]		=	$double_status;
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	function get_all_penalty_details_report_by_software_users($from_data1,$to_data1,$user_id)
	{
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`,`living_address`,`random_string` FROM `penalty_table` WHERE `date` BETWEEN ? AND ?  AND  `user_id`=? "))
		{	
			
			$stmt_insert->bind_param("sss",$from_data1,$to_data1,$user_id);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter]['res_id']			=	$res_id;
					$details[$counter]['attachment1']		=	$actual_file_name1;
					$details[$counter]['attachment2']		=	$actual_file_name2;
					$details[$counter]['attachment3']		=	$actual_file_name3;
					$details[$counter]['attachment4']		=	$actual_file_name4;
					$details[$counter]['name']				=	$name;
					$details[$counter]['address']			=	$address;
					$details[$counter]['mobile_no']			=	$mobile_no;
					$details[$counter]['penalty_for']		=	$penalty_for;
					$details[$counter]['penalty_amount']	=	$penalty_amount;
					$details[$counter]['status']			=	$status;
					$details[$counter]['payment_method']	=	$payment_method;
					$details[$counter]['payment_description']=	$payment_description;
					$details[$counter]['note']				=	$note;
					$details[$counter]['user_id']			=	$user_id;
					$details[$counter]['date']				=	$date;
					$details[$counter]['time']				=	$time;
					$details[$counter]['living_address']	=	$living_address;
					$details[$counter]['random_string']				=	$random_string;
                    $details[$counter]['receipt_details']	=	"<div style='line-height:25px !important;'>
                    <strong>Rec. No. :</strong>".$res_id.
                    "<br /> <strong>Name:</strong>".$name.
                    "<br /> <strong>Address:</strong>".$address.
                    "<br /> <strong>Mobile No:</strong>".$mobile_no.
                    "<br /> <strong>Living Address:</strong>".$living_address.
                    "</div>";
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	//14-12-2020
	function get_all_penalty_details_report_by_id($p_id)
	{
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`,`living_address`,`random_string` FROM `penalty_table` WHERE `id`=? "))
		{	
			
			$stmt_insert->bind_param("i",$p_id);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]		=	$res_id;
					$details[1]		=	$actual_file_name1;
					$details[2]		=	$actual_file_name2;
					$details[3]		=	$actual_file_name3;
					$details[4]		=	$actual_file_name4;
					$details[5]		=	$name;
					$details[6]		=	$address;
					$details[7]		=	$mobile_no;
					$details[8]		=	$penalty_for;
					$details[9]		=	$penalty_amount;
					$details[10]	=	$status;
					$details[11]	=	$payment_method;
					$details[12]	=	$payment_description;
					$details[13]	=	$note;
					$details[14]	=	$user_id;
					$details[15]	=	$date;
					$details[16]	=	$time;
					$details[17]	=	$living_address;
					$details[18]	=	$random_string;
					return $details;
				}
				
			}	
		}
	}
	
	
	//5-1-2020
	function get_all_penalty_details_report_by_random_string($p_id)
	{
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`,`living_address`,`random_string` FROM `penalty_table` WHERE `random_string`=? "))
		{	
			
			$stmt_insert->bind_param("s",$p_id);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]		=	$res_id;
					$details[1]		=	$actual_file_name1;
					$details[2]		=	$actual_file_name2;
					$details[3]		=	$actual_file_name3;
					$details[4]		=	$actual_file_name4;
					$details[5]		=	$name;
					$details[6]		=	$address;
					$details[7]		=	$mobile_no;
					$details[8]		=	$penalty_for;
					$details[9]		=	$penalty_amount;
					$details[10]	=	$status;
					$details[11]	=	$payment_method;
					$details[12]	=	$payment_description;
					$details[13]	=	$note;
					$details[14]	=	$user_id;
					$details[15]	=	$date;
					$details[16]	=	$time;
					$details[17]	=	$living_address;
					$details[18]	=	$random_string;
					return $details;
				}
				
			}	
		}
	}
	//7-1-2020
	function get_penalty_amount($category_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `amount` FROM `penalty_category_master` WHERE `id`=?"))
		{	
			$stmt_insert->bind_param("i",$category_id);
			
			$stmt_insert->bind_result($res_title);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_title;
				}
				return false;
			}	
		}
	}
	//21-1
	function delete_collection_agent($del)
	{
		if($stmt_select = $this->con->prepare("DELETE FROM `collection_agent` WHERE `id`=?"))
		{
			$stmt_select->bind_param("i",$del);
		
			if($stmt_select->execute())
			{					
					return true;
			}
				return false;
		}
	}
	//24
	function get_collection_agent_exist_id_from_user_id($user_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$user_id);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	//16-2-2021
	function get_all_penalty_details_report_for_chalan($from_data1,$to_data1,$software_users)
	{
		$user_stmt		=	"";
		$category_stmt	=	"";
		$status_stmt	=	"";
		
		if($software_users=='all' OR $software_users=="'all'")
		{
			$software_users="";
			$user_stmt=" AND  `user_id` LIKE  '%".$software_users."%' ";
		}
		else
		{
			$user_stmt=" AND  `user_id` IN ($software_users) ";
		}
		
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`,
		`living_address`,`random_string` FROM `penalty_table` WHERE `date` BETWEEN ? AND ? ".$user_stmt))
		{	
			
			$stmt_insert->bind_param("ss",$from_data1,$to_data1);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$actual_file_name1;
					$details[$counter][2]		=	$actual_file_name2;
					$details[$counter][3]		=	$actual_file_name3;
					$details[$counter][4]		=	$actual_file_name4;
					$details[$counter][5]		=	$name;
					$details[$counter][6]		=	$address;
					$details[$counter][7]		=	$mobile_no;
					$details[$counter][8]		=	$penalty_for;
					$details[$counter][9]		=	$penalty_amount;
					$details[$counter][10]		=	$status;
					$details[$counter][11]		=	$payment_method;
					$details[$counter][12]		=	$payment_description;
					$details[$counter][13]		=	$note;
					$details[$counter][14]		=	$user_id;
					$details[$counter][15]		=	$date;
					$details[$counter][16]		=	$time;
					$details[$counter][17]		=	$living_address;
					$details[$counter][18]		=	$random_string;
					
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	//17-2-2021
	function get_penalty_data_by_si_and_date($software_users,$from_date1)
	{
		$from_data = explode("-",$from_date1);
		$from_data1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`,
		`living_address`,`random_string` FROM `penalty_table` WHERE `date`=? AND `user_id`=?  AND `double_status`='' "))
		{	
			
			$stmt_insert->bind_param("ss",$from_data1,$software_users);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$actual_file_name1;
					$details[$counter][2]		=	$actual_file_name2;
					$details[$counter][3]		=	$actual_file_name3;
					$details[$counter][4]		=	$actual_file_name4;
					$details[$counter][5]		=	$name;
					$details[$counter][6]		=	$address;
					$details[$counter][7]		=	$mobile_no;
					$details[$counter][8]		=	$penalty_for;
					$details[$counter][9]		=	$penalty_amount;
					$details[$counter][10]		=	$status;
					$details[$counter][11]		=	$payment_method;
					$details[$counter][12]		=	$payment_description;
					$details[$counter][13]		=	$note;
					$details[$counter][14]		=	$user_id;
					$details[$counter][15]		=	$date;
					$details[$counter][16]		=	$time;
					$details[$counter][17]		=	$living_address;
					$details[$counter][18]		=	$random_string;
					
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	//18-2-2021
	function save_chalan($software_users,$from_date1,$total_paid_amount,$two_thousand_val,$show_two_thousand,$five_hundard_val,$show_five_hundard,$two_hundred_val,$show_two_hundred_val,$hundred_val,$show_hundred_val,$fifty_val,$show_fifty_val,$twenty_val,$show_twenty_val,$ten_val,$show_ten_val,$ten_val_rs,$show_ten_rs,$five_val_rs,$show_five_rs,$two_val_rs,$show_two_rs,$one_val_rs,$show_one_rs,$note_total,$nani_total,$ekun_bharana)
	{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		//$status="pending";
		$from_data = explode("-",$from_date1);
		$from_date1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];
	
		if($stmt_insert = $this->con->prepare("INSERT INTO `chalan`(`si`, `selected_date`, `total_paid_amount`, `two_thousand_val`, `show_two_thousand`, `five_hundard_val`, `show_five_hundard`, `two_hundred_val`, `show_two_hundred_val`, `hundred_val`, `show_hundred_val`, `fifty_val`, `show_fifty_val`, `twenty_val`, `show_twenty_val`, `ten_val`, `show_ten_val`, `ten_val_rs`, `show_ten_rs`, `five_val_rs`, `show_five_rs`, `two_val_rs`, `show_two_rs`, `one_val_rs`, `show_one_rs`, `note_total`, `nani_total`, `ekun_bharana`, `date`, `time`) VALUES  (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"))
		{
			$stmt_insert->bind_param("ssssssssssssssssssssssssssssss",$software_users,$from_date1,$total_paid_amount,$two_thousand_val,$show_two_thousand,$five_hundard_val,$show_five_hundard,$two_hundred_val,$show_two_hundred_val,$hundred_val,$show_hundred_val,$fifty_val,$show_fifty_val,$twenty_val,$show_twenty_val,$ten_val,$show_ten_val,$ten_val_rs,$show_ten_rs,$five_val_rs,$show_five_rs,$two_val_rs,$show_two_rs,$one_val_rs,$show_one_rs,$note_total,$nani_total,$ekun_bharana,$date,$time);
			
			if($stmt_insert->execute())
			{ 
				return true;
			}
			return false;
		} 
	}
	function get_chalan_exist_or_not($software_users,$from_date1)
	{
		$from_data = explode("-",$from_date1);
		$from_date1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];
		if($stmt_insert = $this->con->prepare("SELECT `id` FROM `chalan` WHERE `si`=? AND `selected_date`=?"))
		{	
			$stmt_insert->bind_param("ss",$software_users,$from_date1);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	
	function get_all_chalan_details_report($from_data1,$to_data1,$software_users)
	{
		$user_stmt		=	"";
		
		
		if($software_users=='all' OR $software_users=="'all'")
		{
			$software_users="";
			$user_stmt=" AND  `si` LIKE  '%".$software_users."%' ";
		}
		else
		{
			$user_stmt=" AND  `si` LIKE  '%".$software_users."%' ";
		}
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `si`, `ekun_bharana`,`selected_date`, `date` FROM `chalan` WHERE `date` BETWEEN ? AND ?  ".$user_stmt))
		{	
			
			$stmt_insert->bind_param("ss",$from_data1,$to_data1);
			$stmt_insert->bind_result($res_id,$si,$total_paid_amount,$selected_date,$date);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$si;
					$details[$counter][2]		=	$total_paid_amount;
					$details[$counter][3]		=	$selected_date;
					$details[$counter][4]		=	$date;
					
					
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	function delete_chalan($del)
	{
		if($stmt_select = $this->con->prepare("DELETE FROM `chalan` WHERE `id`=?"))
		{
			$stmt_select->bind_param("i",$del);
		
			if($stmt_select->execute())
			{					
					return true;
			}
				return false;
		}
	}
	function get_chalan_data($c_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `id`, `si`, `selected_date`, `total_paid_amount`, `two_thousand_val`, `show_two_thousand`, `five_hundard_val`, `show_five_hundard`, `two_hundred_val`, `show_two_hundred_val`, `hundred_val`, `show_hundred_val`, `fifty_val`, `show_fifty_val`, `twenty_val`, `show_twenty_val`, `ten_val`, `show_ten_val`, `ten_val_rs`, `show_ten_rs`, `five_val_rs`, `show_five_rs`, `two_val_rs`, `show_two_rs`, `one_val_rs`, `show_one_rs`, `note_total`, `nani_total`, `ekun_bharana`, `date`, `time` FROM `chalan` WHERE `id`=? "))
		{	
			
			$stmt_insert->bind_param("i",$c_id);
			$stmt_insert->bind_result($res_id,$software_users,$from_date1,$total_paid_amount,$two_thousand_val,$show_two_thousand,$five_hundard_val,$show_five_hundard,$two_hundred_val,$show_two_hundred_val,$hundred_val,$show_hundred_val,$fifty_val,$show_fifty_val,$twenty_val,$show_twenty_val,$ten_val,$show_ten_val,$ten_val_rs,$show_ten_rs,$five_val_rs,$show_five_rs,$two_val_rs,$show_two_rs,$one_val_rs,$show_one_rs,$note_total,$nani_total,$ekun_bharana,$date,$time);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				if($stmt_insert->fetch())
				{
					$details[0]		=	$res_id;
					$details[1]		=	$software_users;
					$details[2]		=	$from_date1;
					$details[3]		=	$total_paid_amount;
					$details[4]		=	$two_thousand_val;
					$details[5]		=	$show_two_thousand;
					$details[6]		=	$five_hundard_val;
					$details[7]		=	$show_five_hundard;
					$details[8]		=	$two_hundred_val;
					$details[9]		=	$show_two_hundred_val;
					$details[10]	=	$hundred_val;
					$details[11]	=	$show_hundred_val;
					$details[12]	=	$fifty_val;
					$details[13]	=	$show_fifty_val;
					$details[14]	=	$twenty_val;
					$details[15]	=	$show_twenty_val;
					$details[16]	=	$ten_val;
					$details[17]	=	$show_ten_val;
					$details[18]	=	$ten_val_rs;
					$details[19]	=	$show_ten_rs;
					$details[20]	=	$five_val_rs;
					$details[21]	=	$show_five_rs;
					$details[22]	=	$two_val_rs;
					$details[23]	=	$show_two_rs;
					$details[24]	=	$one_val_rs;
					$details[25]	=	$show_one_rs;
					$details[26]	=	$note_total;
					$details[27]	=	$nani_total;
					$details[28]	=	$ekun_bharana;
					$details[29]	=	$date;
					$details[30]	=	$time;
					return $details;
				}
				
			}	
		}
	}
//19-2-2021
function update_chalan($software_users,$from_date1,$total_paid_amount,$two_thousand_val,$show_two_thousand,$five_hundard_val,$show_five_hundard,$two_hundred_val,$show_two_hundred_val,$hundred_val,$show_hundred_val,$fifty_val,$show_fifty_val,$twenty_val,$show_twenty_val,$ten_val,$show_ten_val,$ten_val_rs,$show_ten_rs,$five_val_rs,$show_five_rs,$two_val_rs,$show_two_rs,$one_val_rs,$show_one_rs,$note_total,$nani_total,$ekun_bharana,$edit_id)
{
		$date = date("Y-m-d");
		$time = date("H-i-s A");
		//$status="pending";
		$from_data = explode("-",$from_date1);
		$from_date1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];
		if($stmt=$this->con->prepare("UPDATE `chalan` SET `si`=?,`selected_date`=?,`total_paid_amount`=?,`two_thousand_val`=?,`show_two_thousand`=?,`five_hundard_val`=?,`show_five_hundard`=?,`two_hundred_val`=?,
		`show_two_hundred_val`=?,`hundred_val`=?,`show_hundred_val`=?,`fifty_val`=?,`show_fifty_val`=?,`twenty_val`=?,`show_twenty_val`=?,`ten_val`=?,`show_ten_val`=?,`ten_val_rs`=?,`show_ten_rs`=?,`five_val_rs`=?,`show_five_rs`=?,`two_val_rs`=?,`show_two_rs`=?,`one_val_rs`=?,`show_one_rs`=?,`note_total`=?,`nani_total`=?,`ekun_bharana`=?,`date`=?,`time`=? WHERE `id`=?"))
		{
			$stmt->bind_param("ssssssssssssssssssssssssssssssi",$software_users,$from_date1,$total_paid_amount,$two_thousand_val,$show_two_thousand,$five_hundard_val,$show_five_hundard,$two_hundred_val,$show_two_hundred_val,$hundred_val,$show_hundred_val,$fifty_val,$show_fifty_val,$twenty_val,$show_twenty_val,$ten_val,$show_ten_val,$ten_val_rs,$show_ten_rs,$five_val_rs,$show_five_rs,$two_val_rs,$show_two_rs,$one_val_rs,$show_one_rs,$note_total,$nani_total,$ekun_bharana,$date,$time,$edit_id);
			
			
			if($stmt->execute())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
}
//27-2-2021
function get_sum_of_amount_chalan($user_id,$from_date1)
{
	$from_data = explode("-",$from_date1);
	$from_date1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];
	if($stmt_insert = $this->con->prepare("SELECT SUM(`ekun_bharana`) FROM `chalan` WHERE `si`=? AND `selected_date`=?"))
		{	
			
			$stmt_insert->bind_param("ss",$user_id,$from_date1);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					
					return $res_id;
				}
				return false;
			}	
		}
}
//28-2-2021
	function update_user_as_active($active)
	{
		$user_status=	"Active";
		
		if($stmt_select = $this->con->prepare("UPDATE `collection_agent` SET `user_status`=? WHERE `id`=?"))
		{
			$stmt_select->bind_param("si",$user_status,$active);				
		
			if($stmt_select->execute())
			{					
				return true;
			}
				return false;
		}
	}
	
	function update_penalty_ids_to_agent($penalty_id,$agent_id)
	{
		if($stmt_select = $this->con->prepare("UPDATE `collection_agent` SET `fine_entries`=? WHERE `user_id`=?"))
		{
			$stmt_select->bind_param("ss",$penalty_id,$agent_id);
		
			if($stmt_select->execute())
			{					
				return true;
			}
				return false;
		}
	}
	
	function update_user_as_block($block)
	{
		$user_status	=	"Block";
		
		if($stmt_select = $this->con->prepare("UPDATE `collection_agent` SET `user_status`=? WHERE `id`=?"))
		{
			$stmt_select->bind_param("si",$user_status,$block);				
		
			if($stmt_select->execute())
			{					
				return true;
			}
				return false;
		}
	}
	function get_user_login_status($user_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `user_status` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$user_id);
			
			$stmt_insert->bind_result($res_id);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_id;
				}
				return false;
			}	
		}
	}
	function get_agentpenalty_list($agent_id)
	{
		if($stmt_insert = $this->con->prepare("SELECT `fine_entries` FROM `collection_agent` WHERE `user_id`=?"))
		{	
			$stmt_insert->bind_param("s",$agent_id);
			
			$stmt_insert->bind_result($res_fine_entries);
			
			if($stmt_insert->execute())
			{
				if($stmt_insert->fetch())
				{
					return $res_fine_entries;
				}
				return false;
			}	
		}
	}
	function get_all_chalan_report($from_date1)
	{
		$from_data = explode("-",$from_date1);
		$from_date1 = $from_data[2]."-".$from_data[1]."-".$from_data[0];
		if($stmt_insert = $this->con->prepare("SELECT `id`, `si`, `ekun_bharana`FROM `chalan` WHERE `selected_date` =?"))
		{	
			
			$stmt_insert->bind_param("s",$from_date1);
			$stmt_insert->bind_result($res_id,$si,$ekun_bharana);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$si;
					$details[$counter][2]		=	$ekun_bharana;
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	function update_penalty_status_as_double($double)
	{
		$user_status=	"Double";
		
		if($stmt_select = $this->con->prepare("UPDATE `penalty_table` SET `double_status`=? WHERE `id`=?"))
		{
			$stmt_select->bind_param("si",$user_status,$double);				
		
			if($stmt_select->execute())
			{					
				return true;
			}
				return false;
		}
	}
	
	function update_penalty_status_as_not_double($not_double)
	{
		$user_status	=	"";
		
		if($stmt_select = $this->con->prepare("UPDATE `penalty_table` SET `double_status`=? WHERE `id`=?"))
		{
			$stmt_select->bind_param("si",$user_status,$not_double);				
		
			if($stmt_select->execute())
			{					
				return true;
			}
				return false;
		}
	}
		
	function get_penalty_details_online_payment($date1)
	{
		
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`, `living_address`,`random_string` FROM `penalty_table` WHERE `date`=?  AND `payment_method`!='CASH' "))
		{	
			
			$stmt_insert->bind_param("s",$date1);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$actual_file_name1;
					$details[$counter][2]		=	$actual_file_name2;
					$details[$counter][3]		=	$actual_file_name3;
					$details[$counter][4]		=	$actual_file_name4;
					$details[$counter][5]		=	$name;
					$details[$counter][6]		=	$address;
					$details[$counter][7]		=	$mobile_no;
					$details[$counter][8]		=	$penalty_for;
					$details[$counter][9]		=	$penalty_amount;
					$details[$counter][10]		=	$status;
					$details[$counter][11]		=	$payment_method;
					$details[$counter][12]		=	$payment_description;
					$details[$counter][13]		=	$note;
					$details[$counter][14]		=	$user_id;
					$details[$counter][15]		=	$date;
					$details[$counter][16]		=	$time;
					$details[$counter][17]		=	$living_address;
					$details[$counter][18]		=	$random_string;
					
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	
	
	function get_penalty_details_online_payment_from_date_userid($date1,$user_id)
	{
	    //$user_id    =   trim($user_id);
	    //$user_id    =   strtolower($user_id);
	    
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`, `living_address`,`random_string` FROM `penalty_table` WHERE `date`='.$date1.' AND `user_id`='.$user_id.' AND `payment_method`!='CASH'"))
		{	
		    
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$res_user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
				$counter	=	0;
				$details	=	array();

				while($stmt_insert->fetch())
				{
				    
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$actual_file_name1;
					$details[$counter][2]		=	$actual_file_name2;
					$details[$counter][3]		=	$actual_file_name3;
					$details[$counter][4]		=	$actual_file_name4;
					$details[$counter][5]		=	$name;
					$details[$counter][6]		=	$address;
					$details[$counter][7]		=	$mobile_no;
					$details[$counter][8]		=	$penalty_for;
					$details[$counter][9]		=	$penalty_amount;
					$details[$counter][10]		=	$status;
					$details[$counter][11]		=	$payment_method;
					$details[$counter][12]		=	$payment_description;
					$details[$counter][13]		=	$note;
					$details[$counter][14]		=	$res_user_id;
					$details[$counter][15]		=	$date;
					$details[$counter][16]		=	$time;
					$details[$counter][17]		=	$living_address;
					$details[$counter][18]		=	$random_string;
					
					
				
					$counter++;
				}

				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}
			else
				{
				    $stmt_insert->error;
				}
		}
	}
	
	//4-3-2021
	function update_penalty_status_as_paid($paid)
	{
		$user_status=	"Paid";
		
		if($stmt_select = $this->con->prepare("UPDATE `penalty_table` SET `status`=? WHERE `id`=?"))
		{
			$stmt_select->bind_param("si",$user_status,$paid);				
		
			if($stmt_select->execute())
			{					
				return true;
			}
				return false;
		}
	}
	
	function update_penalty_status_as_not_unpaid($unpaid)
	{
		$user_status	=	"Unpaid";
		
		if($stmt_select = $this->con->prepare("UPDATE `penalty_table` SET `status`=? WHERE `id`=?"))
		{
			$stmt_select->bind_param("si",$user_status,$unpaid);				
		
			if($stmt_select->execute())
			{					
				return true;
			}
				return false;
		}
	}
		//5-3-2021
	function get_all_penalty_details_report_for_api($from_data1,$to_data1,$software_users)
	{
		$user_stmt		=	"";
		$category_stmt	=	"";
		$status_stmt	=	"";
		
		if($software_users=='all' OR $software_users=="'all'")
		{
			$software_users="";
			$user_stmt=" AND  `user_id` LIKE  '%".$software_users."%' ";
		}
		else
		{
			$user_stmt=" AND  `user_id` ='".$software_users."' ";
		}
		
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`,
		`living_address`,`random_string` FROM `penalty_table` WHERE `date` BETWEEN ? AND ? ".$user_stmt))
		{	
			
			$stmt_insert->bind_param("ss",$from_data1,$to_data1);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$actual_file_name1;
					$details[$counter][2]		=	$actual_file_name2;
					$details[$counter][3]		=	$actual_file_name3;
					$details[$counter][4]		=	$actual_file_name4;
					$details[$counter][5]		=	$name;
					$details[$counter][6]		=	$address;
					$details[$counter][7]		=	$mobile_no;
					$details[$counter][8]		=	$penalty_for;
					$details[$counter][9]		=	$penalty_amount;
					$details[$counter][10]		=	$status;
					$details[$counter][11]		=	$payment_method;
					$details[$counter][12]		=	$payment_description;
					$details[$counter][13]		=	$note;
					$details[$counter][14]		=	$user_id;
					$details[$counter][15]		=	$date;
					$details[$counter][16]		=	$time;
					$details[$counter][17]		=	$living_address;
					$details[$counter][18]		=	$random_string;
					
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
		function get_all_bharana_details_report($from_data1,$to_data1,$software_users)
	    {
		$user_stmt		=	"";
		
		
	
			$user_stmt=" AND  `si` =  '".$software_users."' ";
		
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `si`, `ekun_bharana`,`selected_date`, `date` FROM `chalan` WHERE `date` BETWEEN ? AND ?  ".$user_stmt))
		{	
			
			$stmt_insert->bind_param("ss",$from_data1,$to_data1);
			$stmt_insert->bind_result($res_id,$si,$total_paid_amount,$selected_date,$date);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$si;
					$details[$counter][2]		=	$total_paid_amount;
					$details[$counter][3]		=	$selected_date;
					$details[$counter][4]		=	$date;
					
					
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
	//16
	function get_penalty_details_online_payment_new($date1,$user_id)
	{
		
		
		if($stmt_insert = $this->con->prepare("SELECT `id`, `attachment1`, `attachment2`, `attachment3`, `attachment4`, `name`, `address`, `mobile_no`, `penalty_for`, `penalty_amount`, `status`, `payment_method`, `payment_description`, `note`, `user_id`, `date`, `time`, `living_address`,`random_string` FROM `penalty_table` WHERE `date`=?  AND `payment_method`!='CASH' AND `user_id`=? "))
		{	
			
			$stmt_insert->bind_param("ss",$date1,$user_id);
			$stmt_insert->bind_result($res_id,$actual_file_name1,$actual_file_name2,$actual_file_name3,$actual_file_name4,$name,$address,$mobile_no,$penalty_for,$penalty_amount,$status,$payment_method,$payment_description,$note,$user_id,$date,$time,$living_address,$random_string);
			
			if($stmt_insert->execute())
			{
					$counter	=	0;
					$details	=	array();
				while($stmt_insert->fetch())
				{
					$details[$counter][0]		=	$res_id;
					$details[$counter][1]		=	$actual_file_name1;
					$details[$counter][2]		=	$actual_file_name2;
					$details[$counter][3]		=	$actual_file_name3;
					$details[$counter][4]		=	$actual_file_name4;
					$details[$counter][5]		=	$name;
					$details[$counter][6]		=	$address;
					$details[$counter][7]		=	$mobile_no;
					$details[$counter][8]		=	$penalty_for;
					$details[$counter][9]		=	$penalty_amount;
					$details[$counter][10]		=	$status;
					$details[$counter][11]		=	$payment_method;
					$details[$counter][12]		=	$payment_description;
					$details[$counter][13]		=	$note;
					$details[$counter][14]		=	$user_id;
					$details[$counter][15]		=	$date;
					$details[$counter][16]		=	$time;
					$details[$counter][17]		=	$living_address;
					$details[$counter][18]		=	$random_string;
					
					
				
					$counter++;
				}
				if(!empty($details))	
				{
					return $details;
				}
				return false;
			}	
		}
	}
}//END


?>