<?php 
require_once('lib/functions.php');
$db		=	new login_function();
if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
	
	$flag					=	0;
	$customer_name			=	"";
	$invoice_date			=	"";
	$product_name			=	"";
	$less_stock_item_count	=	0;
	$invoice_count			=	"";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $project_title; ?></title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	<link href="datatable/datatables.min.css" rel="stylesheet" />

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	
</head>
<body class="fixed-navbar">
  
<div class="page-wrapper" style="min-height:500px;">
<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>
<style>
	.mb-4 {
    /* margin-bottom: 1.5rem!important; */
}

	</style>
	
<div class="content-wrapper">
<div class="alert alert-primary" role="alert" style="background-color:#EFEFEF; border:1px solid #EFEFEF; padding:2px; text-align:right;">
</div>
<div class="row" style="padding:0px; margin:0px; margin-top:15px; border-radius:15px; width:100%;">


</div>

</div>

<?php include('footer.php'); ?>
</div>
    </div>
    <?php include('search.php'); ?>
   
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    
	<link rel="stylesheet" href="css/jquery-ui.css">
	 <script src="js/jquery.min.js"></script>
	<script src="js/jquery-ui.js"></script>
	<style>
	.ui-widget-content {
		border: 1px solid #DE1559;
		font-size:16px;
		background: #DE1559;
		color:#FFF;
		font-weight:bold;
		
	}
	.ui-menu .ui-menu-item {
		margin: 0;
		padding:6px;
		border:1px solid #FFF;
		border-bottom:0px solid #E82A2A;
		cursor: pointer;
		width:100%;
	}
	</style>

  
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
	
</body>
</html>