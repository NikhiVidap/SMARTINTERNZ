<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
$success			=0;
if(isset($_GET['del']))
{
	$del	=	$_GET['del'];
	
	if($db->delete_collection_agent_property($del))
	{
	?>
		<script>
		alert("Record Deleted Successfully...!!!");
		</script>
	<?php
	}
	
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $project_title; ?></title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th
{
	text-align:center;
	text-transform:uppercase;
}
table,td
{
	text-align:left;
	text-transform:uppercase;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 350px;
overflow: auto;
}
.table-wrapper-scroll-x
{
position: relative;
width: 100%;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
.txt
{
	text-align:left;
	color:#232B99;
	font-size:12px;
	margin-right:10px;
	font-weight:bold;
	height:40px;
}	

	
</style>

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	</head>
	<body class="fixed-navbar">

	<div class="page-wrapper" style="height:800px;">

	<?php include('header.php'); ?>
	<?php include('side-bar.php'); ?>

	<div class="content-wrapper">


	<div class="page-content fade-in-up">
	<div class="ibox" style="border-radius:5px; padding:7px;">

	<div class="ibox-body" style="padding:7px; padding-top:0px;">
		<div class="ibox-head">
			<div class="ibox-title">Due Report</div>
			<a href="excel-pdf-property-due-report.php?option=2" class="btn btn-danger btn-air"  ><i class="fas fa-download">&nbsp;&nbsp;</i>PRINT</a>
			</div>	
	</div>
	<div class="flexbox mb-4" style="margin-left:20px;margin-right:20px;">
	<div class="input-group-icon input-group-icon-left mr-3">
	<span class="input-icon input-icon-right font-16"><i class="fas fa-search"></i></span>
	<input class="form-control form-control-rounded form-control-solid" id="key-search" type="text" placeholder="Search ...">
	</div>

	</div>

	<div class="table-wrapper-scroll-y table-wrapper-scroll-x my-custom-scrollbar">

	<div class="table-responsive" id="table_response" style="height:100%; width:100%; overflow:auto;">
	<table class="table table-bordered table-hover" id="example" >
	<thead class="thead-default thead-lg">
	<tr>
	<th>Sr No</th>
	<th>Property Name</th> 
	<th>Deposite Amount</th> 
	<th>Paid Amount</th> 
	<th>Remaining Amount</th> 
	<th>Action</th>

	</tr>
	</thead>
	<tbody>
	<?php
	$data	=	array();
	$data	=	$db->get_all_rented_property_details();
	$total_deposite_amount	=	0;
	$total_sum_of_deposite	=	0;
	$total_remaining_amount	=	0;
	if(!empty($data))
	{
		$counter 	=0;
		$sr_counter	=0;
		foreach($data as $record)
		{
			$id						=	$record[0];
			$res_name				=	$record[1];
			$res_mobile_no			=	$record[2];
			$res_address			=	$record[3];
			$other_mobile_no		=	$record[4];
			$res_aadhar_no			=	$record[5];
			$res_image				=	$record[6];
			$res_pan_attach			=	$record[7];
			$res_adhar_attach		=	$record[8];
			$user_id				=	$record[9];
			$password				=	$record[10];
			$frequency_days			=	$record[11];
			$property_issue_date	=	$record[12];
			$desposite_amount		=	$record[13];
			$sum_of_deposite=0;
			$sum_of_deposite=$db->get_sum_of_deposite($id);
			if($sum_of_deposite=='')
			{
				$sum_of_deposite=0;
			}
			$remaining_amount=0;
			$remaining_amount=$desposite_amount-$sum_of_deposite;
			
			$total_deposite_amount	=	$total_deposite_amount+$desposite_amount;
			$total_sum_of_deposite	=	$total_sum_of_deposite+$sum_of_deposite;
			$total_remaining_amount	=	$total_remaining_amount+$remaining_amount;
			
			if($desposite_amount!=$sum_of_deposite)
			{
			?>
		<tr> 
			<td style="text-align:left;"><span class="txt"><?php echo $sr_counter+1; ?></td>
			<td><?php echo $res_name; ?></td>
			<td style="text-align:center;"><?php echo $desposite_amount; ?></td>
			<td style="text-align:center;"><?php echo $sum_of_deposite; ?></td>
			<td style="text-align:center;"><?php echo $remaining_amount; ?></td>
			
			<td><center><a href="deposite-collection.php?propert_id=<?php echo $id; ?>"  style="color:green; font-weight:bold;">PAY</a></center> </td>
			
	<?php
	$sr_counter++;
	}
	?>
	<tr style="text-align:center !important; font-weight:bold;">
	<td colspan="2" style="text-align:center !important; font-weight:bold;">Total:</td>
	<td style="text-align:center !important; font-weight:bold;"> &#8377 <?php echo $total_deposite_amount; ?></td>
	<td style="text-align:center !important; font-weight:bold;"> &#8377 <?php echo $total_sum_of_deposite; ?></td>
	<td style="text-align:center !important; font-weight:bold;"> &#8377 <?php echo $total_remaining_amount; ?></td>
	</tr>
	<?php
	$counter++;
	}
	
}

else
{
?>
<td colspan="19">No Data Found...</td>
<?php
}
?>
</tr> 
</tbody> 
</table> 
</div>
</div>
</div>
</div>
</div>
	</div>
</div>

		<?php include('footer.php'); ?>
	
<?php //include('search.php'); ?>
<!-- END SEARCH PANEL-->
<!-- BEGIN THEME CONFIG PANEL-->

<!-- END THEME CONFIG PANEL-->
<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
<div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- New question dialog-->

<!-- End New question dialog-->
<!-- QUICK SIDEBAR-->
<?php //include('right-side-bar.php'); ?>
<script src="js/jquery.min.js"></script>


<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->

<!-- CORE SCRIPTS-->
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
<script>
$(function() {
	$('#example').DataTable({
		pageLength: 10,
		fixedHeader: true,
		responsive: true,
		"sDom": 'rtip',
		columnDefs: [{
			targets: 'no-sort',
			orderable: false
		}]
	});

	var table = $('#example').DataTable();
	$('#key-search').on('keyup', function() {
		table.search(this.value).draw();
	});
  
});
</script>
</body>

</html>
