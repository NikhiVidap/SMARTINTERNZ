<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}

		
$success			=0;

if(isset($_GET['del']))
{
	$del	=	$_GET['del'];
	
	if($db->delete_collection_agent_property($del))
	{
		$success	=	3;
	}
	
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Rented Property Master List</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th
{
	text-align:center;
	text-transform:uppercase;
}
table,td
{
	text-align:left;
	text-transform:uppercase;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 350px;
overflow: auto;
}
.table-wrapper-scroll-x
{
position: relative;
width: 100%;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
.txt
{
	text-align:left;
	color:#232B99;
	font-size:12px;
	margin-right:10px;
	font-weight:bold;
	height:40px;
}	

	
</style>

	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
	<script src="js/wow.min.js"></script>
	</head>
	<body class="fixed-navbar">

	<div class="page-wrapper" style="height:800px;">

	<?php include('header.php'); ?>
	<?php include('side-bar.php'); ?>

	<div class="content-wrapper">


	<div class="page-content fade-in-up">
	<div class="ibox" style="border-radius:5px; padding:7px;">

	<div class="ibox-body" style="padding:7px; padding-top:0px;">
		<div class="ibox-head">
			<div class="ibox-title">Rented Property Master List</div>
			<a href="add-rented-property.php" class="btn btn-primary btn-air" style=""><i class="fas fa-plus">&nbsp;&nbsp;</i>Add Details</a>
			<a href="excel-pdf-rented-property.php?option=1" class="btn btn-warning btn-air"><i class="fas fa-file-excel-o">&nbsp;&nbsp;</i>EXCEL</a>
			<a href="excel-pdf-rented-property.php?option=2" class="btn btn-danger btn-air"  ><i class="fas fa-download">&nbsp;&nbsp;</i>PDF</a>
			</div>	
	</div>

	<?php
		
		if($success=='3')
		{
		?>
		<script>
			alert("Rented Property Details Deleted Successfully...!!!");
		</script>
		
		<?php
		}
		?>
		
		<br />
		
	<div class="flexbox mb-4" style="margin-left:20px;margin-right:20px;">
	<div class="input-group-icon input-group-icon-left mr-3">
	<span class="input-icon input-icon-right font-16"><i class="fas fa-search"></i></span>
	<input class="form-control form-control-rounded form-control-solid" id="key-search" type="text" placeholder="Search ...">
	</div>

	</div>

	<div class="table-wrapper-scroll-y table-wrapper-scroll-x my-custom-scrollbar">

	<div class="table-responsive" id="table_response" style="height:100%; width:100%; overflow:auto;">
	<table class="table table-bordered table-hover" id="example" >
	<thead class="thead-default thead-lg">
	<tr>
	<th>Details</th>
	<th>Image Attachment</th> 
	<th>PanCard Attachment</th> 
	<th>Aadhar Card Attachment</th> 
	<th>Property Photo 1</th> 
	<th>Property Photo 2</th> 
	<th>Property Photo 3</th> 
	<th>Property Photo 4</th> 
	<th>Action</th>
	<th>Action</th>

	</tr>
	</thead>
	<tbody>
	<?php
	$data	=	array();
	$data	=	$db->get_all_rented_property_details();

	if(!empty($data))
	{
		$counter =0;
		foreach($data as $record)
		{
			$id						=	$record[0];
			$res_name				=	$record[1];
			$res_mobile_no			=	$record[2];
			$res_address			=	$record[3];
			$other_mobile_no		=	$record[4];
			$res_aadhar_no			=	$record[5];
			$res_image				=	$record[6];
			$res_pan_attach			=	$record[7];
			$res_adhar_attach		=	$record[8];
			$user_id				=	$record[9];
			$password				=	$record[10];
			$frequency_days			=	$record[11];
			$property_issue_date	=	$record[12];
			$desposite_amount		=	$record[13];
			$property_type			=	$record[14];
			$income_source			=	$record[15];
			$property_photo1		=	$record[16];
			$property_photo2		=	$record[17];
			$property_photo3		=	$record[18];
			$property_photo4		=	$record[19];
			$income_source_name		= $db->get_income_source_name($income_source);
			?>
		<tr> 
			<td style="text-align:left;"><span class="txt">Sr No:</span><?php echo $counter+1; ?></br>
			<span class="txt">Name:</span><?php echo $res_name; ?></br>
			<span class="txt">Mobile Number:</span><?php echo $res_mobile_no; ?></br>
			<span class="txt">Frequency Days:</span><?php echo $frequency_days; ?></br>
			<span class="txt">Property Issue Date:</span><?php echo $property_issue_date; ?></br>
			<span class="txt">Property Type:</span><?php echo $property_type; ?></br>
			<span class="txt">Income Source:</span><?php echo $income_source_name; ?></br>
			<span class="txt">Deposite Amount:</span><?php echo $desposite_amount; ?></br>
			<span class="txt">Other Mobile No:</span><?php echo $other_mobile_no; ?></br>
			<span class="txt">Address:</span><?php echo $res_address; ?></br>
			<span class="txt">Aadhar No:</span><?php echo $res_aadhar_no; ?> <br />
			<span class="txt">User Id:</span><?php echo $user_id; ?></br>
			<span class="txt">Password:</span><?php echo $password; ?></br>
			
			</td>
			<?php
				if($res_image!="")
				{
				?>
				<td>
					<a href="id_image/<?php echo $res_image; ?>" target="_blank"><img src="id_image/<?php echo $res_image; ?>" height="50px" width="50px"></a>
				</td>
				<?php
				}
				else
				{
				?>
				<td>
					<a href="icon/no-image.png" target="_blank"><img src="icon/no-image.png" height="50px" width="100px"></a>
				</td>
				<?php
				}
				
				if($res_pan_attach!="")
				{
				?>
				<td>
					<a href="pancard_attachments/<?php echo $res_pan_attach; ?>" target="_blank"><img src="pancard_attachments/<?php echo $res_pan_attach; ?>" height="50px" width="50px"></a>
				</td>
				<?php
				}
				else
				{
				?>
				<td><a href="icon/no-image.png" target="_blank"><img src="icon/no-image.png" height="50px" width="100px"></a></td>
				
				<?php
					
				}
				?>
				
				<?php
				if($res_adhar_attach!="")
				{
				?>
				<td>
					<a href="adhar_attachments/<?php echo $res_adhar_attach; ?>" target="_blank"><img src="adhar_attachments/<?php echo $res_adhar_attach; ?>" height="50px" width="50px"></a>
				</td>
				<?php
				}
				else
				{
				?>
				<td><a href="icon/no-image.png" target="_blank"><img src="icon/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				?>
				<?php
				if($property_photo1!="")
				{
				?>
				<td>
					<a href="property_photo/<?php echo $property_photo1; ?>" target="_blank"><img src="property_photo/<?php echo $property_photo1; ?>" height="50px" width="50px"></a>
				</td>
				<?php
				}
				else
				{
				?>
				<td><a href="icon/no-image.png" target="_blank"><img src="icon/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				?>
				<?php
				if($property_photo2!="")
				{
				?>
				<td>
					<a href="property_photo/<?php echo $property_photo2; ?>" target="_blank"><img src="property_photo/<?php echo $property_photo2; ?>" height="50px" width="50px"></a>
				</td>
				<?php
				}
				else
				{
				?>
				<td><a href="icon/no-image.png" target="_blank"><img src="icon/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				?>
				<?php
				if($property_photo3!="")
				{
				?>
				<td>
					<a href="property_photo/<?php echo $property_photo3; ?>" target="_blank"><img src="property_photo/<?php echo $property_photo3; ?>" height="50px" width="50px"></a>
				</td>
				<?php
				}
				else
				{
				?>
				<td><a href="icon/no-image.png" target="_blank"><img src="icon/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				?>
				<?php
				if($property_photo4!="")
				{
				?>
				<td>
					<a href="property_photo/<?php echo $property_photo4; ?>" target="_blank"><img src="property_photo/<?php echo $property_photo4; ?>" height="50px" width="50px"></a>
				</td>
				<?php
				}
				else
				{
				?>
				<td><a href="icon/no-image.png" target="_blank"><img src="icon/no-image.png" height="50px" width="100px"></a></td>
				<?php
					
				}
				?>
			<td><center><a href="update-rented-property.php?edit_id=<?php echo $id; ?>"><i class="fas fa-edit"style="color:blue;margin-left:20px;"></i></a></center> </td>
			<td><center><a href="rented-property-master.php?del=<?php echo $id;?>" onclick="return confirm('Are You Sure to Delete this Record ?');"><i class="fas fa-trash"style="color:red;margin-left:20px;"></i></a></center> </td>
			
	<?php
	$counter++;
	}
	
}

else
{
?>
<td colspan="19">No Data Found...</td>
<?php
}
?>
</tr> 
</tbody> 
</table> 
</div>
</div>
</div>
</div>
</div>
	</div>
</div>

		<?php include('footer.php'); ?>
	
<?php //include('search.php'); ?>
<!-- END SEARCH PANEL-->
<!-- BEGIN THEME CONFIG PANEL-->

<!-- END THEME CONFIG PANEL-->
<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
<div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- New question dialog-->

<!-- End New question dialog-->
<!-- QUICK SIDEBAR-->
<?php //include('right-side-bar.php'); ?>
<script src="js/jquery.min.js"></script>

<script type="text/javascript">
function submitData()
{	
	if($('#name').val()=="")
	{
	alert("Please Enter Name");
	}
	else if($('#birth_date').val()=="")
	{
	alert("Please Enter Birth Date");
	}
	else if($('#gender').val()=="")
	{
	alert("Please Choose Gender");
	}
	else if($('#blood_grp').val()=="")
	{
	alert("Please Enter Blood Group");
	}
	else if($('#martial_status').val()=="")
	{
	alert("Please Enter Martial Status");
	}
	else if($('#mobile_no').val()=="")
	{
	alert("Please Enter Mobile Number");
	}
	else if($('#address').val()=="")
	{
	alert("Please Enter Address");
	}
	else if($('#department').val()=="Select Department")
	{
	alert("Please Select Designation");
	}
	else if($('#join_date').val()=="")
	{
	alert("Please Enter Joining Date");
	}
	else if($('#adhar_no').val()=="")
	{
	alert("Please Enter Aadhar Card Number");
	}
	else if($('#img').val()=="")
	{
	alert("Please Upload ID Size Photo");
	}
	else if($('#pan_attach').val()=="")
	{
	alert("Please Upload Pan Card");
	}
	else if($('#adhar_attach').val()=="")
	{
	alert("Please Upload Aadhar Card");
	}
	
	else
	{
	//alert('hii');
	var fname = $("#fname").val();
	var birth_date = $("#birth_date").val();
	var gender= $("#gender").val();
	var blood_grp = $("#blood_grp").val();
	var mar_st = $("#martial_status").val();
	var mobile = $("#mobile_no").val();
	var address = $("#address").val();
	var dep= $("#department").val();
	var join_dt= $("#join_date").val();
	var adhar= $("#aadhar_no").val();
	var img= $("#image").val();
	var pan_attach=$("#pancard_file").val();
	var adhar_attach=$("#aadhar_file").val();
	
	 $.ajax({
            type:'POST',
            url:'insert_expenses.php',
             data:'submitData=1&fname='+fname+'&birth_date='+birth_date+'&gender='+gender+'&blood_grp='+blood_grp+'&mar_st='+mar_st+'&mobile='+mobile+'&address='+address+'&dep='+dep+'&join_dt='+join_dt+'&adhar='+adhar+'&img='+img+'&pan_attach='+pan_attach+'&adhar_attach='+adhar_attach,
			
			success:function(msg)
                {
                  
                   if(msg == '1')
                    {	
						$('#modalPush').modal('hide');
						alert("Expenses Added Successfully...!!!");
						location.reload(true);
                                               
                    }
                    else
                    {
                       alert("Expenses Already Exists...!!!");
                    }
                }
            });
			}
				
}

	</script>
<script type="text/javascript">
$(document).ready(function(){
$( function() {
    $( "#date" ).datepicker();
  } );
  
  
});
</script>

<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->

<!-- CORE SCRIPTS-->
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
<script>
$(function() {
	$('#example').DataTable({
		pageLength: 10,
		fixedHeader: true,
		responsive: true,
		"sDom": 'rtip',
		columnDefs: [{
			targets: 'no-sort',
			orderable: false
		}]
	});

	var table = $('#example').DataTable();
	$('#key-search').on('keyup', function() {
		table.search(this.value).draw();
	});
  
});
</script>
</body>

</html>
