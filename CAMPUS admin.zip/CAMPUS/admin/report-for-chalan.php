<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}

$success			=0;


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $project_title; ?></title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th
{
	text-align:center;
	text-transform:uppercase;
}
table,td
{
	text-align:left;
	text-transform:uppercase;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 700px;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
</style>
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
</head>
<body class="fixed-navbar">

<div class="page-wrapper" style="height:1000px;">

<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>

<div class="content-wrapper">
<div class="page-content fade-in-up">
<div class="ibox" style="border-radius:5px; padding:7px;">
<?php
$from_date1	=	date("d-m-Y");
$to_date1	=	date("d-m-Y");
$software_users	=	"";
$category		=	"";
$status			=	"";
$category_data	=	"";
$software_data	=	"";
$software_data_new="";
$category_data_new="";
$flag			=	0;
if(isset($_POST['search']))
{
	$from_date1				= $_POST['from_date1'];
	//$to_date1       		= $_POST['to_date1'];
	$software_users      	= $_POST['software_users'];
	//$_SESSION['to_date1']		=	$to_date1;
	$_SESSION['from_date1']		=	$from_date1;
	$_SESSION['software_users']	=	$software_users;
	if($software_users=='Select SI')
	{
	?>
	<script>
	alert("Please Select SI");
	</script>
	<?php
	$flag=1;
	}
	if($flag==0)
	{
	?>
	<script>
	window.location="create-chalan.php";
	</script>
	<?php
	}
}
if(isset($_SESSION['from_date1']) AND isset($_SESSION['software_users']))
{
	$from_date1		= $_SESSION['from_date1'];
	$software_users	= $_SESSION['software_users'];
}

?>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" autocomplete="off">
	<div class="col-lg-12" style="font-size:16px;padding:10px;">
		
		<div class="col-lg-4"  style="display:inline-table; ">
		<label class="form-group mb-4 set-row"><b>Software User</b></label>
		<div class="input-group-icon input-group-icon-left  set-row">
		<select class="form-control" name="software_users" >
		<option value="Select SI" <?php if($software_users=="all") { ?> Selected <?php }  ?>>Select SI</option>	

		<?php

		$data	=	array();
		$data	=	$db->get_all_collection_agent_details();

		if(!empty($data))
		{
			$counter =0;
			foreach($data as $record)
			{
				$id				=	$record[0];
				$employee_code	=	$record[1];
				$res_name		=	$record[2];
				$user_id		=	$record[5];

		?>
		<option value="<?php echo $user_id; ?>" <?php if($software_users==$user_id) { ?> Selected <?php }  ?>><?php echo $res_name; ?></option>	
		<?php
			}
		}
		?>
		</select>
		</div>
		</div>
		
		<div class="col-lg-3" style="display:inline-table;">
			Select date:
			<input placeholder="Select From date" type="text" name="from_date1" id="from_date" value=<?php echo $from_date1; ?> class="form-control">
		</div>
		
		
		<div class="col-lg-1" style="display:inline-table;width:100%;margin:auto;">
		<label></label>
		<br />
		<input class="btn btn-pink btn-air"  type="submit" name="search"  value="Create"  />
		</div>
		 
	</div><!-- end of colg-2.6-->
</form>
</div>
</div>
	

</div>
	</div>
<?php include('footer.php'); ?>
	
<?php //include('search.php'); ?>
<!-- END SEARCH PANEL-->
<!-- BEGIN THEME CONFIG PANEL-->

<!-- END THEME CONFIG PANEL-->
<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
<div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- New question dialog-->

<!-- End New question dialog-->
<!-- QUICK SIDEBAR-->
<?php //include('right-side-bar.php'); ?>
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		
<script>

$( function()  {
		$( "#from_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		$( "#to_date" ) .datepicker({ dateFormat: 'dd-mm-yy'   }) ;
		
}  ) ;
		


</script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->

<!-- CORE SCRIPTS-->
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
<script>
$(function() {
	$('#example').DataTable({
		pageLength: 10,
		fixedHeader: true,
		responsive: true,
		"sDom": 'rtip',
		columnDefs: [{
			targets: 'no-sort',
			orderable: false
		}]
	});

	var table = $('#example').DataTable();
	$('#key-search').on('keyup', function() {
		table.search(this.value).draw();
	});
  
});
</script>
	


    <!-- PAGE LEVEL SCRIPTS-->
</body>

</html>
