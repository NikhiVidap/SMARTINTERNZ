<?php 
require_once('lib/functions.php');
$db		=	new login_function();

$response = array();

if(isset($_POST['vehicle_id']))
{
	$vehicle_id	= $_POST['vehicle_id'];
	
	if($flag==0)
	{
		$db_id =	$db->get_vehicle_id_exist_id($vehicle_id);
		
		if($db_id=="")
		{
			if($db->save_entry_record($vehicle_id))
			{
				$response['status']	=	0;
				$response['message']	=	"Success";
			}
			else
			{
				$response['status']	=	1;
				$response['message']	=	"Failed to save";
			}
		}
		else
		{
			$response['status']	=	2;
			$response['message']	=	"Not Exist";		
		}
	}
}
echo json_encode($response);
?>