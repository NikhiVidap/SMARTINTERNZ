<?php 
require_once('lib/functions.php');

$db		=	new login_function();

/*if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}*/

		if(isset($_GET['edit_id']))
		{
			$edit_id	=	$_GET['edit_id'];
			$_SESSION['edit_id'] = $edit_id;
		}
		 else if(isset($_SESSION['edit_id']))
		{
			$edit_id	= $_SESSION['edit_id'];
		}
		
		if(isset($_POST['update']))
		{	
			$category 	= $_POST['category'];
			$title 		= $_POST['title'];
			$desc 		= $_POST['description'];
			$amount 	= $_POST['amount'];
			$date 		= $_POST['date'];
			
			
			if($db->update_expenses($category,$title,$desc,$amount,$date,$edit_id))
			{
			?>
				<script>
				alert("Successfully Updated...!!!");
				window.location.href="expenses.php";
				</script>
			<?php
				
			}
			else
			{
				$success_msg = 2 ;
			}
		}
	
	$db_expenses	=	array();
	$db_expenses = $db->get_expenses_by_id($edit_id);
	
	if(!empty($db_expenses))
	{
		$res_id		=	$db_expenses[0];
		$res_cat	=	$db_expenses[1];
		$res_tit	=	$db_expenses[2];
		$res_desc	=	$db_expenses[3];
		$res_amt	=	$db_expenses[4];
		$res_date	=	$db_expenses[5];
	}
	
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Update Expenses Category</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}

</style>

<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
</head>
<body class="fixed-navbar">

<div class="page-wrapper" style="height:800px;">

<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>

<div class="content-wrapper">
<center>
<div class="page-content fade-in-up">
<div class="ibox col-sm-6" style="border-radius:5px; padding:7px;">

<div class="ibox-body" style="padding:7px; padding-top:0px;">
	<div class="ibox-title">
			<div class="modal-content text-center">
						<?php
						$title="";
						?>
							<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data">
								<div class="ibox-head" style="text-align:center; background-color:#24B8E3;color:white !Important;">
									<div><i class="fas fa-cogs" style="margin-right:10px;"></i>Add Expenses</div>
								</div>
								<div class="ibox-body">
									
									
									<div class="col-sm-12 form-group mb-12">
									<div class="input-group-icon input-group-icon-left  set-row">
										<span class="input-icon input-icon-left"><i class="fa fa-check"></i></span>
										<select name="category" id="category" class="form-control form-control-air">
										<option value="Select Category" <?php if($res_cat=="Select Category") { ?> Selected <?php } ?> >Select Category</option>
												<?php

													$app_data	=	array();
													
													$app_data	=	$db->get_all_category_details();
													
													if(!empty($app_data))
													{
														$counter	=	0;
														
														foreach($app_data as $record)
														{
															$res_id			=	$record[0];
															$res_title		=	$record[1];
														?>
															<option value="<?php echo $res_id; ?>" <?php if($res_cat==$res_id) { ?> Selected <?php } ?>><?php echo $res_title; ?></option>
															<?php
															$counter++;
														}
													}
													?>
										</select>
									</div>
								</div>
								
								<div class="col-sm-12 form-group mb-12">
										<div class="input-group-icon input-group-icon-left  set-row">
											<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
											<input type="text" name="title" id="title" class="form-control form-control-air" value="<?php echo $res_tit; ?>" placeholder="Enter Title" required  />
										</div>
									</div>
									
									<div class="col-sm-12 form-group mb-12">
										<div class="input-group-icon input-group-icon-left  set-row">
											<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
											<input type="text" name="description" id="description" class="form-control form-control-air" value="<?php echo $res_desc; ?>" placeholder="Enter Description" required  />
										</div>
									</div>
									
									<div class="col-sm-12 form-group mb-12">
										<div class="input-group-icon input-group-icon-left  set-row">
											<span class="input-icon input-icon-left"><i class="fas fa-edit"></i></span>
											<input type="number" name="amount" id="amount" class="form-control form-control-air" value="<?php echo $res_amt; ?>" placeholder="Enter Amount" required  />
										</div>
									</div>
									
									<div class="col-sm-12 form-group mb-12">
										<div class="input-group-icon input-group-icon-left  set-row">
											<span class="input-icon input-icon-left"><i class="fas fa-calendar"></i></span>
											<div class="md-form md-outline input-with-post-icon datepicker">
												<input placeholder="Select date" type="date" name="date" id="date" value="<?php echo $res_date;?>" class="form-control">
											</div>
										</div>
									</div>
									
								</div>
								<div class="modal-footer flex-center">
									<button class="btn btn-info"  style="margin:auto;width:50%;" type="submit" name="update" style="width:100%;">Update</button>
								</div>
							</form>
						</div>
					</div>
				</div>
		</div>
	</div>
	</center>
</div>
	
	</div>
</div>
</div>
	</div>
</div>

		<?php include('footer.php'); ?>
	
<?php //include('search.php'); ?>
<!-- END SEARCH PANEL-->
<!-- BEGIN THEME CONFIG PANEL-->

<!-- END THEME CONFIG PANEL-->
<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
<div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- New question dialog-->

<!-- End New question dialog-->
<!-- QUICK SIDEBAR-->
<?php //include('right-side-bar.php'); ?>
<script src="js/jquery.min.js"></script>


<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->

<!-- CORE SCRIPTS-->
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
<script>
$(function() {
	$('#example').DataTable({
		pageLength: 10,
		fixedHeader: true,
		responsive: true,
		"sDom": 'rtip',
		columnDefs: [{
			targets: 'no-sort',
			orderable: false
		}]
	});

	var table = $('#example').DataTable();
	$('#key-search').on('keyup', function() {
		table.search(this.value).draw();
	});
  
});
</script>
	


    <!-- PAGE LEVEL SCRIPTS-->
</body>

</html>
