<?php 
require_once('lib/functions.php');

$db		=	new login_function();

if(isset($_SESSION['current_login_admin']))
{
	$current_login_admin	=	$_SESSION['current_login_admin'];
}
if(!isset($_SESSION['current_login_admin']))
{	
	header("location:index.php");
}
	if(isset($_GET['up_emp_id']))
	{
		$up_emp_id	=	$_GET['up_emp_id'];
		$_SESSION['up_emp_id'] = $up_emp_id;
	}
	else if(isset($_SESSION['up_emp_id']))
	{
		$up_emp_id	= $_SESSION['up_emp_id'];
	}
	
	
	if(isset($_GET['image']))
	{
		$image  = $_GET['image'];	
		$db->update_employee_image($up_emp_id);
		unlink('id_image/'.$image);
			
	}
	
	if(isset($_GET['pan_image']))
	{
		$pan_image  = $_GET['pan_image'];	
		$db->update_employee_pancard($up_emp_id);
		unlink('pancard_attachments/'.$pan_image);
		//header("Location:employee.php");	
	}
	
	if(isset($_GET['adhar_attach']))
	{
		$adhar_attach  = $_GET['adhar_attach'];	
		$db->update_employee_adharcard($up_emp_id);
		unlink('adhar_attachments/'.$adhar_attach);
		//header("Location:employee.php");	
	}
	if(isset($_GET['photo1']))
	{
		$photo1  = $_GET['photo1'];	
		$db->update_photo1($up_emp_id);
		unlink('property_photo/'.$photo1);
		//header("Location:employee.php");	
	}
	
	if(isset($_GET['photo2']))
	{
		$photo2  = $_GET['photo2'];	
		$db->update_photo2($up_emp_id);
		unlink('property_photo/'.$photo2);
		//header("Location:employee.php");	
	}
	if(isset($_GET['photo3']))
	{
		$photo3  = $_GET['photo1'];	
		$db->update_photo3($up_emp_id);
		unlink('property_photo/'.$photo3);
		//header("Location:employee.php");	
	}
	if(isset($_GET['photo4']))
	{
		$photo4  = $_GET['photo4'];	
		$db->update_photo4($up_emp_id);
		unlink('property_photo/'.$photo4);
		//header("Location:employee.php");	
	}

$record	=	array();
$record = $db->get_rent_property_details_by_id($up_emp_id);
if(!empty($record))
{
	$id							=	$record[0];
	$res_image					=	$record[6];
	$res_pan_attach				=	$record[7];
	$res_adhar_attach			=	$record[8];
	$property_photo1		=	$record[16];
	$property_photo2		=	$record[17];
	$property_photo3		=	$record[18];
	$property_photo4		=	$record[19];
}	
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Update Images</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/line-awesome.min.css" rel="stylesheet" />
    <link href="css/themify-icons.css" rel="stylesheet" />
    <link href="css/animate.min.css" rel="stylesheet" />
    <link href="css/toastr.min.css" rel="stylesheet" />
    <link href="css/bootstrap-select.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
  
    <!-- PLUGINS STYLES-->
    <!-- THEME STYLES-->
    <link href="css/main.min.css" rel="stylesheet" />
	 <link href="datatable/datatables.min.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
<style>
.col-md-12
{
	width:100%;
	margin:auto;
	margin-top:20px;
}
table,th,td
{
	text-align:center;
}
@media only screen and (max-width: 600px) {
	.col-md-12
	{
		width:100%;
	}
	.alert
	{
		width:100%;
	}
	.side-row
	{
		width:49%;
		display:inline-table;
	}
}
.my-custom-scrollbar {
position: relative;
height: 800px;
overflow: auto;
}
.table-wrapper-scroll-y {
display: block;
}
</style>

<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
</head>
<body class="fixed-navbar">

<div class="page-wrapper" style="height:800px;">

<?php include('header.php'); ?>
<?php include('side-bar.php'); ?>

<div class="content-wrapper">
<div class="row" style="padding:0px; margin:0px; margin-top:15px; border-radius:15px;">

<div class="ibox" style="border-radius:5px; padding:7px;">
		<div class="ibox-head">
			<div class="ibox-title"><i class="fas fa-user-tie" style="margin-right:10px;"></i>UPDATE  Attachments</div>
			<a href="update-rented-property.php?up_id=<?php echo $id; ?>" class="btn btn-primary btn-air"><i class="fas fa-edit">&nbsp;&nbsp;</i>UPDATE RENTED PROPERTY</a>

			<a href="rented-property-master.php" class="btn btn-outline-danger btn-rounded waves-effect"><i class="fas fa-angle-double-left">&nbsp;&nbsp;</i>RENTED PROPERTY MASTER</a>

		</div>
	<div class="row">
	<div class="col-sm-4" style="border-radius:5px; padding:50px;">
		<?php
			$flag=0;
			$image="";
			if(isset($_POST['update_image']))
			{
			$valid_formats = array("jpg","png","gif","bmp","jpeg","pdf","JPEG","JPG","BMP","PNG","GIF","PDF");

			if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
			{	
			$name 				= 	$_FILES['image']['name'];
			$size 				= 	$_FILES['image']['size'];

			if(strlen($name))
			{				
			list($txt, $ext) = explode(".", $name);

			if(in_array($ext,$valid_formats))
			{
				$files	=	array();

				function generateRandomString($length = 10) {
					$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) 
					{
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
				
				$current_random_string = generateRandomString();
				
				$actual_image = $current_random_string.".".strtolower($ext);						

				$tmp = $_FILES['image']['tmp_name'];
				
				$img_Dir = "id_image/";
				
				if(!file_exists($img_Dir))
				{
					mkdir($img_Dir);
				}
				
				if(move_uploaded_file($tmp,$img_Dir.$actual_image))
				{
					
				}
				else
				{
					$image_error	=	"failed" ;
					$flag				=	1;
				}	
			}
			else
			{
				$image_error	= "Invalid file format";
				$flag				=	1;	
			}	
			}	
			}

			if($flag==0)
			{
			if($db->update_employee_image_attach($actual_image,$id))
			{
			?>
			<script>
			alert("Employee Image Updated Successfully...!!!");
			window.location.href="update-rent-images.php";
			</script>
			<?php

			}
			else
			{
			$success_msg = 2 ;
			}
			}
			}
			?>
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data" >
<div style="margin-right:10px;font-size:16px;color:#E4287C;font-weight:bold;">Update Image</div>
<div class="input-group-icon input-group-icon-left  set-row">
<?php
if($res_image!= "")
{
?>
<a href="id_image/<?php echo $res_image; ?>" target="_blank"><img src="id_image/<?php echo $res_image; ?>" height="50px" width="50px"></a><br />
<label><a href="update-rent-images.php?image=<?php echo $res_image; ?>" onclick="return confirm('Are You Sure to Remove Image');" style="font-size:12px;color:red;">Remove Image</a></label>

<?php
}
else
{
?>
<img src="icon/no-image.png" height="50px" width="200px">

<?php
}
?>
</div>
<label class="form-group set-row label_marg"><b>Upload</b></label>
<input class="form-control form-control-air " placeholder="Upload Image" name="image" type="file" required>
<button class="btn btn-info"  style="margin:auto;margin-top:10px;width:100%;" type="submit" name="update_image" onclick="submitData()" style="width:100%;">Update</button>
</form>
</div>

<div class="col-sm-4" style="border-radius:5px; padding:50px;">
<?php
$flag=0;
$adhar_attach="";
if(isset($_POST['update_pan']))
{
$valid_formats = array("jpg","png","gif","bmp","jpeg","pdf","JPEG","JPG","BMP","PNG","GIF","PDF");

if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{	
$name 				= 	$_FILES['pan_attach']['name'];
$size 				= 	$_FILES['pan_attach']['size'];

if(strlen($name))
{				
list($txt, $ext) = explode(".", $name);

if(in_array($ext,$valid_formats))
{
	$files	=	array();

	function generateRandomString($length = 10) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
		{
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	$current_random_string = generateRandomString();
	
	$actual_pan_attach = $current_random_string.".".strtolower($ext);						

	$tmp = $_FILES['pan_attach']['tmp_name'];
	
	$img_Dir = "pancard_attachments/";
	
	if(!file_exists($img_Dir))
	{
		mkdir($img_Dir);
	}
	
	if(move_uploaded_file($tmp,$img_Dir.$actual_pan_attach))
	{
		
	}
	else
	{
		$image_error	=	"failed" ;
		$flag				=	1;
	}	
}
else
{
	$image_error	= "Invalid file format";
	$flag				=	1;	
}	
}	
}

if($flag==0)
{
if($db->update_employee_pancard_attach($actual_pan_attach,$id))
{
?>
<script>
alert("PanCard Updated Successfully...!!!");
window.location.href="update-rent-images.php";
</script>
<?php

}
else
{
$success_msg = 2 ;
}
}
}

?>
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data" >
<div style="margin-right:10px;font-size:16px;color:#E4287C;font-weight:bold;">Update Pan Card</div>
<div class="input-group-icon input-group-icon-left  set-row">
<?php
if($res_pan_attach!= "")
{
?>
<a href="pancard_attachments/<?php echo $res_pan_attach; ?>" target="_blank"><img src="pancard_attachments/<?php echo $res_pan_attach; ?>" height="50px" width="50px"></a><br />
<label><a href="update-rent-images.php?pan_image=<?php echo $res_pan_attach; ?>" onclick="return confirm('Are You Sure to Remove Attachment');" style="font-size:12px;color:red;">Remove </a></label>

<?php
}
else
{
?>
<img src="icon/no-image.png" height="50px" width="200px">

<?php
}
?>
<br />
<label class="form-group set-row label_marg"><b>Upload</b></label>
<input class="form-control form-control-air " placeholder="Upload Pan Card Attachment" name="pan_attach" type="file" required>
<button class="btn btn-info"  type="submit" name="update_pan" style="margin-top:10px;width:100%;">Update</button>
</div>
</form>
</div>
<br />
<div class="col-sm-4" style="border-radius:5px; padding:50px; border:1px;">
<?php
$flag=0;
$adhar_attach="";
if(isset($_POST['update_adhar']))
{
$valid_formats = array("jpg","png","gif","bmp","jpeg","pdf","JPEG","JPG","BMP","PNG","GIF","PDF");

if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
{	
$name 				= 	$_FILES['adhar_attach']['name'];
$size 				= 	$_FILES['adhar_attach']['size'];

if(strlen($name))
{				
list($txt, $ext) = explode(".", $name);

if(in_array($ext,$valid_formats))
{
	$files	=	array();

	function generateRandomString($length = 10) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
		{
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	$current_random_string = generateRandomString();
	
	$actual_adhar_attach = $current_random_string.".".strtolower($ext);						

	$tmp = $_FILES['adhar_attach']['tmp_name'];
	
	$img_Dir = "adhar_attachments/";
	
	if(!file_exists($img_Dir))
	{
		mkdir($img_Dir);
	}
	
	if(move_uploaded_file($tmp,$img_Dir.$actual_adhar_attach))
	{
		
	}
	else
	{
		$image_error	=	"failed" ;
		$flag				=	1;
	}	
}
else
{
	$image_error	= "Invalid file format";
	$flag				=	1;	
}	
}	
}

if($flag==0)
{
if($db->update_employee_adhar_attach($actual_adhar_attach,$id))
{
?>
<script>
alert("Adharcard Updated Successfully...!!!");
window.location.href="update-rent-images.php";
</script>
<?php

}
else
{
$success_msg = 2 ;
}
}
}

?>
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data" >
<div style="margin-right:10px;font-size:16px;color:#E4287C;font-weight:bold;">Update Aadhar Card</div>
<div class="input-group-icon input-group-icon-left  set-row">
<?php
if($res_adhar_attach!= "")
{
?>
<a href="adhar_attachments/<?php echo $res_adhar_attach; ?>" target="_blank"><img src="adhar_attachments/<?php echo $res_adhar_attach; ?>" height="50px" width="70px"></a><br/>
<label><a href="update-rent-images.php?adhar_attach=<?php echo $res_adhar_attach; ?>" onclick="return confirm('Are You Sure to Remove Image');" style="font-size:12px;color:red;">Remove</a></label>

<?php
}
else
{
?>
<img src="icon/no-image.png" height="50px" width="200px">

<?php
}
?>
</div>
<label class="form-group set-row label_marg"><b>Upload</b></label><input class="form-control form-control-air " placeholder="Upload Aadhar Card Attachment" name="adhar_attach" type="file" required>
<button class="btn btn-info"  style="margin-top:10px;width:100%;" type="submit" name="update_adhar">Update</button>
</div>

</form>
</div>
		
<!--------photo--------------->	
<div class="row">
	<div class="col-sm-4" style="border-radius:5px; padding:50px;">
		<?php
			$flag=0;
			$image="";
			if(isset($_POST['update_photo1']))
			{
			$valid_formats = array("jpg","png","gif","bmp","jpeg","pdf","JPEG","JPG","BMP","PNG","GIF","PDF");

			if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
			{	
			$name 				= 	$_FILES['photo1']['name'];
			$size 				= 	$_FILES['photo1']['size'];

			if(strlen($name))
			{				
			list($txt, $ext) = explode(".", $name);

			if(in_array($ext,$valid_formats))
			{
				$files	=	array();

				function generateRandomString($length = 10) {
					$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) 
					{
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
				
				$current_random_string = generateRandomString();
				
				$actual_image = $current_random_string.".".strtolower($ext);						

				$tmp = $_FILES['photo1']['tmp_name'];
				
				$img_Dir = "property_photo/";
				
				if(!file_exists($img_Dir))
				{
					mkdir($img_Dir);
				}
				
				if(move_uploaded_file($tmp,$img_Dir.$actual_image))
				{
					
				}
				else
				{
					$image_error	=	"failed" ;
					$flag				=	1;
				}	
			}
			else
			{
				$image_error	= "Invalid file format";
				$flag				=	1;	
			}	
			}	
			}

			if($flag==0)
			{
			if($db->update_photo1_attach($actual_image,$id))
			{
			?>
			<script>
			alert(" Image Updated Successfully...!!!");
			window.location.href="update-rent-images.php";
			</script>
			<?php

			}
			else
			{
			$success_msg = 2 ;
			}
			}
			}
			?>
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data" >
<div style="margin-right:10px;font-size:16px;color:#E4287C;font-weight:bold;">Update Property Photo1</div>
<div class="input-group-icon input-group-icon-left  set-row">
<?php
if($property_photo1!= "")
{
?>
<a href="property_photo/<?php echo $property_photo1; ?>" target="_blank"><img src="property_photo/<?php echo $property_photo1; ?>" height="50px" width="50px"></a><br />
<label><a href="update-rent-images.php?photo1=<?php echo $property_photo1; ?>" onclick="return confirm('Are You Sure to Remove Image');" style="font-size:12px;color:red;">Remove Image</a></label>

<?php
}
else
{
?>
<img src="icon/no-image.png" height="50px" width="200px">

<?php
}
?>
</div>
<label class="form-group set-row label_marg"><b>Upload</b></label>
<input class="form-control form-control-air " placeholder="Upload Image" name="photo1" type="file" required>
<button class="btn btn-info"  style="margin:auto;margin-top:10px;width:100%;" type="submit" name="update_photo1" onclick="submitData()" style="width:100%;">Update</button>
</form>
</div>

<div class="col-sm-4" style="border-radius:5px; padding:50px;">
		<?php
			$flag=0;
			$image="";
			if(isset($_POST['update_photo2']))
			{
			$valid_formats = array("jpg","png","gif","bmp","jpeg","pdf","JPEG","JPG","BMP","PNG","GIF","PDF");

			if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
			{	
			$name 				= 	$_FILES['photo2']['name'];
			$size 				= 	$_FILES['photo2']['size'];

			if(strlen($name))
			{				
			list($txt, $ext) = explode(".", $name);

			if(in_array($ext,$valid_formats))
			{
				$files	=	array();

				function generateRandomString($length = 10) {
					$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) 
					{
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
				
				$current_random_string = generateRandomString();
				
				$actual_image = $current_random_string.".".strtolower($ext);						

				$tmp = $_FILES['photo2']['tmp_name'];
				
				$img_Dir = "property_photo/";
				
				if(!file_exists($img_Dir))
				{
					mkdir($img_Dir);
				}
				
				if(move_uploaded_file($tmp,$img_Dir.$actual_image))
				{
					
				}
				else
				{
					$image_error	=	"failed" ;
					$flag				=	1;
				}	
			}
			else
			{
				$image_error	= "Invalid file format";
				$flag				=	1;	
			}	
			}	
			}

			if($flag==0)
			{
			if($db->update_photo2_attach($actual_image,$id))
			{
			?>
			<script>
			alert(" Image Updated Successfully...!!!");
			window.location.href="update-rent-images.php";
			</script>
			<?php

			}
			else
			{
			$success_msg = 2 ;
			}
			}
			}
			?>
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data" >
<div style="margin-right:10px;font-size:16px;color:#E4287C;font-weight:bold;">Update Property Photo 2</div>
<div class="input-group-icon input-group-icon-left  set-row">
<?php
if($property_photo2!= "")
{
?>
<a href="property_photo/<?php echo $property_photo2; ?>" target="_blank"><img src="property_photo/<?php echo $property_photo2; ?>" height="50px" width="50px"></a><br />
<label><a href="update-rent-images.php?photo1=<?php echo $property_photo2; ?>" onclick="return confirm('Are You Sure to Remove Image');" style="font-size:12px;color:red;">Remove Image</a></label>

<?php
}
else
{
?>
<img src="icon/no-image.png" height="50px" width="200px">

<?php
}
?>
</div>
<label class="form-group set-row label_marg"><b>Upload</b></label>
<input class="form-control form-control-air " placeholder="Upload Image" name="photo2" type="file" required>
<button class="btn btn-info"  style="margin:auto;margin-top:10px;width:100%;" type="submit" name="update_photo2" onclick="submitData()" style="width:100%;">Update</button>
</form>
</div>
<div class="col-sm-4" style="border-radius:5px; padding:50px;">
		<?php
			$flag=0;
			$image="";
			if(isset($_POST['update_photo3']))
			{
			$valid_formats = array("jpg","png","gif","bmp","jpeg","pdf","JPEG","JPG","BMP","PNG","GIF","PDF");

			if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
			{	
			$name 				= 	$_FILES['photo3']['name'];
			$size 				= 	$_FILES['photo3']['size'];

			if(strlen($name))
			{				
			list($txt, $ext) = explode(".", $name);

			if(in_array($ext,$valid_formats))
			{
				$files	=	array();

				function generateRandomString($length = 10) {
					$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) 
					{
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
				
				$current_random_string = generateRandomString();
				
				$actual_image = $current_random_string.".".strtolower($ext);						

				$tmp = $_FILES['photo3']['tmp_name'];
				
				$img_Dir = "property_photo/";
				
				if(!file_exists($img_Dir))
				{
					mkdir($img_Dir);
				}
				
				if(move_uploaded_file($tmp,$img_Dir.$actual_image))
				{
					
				}
				else
				{
					$image_error	=	"failed" ;
					$flag				=	1;
				}	
			}
			else
			{
				$image_error	= "Invalid file format";
				$flag				=	1;	
			}	
			}	
			}

			if($flag==0)
			{
			if($db->update_photo3_attach($actual_image,$id))
			{
			?>
			<script>
			alert(" Image Updated Successfully...!!!");
			window.location.href="update-rent-images.php";
			</script>
			<?php

			}
			else
			{
			$success_msg = 2 ;
			}
			}
			}
			?>
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data" >
<div style="margin-right:10px;font-size:16px;color:#E4287C;font-weight:bold;">Update Property Photo 3</div>
<div class="input-group-icon input-group-icon-left  set-row">
<?php
if($property_photo3!= "")
{
?>
<a href="property_photo/<?php echo $property_photo3; ?>" target="_blank"><img src="property_photo/<?php echo $property_photo3; ?>" height="50px" width="50px"></a><br />
<label><a href="update-rent-images.php?photo3=<?php echo $property_photo3; ?>" onclick="return confirm('Are You Sure to Remove Image');" style="font-size:12px;color:red;">Remove Image</a></label>

<?php
}
else
{
?>
<img src="icon/no-image.png" height="50px" width="200px">

<?php
}
?>
</div>
<label class="form-group set-row label_marg"><b>Upload</b></label>
<input class="form-control form-control-air " placeholder="Upload Image" name="photo3" type="file" required>
<button class="btn btn-info"  style="margin:auto;margin-top:10px;width:100%;" type="submit" name="update_photo3" onclick="submitData()" style="width:100%;">Update</button>
</form>
</div>
</div>
<div class="row">
<div class="col-sm-3" style="border-radius:5px; padding:50px;">
		<?php
			$flag=0;
			$image="";
			if(isset($_POST['update_photo4']))
			{
			$valid_formats = array("jpg","png","gif","bmp","jpeg","pdf","JPEG","JPG","BMP","PNG","GIF","PDF");

			if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
			{	
			$name 				= 	$_FILES['photo4']['name'];
			$size 				= 	$_FILES['photo4']['size'];

			if(strlen($name))
			{				
			list($txt, $ext) = explode(".", $name);

			if(in_array($ext,$valid_formats))
			{
				$files	=	array();

				function generateRandomString($length = 10) {
					$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
					$charactersLength = strlen($characters);
					$randomString = '';
					for ($i = 0; $i < $length; $i++) 
					{
						$randomString .= $characters[rand(0, $charactersLength - 1)];
					}
					return $randomString;
				}
				
				$current_random_string = generateRandomString();
				
				$actual_image = $current_random_string.".".strtolower($ext);						

				$tmp = $_FILES['photo4']['tmp_name'];
				
				$img_Dir = "property_photo/";
				
				if(!file_exists($img_Dir))
				{
					mkdir($img_Dir);
				}
				
				if(move_uploaded_file($tmp,$img_Dir.$actual_image))
				{
					
				}
				else
				{
					$image_error	=	"failed" ;
					$flag				=	1;
				}	
			}
			else
			{
				$image_error	= "Invalid file format";
				$flag				=	1;	
			}	
			}	
			}

			if($flag==0)
			{
			if($db->update_photo4_attach($actual_image,$id))
			{
			?>
			<script>
			alert(" Image Updated Successfully...!!!");
			window.location.href="update-rent-images.php";
			</script>
			<?php

			}
			else
			{
			$success_msg = 2 ;
			}
			}
			}
			?>
<form class="form-pink" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="myForm" onsubmit="return validateForm()" autocomplete="off" enctype="multipart/form-data" >
<div style="margin-right:10px;font-size:16px;color:#E4287C;font-weight:bold;">Update Property Photo 4</div>
<div class="input-group-icon input-group-icon-left  set-row">
<?php
if($property_photo4!= "")
{
?>
<a href="property_photo/<?php echo $property_photo4; ?>" target="_blank"><img src="property_photo/<?php echo $property_photo4; ?>" height="50px" width="50px"></a><br />
<label><a href="update-rent-images.php?photo4=<?php echo $property_photo4; ?>" onclick="return confirm('Are You Sure to Remove Image');" style="font-size:12px;color:red;">Remove Image</a></label>

<?php
}
else
{
?>
<img src="icon/no-image.png" height="50px" width="200px">

<?php
}
?>
</div>
<label class="form-group set-row label_marg"><b>Upload</b></label>
<input class="form-control form-control-air " placeholder="Upload Image" name="photo4" type="file" required>
<button class="btn btn-info"  style="margin:auto;margin-top:10px;width:100%;" type="submit" name="update_photo4" onclick="submitData()" style="width:100%;">Update</button>
</form>
</div>
	
	
	
	
	
	
	
	</div>
</div>
</div>
</div>
			

<?php include('footer.php'); ?>
	
<?php //include('search.php'); ?>
<!-- END SEARCH PANEL-->
<!-- BEGIN THEME CONFIG PANEL-->

<!-- END THEME CONFIG PANEL-->
<!-- BEGIN PAGA BACKDROPS-->
<div class="sidenav-backdrop backdrop"></div>
<div class="preloader-backdrop">
<div class="page-preloader">Loading</div>
</div>
<!-- END PAGA BACKDROPS-->
<!-- New question dialog-->

<!-- End New question dialog-->
<!-- QUICK SIDEBAR-->
<?php //include('right-side-bar.php'); ?>
<script src="js/jquery.min.js"></script>


<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/idle-timer.min.js"></script>
<script src="js/toastr.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<!-- PAGE LEVEL PLUGINS-->

<!-- CORE SCRIPTS-->
<script src="datatable/datatables.min.js"></script>
<script src="js/app.min.js"></script>
<script>
$(function() {
	$('#example').DataTable({
		pageLength: 10,
		fixedHeader: true,
		responsive: true,
		"sDom": 'rtip',
		columnDefs: [{
			targets: 'no-sort',
			orderable: false
		}]
	});

	var table = $('#example').DataTable();
	$('#key-search').on('keyup', function() {
		table.search(this.value).draw();
	});
  
});
</script>
	


    <!-- PAGE LEVEL SCRIPTS-->
</body>

</html>
