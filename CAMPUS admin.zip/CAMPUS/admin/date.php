<?php
$todays_date=date('Y-m-d',strtotime("+1 days"));
 
$expiry_date = date('Y-m-d', strtotime($todays_date. ' + ' .$package_days. ' days ' )); 

?>