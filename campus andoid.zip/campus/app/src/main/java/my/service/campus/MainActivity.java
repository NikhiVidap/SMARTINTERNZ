package my.service.campus;

import static my.service.campus.API.Constant.Baseurl;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;

import java.io.IOException;

import my.service.campus.API.ApiNew1;
import my.service.campus.API.List.DefualtList.DefualtList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class MainActivity extends AppCompatActivity {

    private CameraSource mCameraSource;
    private TextRecognizer mTextRecognizer;
    private SurfaceView mSurfaceView;
    private TextView mTextView;
    private Button b1,b2,logout;
    private LinearLayout l1;
    private EditText e1;
    private Toolbar mToolbar;
    private static final int RC_HANDLE_CAMERA_PERM = 2;
    public static final String MyPREFERENCES2 = "MainActivity" ;
    public static final String ocr_text = "ocr_text";
    SharedPreferences sharedpreferences1;

    public static final String MyPREFERENCES = "UserData" ;
    SharedPreferences sharedpreferences2;
    public static final String Varify_account = "Varify_account";
    public static final String phone_number1 = "phone_number1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mToolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(mToolbar);
        ActionBar actionBar = getSupportActionBar();

        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        mSurfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        mTextView = (TextView) findViewById(R.id.textView);
        b1 =  findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        l1 = findViewById(R.id.l1);
        e1 = findViewById(R.id.e1);
        logout = findViewById(R.id.logout);


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sharedpreferences1 = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor1 = sharedpreferences1.edit();
                editor1.putString(phone_number1, "logout");

                editor1.commit();
                startActivity(new Intent(MainActivity.this, LoginDashboard.class));
                finish();



            }
        });



        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sharedpreferences1 = getSharedPreferences(MyPREFERENCES2, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences1.edit();
                editor.putString(ocr_text, e1.getText().toString());

                editor.commit();


                String str=e1.getText().toString();

                getdata(str);




              // startActivity(new Intent(MainActivity.this, OCRLIST.class));

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(!mTextView.getText().toString().isEmpty())
                {
                    l1.setVisibility(View.VISIBLE);
                    e1.setText(mTextView.getText().toString());
                }
                else
                {


                    Toast.makeText(MainActivity.this, "Empty", Toast.LENGTH_SHORT).show();

                }



            }
        });



        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startTextRecognizer();
        } else {
            askCameraPermission();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mCameraSource.release();
    }

    private void startTextRecognizer() {
        mTextRecognizer = new TextRecognizer.Builder(getApplicationContext()).build();

        if (!mTextRecognizer.isOperational()) {
            Toast.makeText(getApplicationContext(), "Oops ! Not able to start the text recognizer ...", Toast.LENGTH_LONG).show();
        } else {
            mCameraSource = new CameraSource.Builder(getApplicationContext(), mTextRecognizer)
                    .setFacing(CameraSource.CAMERA_FACING_BACK)
                    .setRequestedPreviewSize(1280, 1024)
                    .setRequestedFps(15.0f)
                    .setAutoFocusEnabled(true)
                    .build();

            mSurfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
                @Override
                public void surfaceCreated(SurfaceHolder holder) {
                    if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        try {
                            mCameraSource.start(mSurfaceView.getHolder());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        askCameraPermission();
                    }
                }

                @Override
                public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

                }

                @Override
                public void surfaceDestroyed(SurfaceHolder holder) {
                    mCameraSource.stop();
                }
            });

            mTextRecognizer.setProcessor(new Detector.Processor<TextBlock>() {
                @Override
                public void release() {

                }

                @Override
                public void receiveDetections(Detector.Detections<TextBlock> detections) {
                    SparseArray<TextBlock> items = detections.getDetectedItems();
                    StringBuilder stringBuilder = new StringBuilder();
                    for (int i = 0; i < items.size(); ++i) {
                        TextBlock item = items.valueAt(i);
                        if (item != null && item.getValue() != null) {
                            stringBuilder.append(item.getValue() + " ");
                        }
                    }

                    final String fullText = stringBuilder.toString();
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        public void run() {


                            String white=fullText.replace(" ","");

                            mTextView.setText(white);


                        }
                    });

                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode != RC_HANDLE_CAMERA_PERM) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            return;
        }

        if (grantResults.length != 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startTextRecognizer();
            return;
        }

    }

    private void askCameraPermission() {

        final String[] permissions = new String[]{Manifest.permission.CAMERA};

        if (!ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.CAMERA)) {
            ActivityCompat.requestPermissions(this, permissions, RC_HANDLE_CAMERA_PERM);
            return;
        }

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:{



                onBackPressed();
                return true;
            }

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    private void getdata(String v_no)
    {



        ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setTitle("Please Wait..");
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();



        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(Baseurl)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiNew1 postApiNew=retrofit.create(ApiNew1.class);



        String a="a";
        Call<DefualtList> call=postApiNew.entry_record(v_no);
        call.enqueue(new Callback<DefualtList>() {
            @Override
            public void onResponse(Call<DefualtList> call, Response<DefualtList> response) {
                if(!response.isSuccessful())
                {
                    progressDialog.hide();
                    Log.i("MyActivity", "Code1:"+response.code());
                    Toast.makeText(getApplicationContext(), "Not Available", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, Final1.class);
                    intent.putExtra("key", "0");
                    startActivity(intent);
                    finish();
                    return;
                }

                Log.i("MyActivity", "Code1:"+response.code());

                if(response.body().getMessage()==null)
                {
                    Toast.makeText(getApplicationContext(), "Error code 401", Toast.LENGTH_SHORT).show();
                    progressDialog.hide();
                    Log.i("MyActivity", "Empty");
                    Toast.makeText(getApplicationContext(), "Not Available", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, Final1.class);
                    intent.putExtra("key", "0");
                    startActivity(intent);
                    finish();
                }
                else
                {

                    if(response.body().getStatus()!=0)
                    {
                        Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        progressDialog.hide();
                        Log.i("MyActivity",response.body().getMessage().toString());
                        Log.i("MyActivity","Wrong");
                        String id1= response.body().getMessage();
                        Toast.makeText(getApplicationContext(), id1, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, Final1.class);
                        intent.putExtra("key", "0");
                        startActivity(intent);
                        finish();

                    }
                    else
                    {

                        progressDialog.hide();
                        Log.i("MyActivity","correct");
                        Log.i("MyActivity",response.body().getStatus()+"");



                            String id1= response.body().getMessage();



                            Toast.makeText(getApplicationContext(), id1, Toast.LENGTH_SHORT).show();
                          //  Toast.makeText(getApplicationContext(), response.body().getStatus()+"", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MainActivity.this, Final1.class);
                            intent.putExtra("key", "1");
                            startActivity(intent);
                            finish();













                    }

                }

            }
            @Override
            public void onFailure(Call<DefualtList> call, Throwable t)
            {
                progressDialog.hide();
                Log.i("MyActivity", t.getMessage());
                Toast.makeText(getApplicationContext(), "Not Available", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, Final1.class);
                intent.putExtra("key", "0");
                startActivity(intent);
                finish();

            }
        });


    }


}
