package my.service.campus.API;

public class Constant {


    public static String Baseurl="https://campus.saioc.in/";








}
