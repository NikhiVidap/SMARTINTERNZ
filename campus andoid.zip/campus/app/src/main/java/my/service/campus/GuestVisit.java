package my.service.campus;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;



import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;


import my.service.campus.API.ApiNew1;
import my.service.campus.API.List.DefualtList.DefualtList;
import my.service.campus.R;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.os.Build.VERSION.SDK_INT;
import static my.service.campus.API.Constant.Baseurl;


public class GuestVisit extends AppCompatActivity {


    private ImageView img11,img12;
    private String Selectimg="0";

    private  Button buttonContinue;
    String gallery_file_path, all_file_path, file_name;
    private Uri filePath;
    public static final String EXTRA_TEXT = "my.service.rbdigitalnew.EXTRA_TEXT";
    public static final int PERMISSION_WRITE = 0;

    public static final String MyPREFERENCES1 = "userdata" ;

    public static final String name = "name";
    public static final String phonenumber = "phonenummber";
    SharedPreferences sharedpreferences;


    private int STORAGE_PERMISSION_CODE = 1;
    private long downloadId;
    public static final String MyPREFERENCES = "ChatData" ;

    public static final String msg = "msg";
    private static String servie;
    private Spinner spin;


    private TextView open_image;

    private Toolbar mToolbar;




    private CardView card1,card2;

    private ImageView imageView,imageView1,image,edit;

    String fileUri;
    private static String cityselect,service;

    private String stuff1;


    private static final int CAMERA_REQUEST = 1888;
    private String  s_stage,s_stage_id;
    private static final int MY_CAMERA_PERMISSION_CODE = 100;
    private final int PICK_IMAGE_REQUEST = 10;

    private ProgressDialog progressDialog;
    private String imgselect="";
    private String imgselect1="";
    private String imgselect2="";
    private String imgselect3="";
    private String imgselect4="";


    private String file_imgselect="";
    private String file_imgselect1="";
    private String file_imgselect2="";
    private String file_imgselect3="";
    private String file_imgselect4="";





    final static  int conn=333;
    RatingBar ratingBar;

    private TextView t3,t4;
    private static  String Appuserid="0";
    private EditText e1,e2,e3,e4,e5;

    private Button btn_save;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guest_visit);


        img11 =  findViewById(R.id.img11);
        img12 =  findViewById(R.id.img12);


        mToolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(mToolbar);
        ActionBar actionBar = getSupportActionBar();

        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);


        e1=  findViewById(R.id.e1);
        e2=  findViewById(R.id.e2);
        e3=  findViewById(R.id.e3);
        e4=  findViewById(R.id.e4);
        e5=  findViewById(R.id.e5);










        btn_save=  findViewById(R.id.btn_save);








        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                final String se1 = e1.getText().toString().trim();
                final String se2 = e2.getText().toString().trim();
                final String se3 = e3.getText().toString().trim();
                final String se4 = e4.getText().toString().trim();
                final String se5 = e5.getText().toString().trim();



                if (TextUtils.isEmpty(se1)) {
                    Toast.makeText(getApplicationContext(), "Enter Detail", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (se1.contains(" ")) {
                    Toast.makeText(getApplicationContext(), "Enter Detail Without Space", Toast.LENGTH_SHORT).show();
                    return;
                }




                if (TextUtils.isEmpty(se2)) {
                    Toast.makeText(getApplicationContext(), "Enter Detail", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(se3)) {
                    Toast.makeText(getApplicationContext(), "Enter Detail", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(se4)) {
                    Toast.makeText(getApplicationContext(), "Enter Detail", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(se5)) {
                    Toast.makeText(getApplicationContext(), "Enter Detail", Toast.LENGTH_SHORT).show();
                    return;
                }



                GetRegistration();


            }
        });















        img11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Selectimg="2";
                chooseImage();


            }
        });




        img12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Selectimg="3";
                chooseImage();


            }
        });





        ActivityCompat.requestPermissions(GuestVisit.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

        if (ContextCompat.checkSelfPermission(GuestVisit.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

        } else {
            //   requestStoragePermission();
        }

        checkPermission();




        //   CheckPermission();

        if (ContextCompat.checkSelfPermission(GuestVisit.this,
                WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

        } else {
            //     requestStoragePermission();
        }



        if(CheckPermission())
        {
            // method = 0;
            if (SDK_INT >= 23) {
                if (checkPermission(WRITE_EXTERNAL_STORAGE)) {
                    //  filePicker(0);
                } else {

                    Log.i("MyActivity","1");
                    requestPermission(WRITE_EXTERNAL_STORAGE);
                }
            } else {
                //  filePicker(0);
            }
        }
        else
        {
            Log.i("MyActivity","2");
            RequestPermission1();
        }




    }



    private void Submitdata()
    {

        ImageUpload();

    }




    private void GetRegistration()
    {






        final String se1 = e1.getText().toString().trim();
        final String se2 = e2.getText().toString().trim();
        final String se3 = e3.getText().toString().trim();
        final String se4 = e4.getText().toString().trim();
        final String se5 = e5.getText().toString().trim();


        ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(GuestVisit.this);
        progressDialog.setTitle("Please Wait..");
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();





        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(Baseurl)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiNew1 postApiNew=retrofit.create(ApiNew1.class);






        try {

            JSONObject paramObject = new JSONObject();
            paramObject.put("querys", "App_GetAccountName 0,0,0");



            Call<DefualtList> call=postApiNew.add_guest(
                    se1,se2,se3,se4,se5, file_imgselect1,file_imgselect2);
            //   Call<DefualtList> call=postApiNew.agent_e_paper(s1,se1,se2,"as","as","As");
            call.enqueue(new Callback<DefualtList>() {
                @Override
                public void onResponse(Call<DefualtList> call, Response<DefualtList> response) {
                    if(!response.isSuccessful())
                    {
                        progressDialog.hide();
                        Log.i("MyActivity", "Code1:"+response.code());
                        Log.i("MyActivity", "Code1:"+response.message());
                        return;
                    }

                    Log.i("MyActivity", "Code1:"+response.code());
                    Log.i("MyActivity", "Code1:"+response.message());

                    if(response.body().getMessage()==null)
                    {
                        Toast.makeText(getApplicationContext(), "Error code 401", Toast.LENGTH_SHORT).show();
                        progressDialog.hide();
                        Log.i("MyActivity", "Empty");
                    }
                    else
                    {
                        Log.i("MyActivity", response.body().getMessage());
                        if(response.body().getStatus()!=0)
                        {
                            Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            progressDialog.hide();
                            Log.i("MyActivity", "This user is already exist");
                        }
                        else
                        {

                            Log.i("MyActivity", "yes");
                            progressDialog.hide();

                            Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();

                            Intent i = new Intent(GuestVisit.this, HomeActivity.class);

                            startActivity(i);

                            //    }

                        }



                    }



                }
                @Override
                public void onFailure(Call<DefualtList> call, Throwable t)
                {
                    progressDialog.hide();
                    Log.i("MyActivity", t.getMessage());
                }
            });


        } catch (JSONException e) {
            progressDialog.hide();

            e.printStackTrace();
            Log.i("MyActivity", e.getMessage());
        }


    }





    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);

            }
            else
            {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }

        if (requestCode==PERMISSION_WRITE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //do somethings
        }




    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);


                 if(Selectimg.equals("2"))
                {
                    img11.setImageBitmap(bitmap);
                    imgselect1= String.valueOf(filePath);
                    ImageUpload();
                }
                else if(Selectimg.equals("3"))
                {
                    img12.setImageBitmap(bitmap);
                    imgselect2= String.valueOf(filePath);
                    ImageUpload();
                }


            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }

        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK)
        {
            filePath = data.getData();
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            img11.setImageBitmap(photo);
            imgselect= String.valueOf(filePath);
        }




    }




    private void ImageUpload()
    {


        //   ImageView img = (ImageView) findViewById(R.id.img);


        Bitmap bitmap = null;


        if(Selectimg.equals("2"))
        {

            BitmapDrawable draw = (BitmapDrawable) img11.getDrawable();
            bitmap = draw.getBitmap();

        }
        else if(Selectimg.equals("3"))
        {

            BitmapDrawable draw = (BitmapDrawable) img12.getDrawable();
            bitmap = draw.getBitmap();

        }











        FileOutputStream outStream = null;



        File dir = null ;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            dir = new File (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)+ "/"+"Vijendra_Offsete"+ "/"+"Images" );
        } else {
            dir = new File(Environment.getExternalStorageDirectory() + "/"+"News4u"+ "/"+"Images");
        }


        if (!dir.exists()) {
            dir.mkdirs();
        }


        String fileName = String.format("%d.jpg", System.currentTimeMillis());




        File outFile = new File(dir, fileName);
        try {
            outStream = new FileOutputStream(outFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
        try {
            outStream.flush();
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(),"error code 403" , Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        try {
            outStream.close();



            Uri shareFact1 = Uri.parse(String.valueOf(outFile));
            Log.i("MyActivity", String.valueOf(shareFact1));



            all_file_path = String.valueOf(outFile);
            UploadTask uploadTask = new UploadTask();
            uploadTask.execute(new String[]{all_file_path});
            file_name="" + new File(all_file_path).getName();





        } catch (IOException e) {
            Toast.makeText(getApplicationContext(),"error code 402" , Toast.LENGTH_SHORT).show();

            e.printStackTrace();
        }
    }




    public class UploadTask extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(GuestVisit.this);
            progressDialog.setTitle("Please Wait..");
            progressDialog.setMessage("Uploading");
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            //   progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s!=null){

                SharedPreferences userdetail = getSharedPreferences("Agentdata", MODE_PRIVATE);
                String s1 = (userdetail.getString("a_id", ""));

                Toast.makeText(GuestVisit.this, "File Uploaded", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();



                //     UpdateStage();

            }
            else{
                Toast.makeText(GuestVisit.this, "File Upload Failed", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
            //  progressBar.setVisibility(View.GONE);
        }

        @Override
        protected String doInBackground(String... strings) {

            File file1 = new File(strings[0]);
            SharedPreferences userdetail = getSharedPreferences("Agentdata", MODE_PRIVATE);
            String s1 = (userdetail.getString("a_id", ""));

            try {
                Log.i("MyActivity",file1.getName());
                Log.i("MyActivity", String.valueOf(file1));
                long time= System.currentTimeMillis();


                if(Selectimg.equals("1"))
                {
                    file_imgselect=time+"_"+file1.getName();;


                }
                else if(Selectimg.equals("2"))
                {
                    file_imgselect1=time+"_"+file1.getName();

                }
                else if(Selectimg.equals("3"))
                {
                    file_imgselect2=time+"_"+file1.getName();

                }
                else if(Selectimg.equals("4"))
                {
                    file_imgselect3=time+"_"+file1.getName();

                }
                else if(Selectimg.equals("5"))
                {
                    file_imgselect4=time+"_"+file1.getName();
                }





                //  imgselect= time+"_"+file1.getName();
                RequestBody requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
                        .addFormDataPart("files1", time+"_"+file1.getName(),
                                RequestBody.create(MediaType.parse("*/*"), file1))

                        .addFormDataPart("some_key", "some_value")
                        .addFormDataPart("submit", "submit")
                        .build();
                okhttp3.Request request = new Request.Builder()
                        .url("http://campus.saioc.in/admin/file/upload2.php")
                      // .url("https://ayushsoftcare.com/File/upload2.php")
                        .post(requestBody)
                        .build();

                OkHttpClient okHttpClient = new OkHttpClient();
                //now progressbar not showing properly let's fixed it
                okhttp3.Response response = okHttpClient.newCall(request).execute();
                if (response != null && response.isSuccessful()) {
                    return response.body().string();
                } else {
                    return null;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }


    public boolean checkPermission() {
        int READ_EXTERNAL_PERMISSION = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        if((READ_EXTERNAL_PERMISSION != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_WRITE);
            return false;
        }
        return true;
    }





    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed because of this and that")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(GuestVisit.this,
                                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }
    }





    private boolean CheckPermission()
    {
        if(SDK_INT>=Build.VERSION_CODES.R)
        {
            return Environment.isExternalStorageManager();

        }
        else
        {
            int write=ContextCompat.checkSelfPermission(getApplicationContext(),WRITE_EXTERNAL_STORAGE);
            int read=ContextCompat.checkSelfPermission(getApplicationContext(),READ_EXTERNAL_STORAGE);
            return  write ==PackageManager.PERMISSION_GRANTED
                    && read ==PackageManager.PERMISSION_GRANTED;
        }
    }

    public void RequestPermission1()
    {
        if(SDK_INT>=Build.VERSION_CODES.R)
        {
            try {
                Intent intent=new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                intent.addCategory("android.intent.category.DEFAULT");
                intent.setData(Uri.parse(String.format("package:%s",new Object[]{getApplicationContext().getPackageName()})));
                startActivityForResult(intent,2000);
            }
            catch (Exception e)
            {
                Intent obj=new Intent();
                obj.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult(obj,2000);

            }



        }
        else
        {
            ActivityCompat.requestPermissions(GuestVisit.this,new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, conn);
        }
    }









    private boolean checkPermission(String permission) {
        int result = ContextCompat.checkSelfPermission(GuestVisit.this, permission);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }
    private void requestPermission(String permission) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(GuestVisit.this, permission)) {
            Toast.makeText(GuestVisit.this, "Please Allow Permission", Toast.LENGTH_SHORT).show();
        } else {
            Log.i("MyActivity","11");
            //  filePicker(method);
            //     ActivityCompat.requestPermissions(GuestVisit.this, new String[]{permission}, PERMISSION_REQUEST_CODE);
        }
    }


    public abstract class TextValidator1 implements TextWatcher {
        private final EditText editText;


        public TextValidator1(EditText editText) {
            this.editText = editText;

        }

        public abstract void validate(EditText editText, String text);

        @Override
        final public void afterTextChanged(Editable s) {
            String text = editText.getText().toString();
            validate(editText, text);
        }

        @Override
        final public void beforeTextChanged(CharSequence s, int start, int count, int after) { /* Don't care */ }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        final public void onTextChanged(CharSequence s, int start, int before, int count) {


            editText.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#ff1100")));

            /* Don't care */
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:{



                onBackPressed();
                return true;
            }

            default:
                return super.onOptionsItemSelected(item);
        }

    }

}