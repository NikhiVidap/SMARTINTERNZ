package my.service.campus;

import android.content.Intent;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class Final1 extends AppCompatActivity {


    private Button b1;
    private LinearLayout l1,l2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.final_page);



        b1 =  findViewById(R.id.b1);
        l1 =  findViewById(R.id.l1);
        l2 =  findViewById(R.id.l2);



        final String key = getIntent().getStringExtra("key");

        Log.i("AAAAAAAA",key);


        if(key.equals("0"))
        {
            l2.setVisibility(View.VISIBLE);
            l1.setVisibility(View.GONE);
        }
        else
        {
            l1.setVisibility(View.VISIBLE);
            l2.setVisibility(View.GONE);
        }


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(Final1.this, MainActivity.class);

                startActivity(intent);
                finish();

            }
        });




    }


}
