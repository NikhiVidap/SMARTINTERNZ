package my.service.campus;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;

import static my.service.campus.API.Constant.Baseurl;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.google.android.material.textfield.TextInputEditText;

import my.service.campus.API.ApiNew1;
import my.service.campus.API.List.DefualtList.DefualtList;
import my.service.campus.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;


public class LoginDashboard extends AppCompatActivity {



    private String[] a=new String[2];



    private TextInputEditText email,password;
    private Button b1,b2;
    private Toolbar mToolbar;
    private EditText e1;

    private TextView tf,go;

    public static final String MyPREFERENCES = "UserData" ;
    SharedPreferences sharedpreferences1;
    public static final String Varify_account = "Varify_account";
    public static final String phone_number1 = "phone_number1";


    private TextView register,btn_forgot;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);




        SharedPreferences userdetail = getSharedPreferences("UserData", MODE_PRIVATE);

        String s12 = (userdetail.getString("phone_number1", ""));

        if(s12.equals("logout"))
        {

        }
        else
        {

            if(s12.equals(""))
            {

            }
            else
            {
                Intent intent = new Intent(LoginDashboard.this, HomeActivity.class);

                startActivity(intent);
                finish();
            }

        }



        e1 = findViewById(R.id.e1);

        b1 = findViewById(R.id.submit);















        if ( b1 != null) {
            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    final String e11 = e1.getText().toString().trim();



                    if (TextUtils.isEmpty(e11)) {
                        Toast.makeText(getApplicationContext(), "Enter data!", Toast.LENGTH_SHORT).show();
                        return;
                    }



                    Login(e11);



                    //  Intent mySuperIntent = new Intent(Login.this, LoginActivity.class);
                    //    startActivity(mySuperIntent);



                }
            });


        }

    }


    private void Login(String Username)
    {





        ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(LoginDashboard.this);
        progressDialog.setTitle("Please Wait..");
        progressDialog.setMessage("Loading");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();



        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(Baseurl)
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiNew1 postApiNew=retrofit.create(ApiNew1.class);



        String a="a";
        Call<DefualtList> call=postApiNew.user_login(Username);
        call.enqueue(new Callback<DefualtList>() {
            @Override
            public void onResponse(Call<DefualtList> call, Response<DefualtList> response) {
                if(!response.isSuccessful())
                {
                    progressDialog.hide();
                    Log.i("MyActivity", "Code1:"+response.code());
                    return;
                }

                Log.i("MyActivity", "Code1:"+response.code());

                if(response.body().getMessage()==null)
                {
                    progressDialog.hide();
                    Toast.makeText(getApplicationContext(), "Error code 401", Toast.LENGTH_SHORT).show();

                    Log.i("MyActivity", "Empty");
                }
                else
                {

                    if(response.body().getStatus()!=0)
                    {
                        progressDialog.hide();
                        Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();

                        Log.i("MyActivity",response.body().getMessage().toString());
                        Log.i("MyActivity","Wrong");

                    }
                    else
                    {

                        progressDialog.hide();

                        Log.i("MyActivity","correct");
                        String id1= response.body().getMessage();


                        Toast.makeText(getApplicationContext(), "Log-In Successful", Toast.LENGTH_SHORT).show();

                        sharedpreferences1 = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor1 = sharedpreferences1.edit();
                        editor1.putString(phone_number1, Username);

                        editor1.commit();






                        Intent intent = new Intent(LoginDashboard.this, HomeActivity.class);
                      
                        startActivity(intent);
                        finish();

                    }

                }

            }
            @Override
            public void onFailure(Call<DefualtList> call, Throwable t)
            {
                progressDialog.hide();
                Log.i("MyActivity", t.getMessage());
            }
        });


    }






}