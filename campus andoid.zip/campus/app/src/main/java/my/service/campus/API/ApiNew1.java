package my.service.campus.API;


import my.service.campus.API.List.DefualtList.DefualtList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiNew1{




    @FormUrlEncoded
    @POST("admin/api-login-app.php")
    Call<DefualtList> user_login(

            @Field("unique_code") String unique_code



    );

    @FormUrlEncoded
    @POST("admin/api-save-entry-record.php")
    Call<DefualtList> entry_record(

            @Field("vehicle_id") String vehicle_id



    );



    @FormUrlEncoded
    @POST("admin/api-add-guest-entry.php")
    Call<DefualtList> add_guest(

            @Field("guest_name") String guest_name,
            @Field("guest_mobile_number") String guest_mobile_number,
            @Field("guest_address") String guest_address,
            @Field("guest_visit_purpose") String guest_visit_purpose,
            @Field("no_of_peoples") String no_of_peoples,
            @Field("aadhar_card_photo") String aadhar_card_photo,
            @Field("aadhar_card_photo1") String aadhar_card_photo1



    );




}
